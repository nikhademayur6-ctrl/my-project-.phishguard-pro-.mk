export type RiskLevel = 'SAFE' | 'LOW RISK' | 'SUSPICIOUS' | 'HIGH RISK' | 'CRITICAL';

export type ThreatCategory =
  | 'Credential Harvesting'
  | 'Brand Impersonation'
  | 'Financial / Invoice Scam'
  | 'Malware Distribution'
  | 'Account Verification Scam'
  | 'Delivery / Package Scam'
  | 'Tech Support Scam'
  | 'Advance Fee / 419 Scam'
  | 'CEO Fraud / BEC'
  | 'QR Code Quishing'
  | 'Suspicious Domain'
  | 'Legitimate / Benign';

export type UserRole = 'User' | 'Security Analyst' | 'Administrator';

export type ThemeMode = 'dark' | 'light';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  mfaEnabled: boolean;
  apiKey?: string;
  createdAt: string;
  lastLogin: string;
}

export interface ThreatSignal {
  id: string;
  category: 'URL' | 'Domain' | 'SSL/TLS' | 'Content' | 'Threat Intel' | 'DNS' | 'Behavioral';
  name: string;
  description: string;
  severity: 'benign' | 'low' | 'medium' | 'high' | 'critical';
  isSafeSignal?: boolean;
  scoreContribution: number;
  evidence?: string;
}

export interface UrlAnalysisResult {
  id: string;
  url: string;
  normalizedUrl: string;
  domain: string;
  riskScore: number; // 0 - 100
  riskLevel: RiskLevel;
  confidence: number; // 0 - 100%
  timestamp: string;
  threatCategory: ThreatCategory;
  aiExplanation: {
    summary: string;
    whySuspicious: string[];
    positiveSignals: string[];
    recommendedAction: string;
    mitreTechniques: string[];
    analystNotes?: string;
  };
  signals: ThreatSignal[];
  technicalDetails: {
    https: boolean;
    domainAgeDays?: number;
    redirectCount: number;
    redirectChain: string[];
    ipAddress?: string;
    isIpHost: boolean;
    hasHomoglyphs: boolean;
    punycodeDomain?: string;
    tld: string;
    tldRisk: 'Low' | 'Medium' | 'High' | 'Suspicious';
    subdomainCount: number;
    subdomains: string[];
    suspiciousKeywords: string[];
    entropyScore: number;
    sslIssuer?: string;
    sslValid: boolean;
    dnsRecordsFound: boolean;
    threatIntelHits: string[];
  };
  targetBrand?: string;
  isDemoData?: boolean;
  falsePositiveReported?: boolean;
}

export interface EmailAnalysisResult {
  id: string;
  subject?: string;
  sender?: string;
  replyTo?: string;
  content: string;
  riskScore: number;
  riskLevel: RiskLevel;
  confidence: number;
  timestamp: string;
  threatCategory: ThreatCategory;
  extractedUrls: {
    url: string;
    displayAnchor?: string;
    mismatch: boolean;
    riskScore: number;
  }[];
  suspiciousPhrases: {
    phrase: string;
    reason: string;
    severity: 'low' | 'medium' | 'high';
  }[];
  indicators: {
    urgencyLanguage: boolean;
    fearBasedLanguage: boolean;
    credentialRequest: boolean;
    paymentRequest: boolean;
    brandImpersonation: boolean;
    senderMismatch: boolean;
    attachmentRisk: boolean;
  };
  aiExplanation: {
    summary: string;
    keyPoints: string[];
    safeHandlingInstructions: string[];
    remediationSteps: string[];
  };
  isDemoData?: boolean;
}

export interface DomainIntelData {
  domain: string;
  riskScore: number;
  riskLevel: RiskLevel;
  registrar: string;
  creationDate: string;
  expirationDate: string;
  domainAge: string;
  nameservers: string[];
  ipAddress: string;
  country: string;
  dnsRecords: {
    a: string[];
    mx: string[];
    txt: string[];
    ns: string[];
  };
  sslCertificate: {
    valid: boolean;
    issuer: string;
    subject: string;
    validFrom: string;
    validTo: string;
    daysRemaining: number;
  };
  reputation: {
    blacklisted: boolean;
    sourcesChecked: number;
    detections: number;
    categories: string[];
  };
  subdomains: string[];
  typosquats: {
    domain: string;
    type: string;
    status: 'Active' | 'Available' | 'Parked' | 'Suspicious';
    riskScore: number;
  }[];
  isVerified: boolean;
}

export interface Incident {
  id: string;
  title: string;
  type?: 'URL Phishing' | 'Email Phishing' | 'Quishing' | 'Credential Portal' | 'Impersonation' | 'Malware Dropper' | string;
  severity: 'Low' | 'Medium' | 'High' | 'Critical' | 'low' | 'medium' | 'high' | 'critical';
  status: 'New' | 'Investigating' | 'Contained' | 'Resolved' | 'Closed';
  assignee?: string;
  assignedTo?: string;
  reporter?: string;
  targetUser?: string;
  createdAt: string;
  updatedAt: string;
  sourceUrl?: string;
  sourceEmail?: string;
  source?: string;
  category?: string;
  description?: string;
  riskScore?: number;
  iocs: string[];
  tags: string[];
  notes?: {
    id: string;
    author: string;
    timestamp: string;
    content: string;
  }[];
  timeline: {
    id?: string;
    timestamp: string;
    event?: string;
    note?: string;
    actor?: string;
    author?: string;
  }[];
}

export interface ThreatReport {
  id: string;
  submissionType?: 'URL' | 'Email' | 'QR Code' | 'Fake Website' | 'SMS' | 'Other';
  type?: 'URL' | 'Email' | 'QR Code' | 'Fake Website' | 'SMS' | 'Other';
  target: string;
  details?: string;
  description?: string;
  reporterEmail: string;
  status: 'Report Received' | 'Under Review' | 'Investigation' | 'Action Taken' | 'Closed' | 'Verified Threat' | 'Resolved' | 'False Positive';
  riskScore?: number;
  createdAt: string;
  updatedAt?: string;
  analystComment?: string;
  evidenceFiles?: string[];
}

export interface ThreatIntelFeed {
  id: string;
  name: string;
  provider: string;
  type: 'URL Reputation' | 'Malware Hashes' | 'Domain Intel' | 'IP Reputation' | 'CISA Feed';
  status: 'Active' | 'Degraded' | 'Offline' | 'Configured';
  lastSync: string;
  indicatorsCount: number;
  reliability: 'High' | 'Medium' | 'Authoritative';
  apiKeyConfigured: boolean;
}

export interface IOCItem {
  id: string;
  type: 'URL' | 'Domain' | 'IP' | 'SHA256' | 'Email';
  value: string;
  threatType: string;
  confidence: number;
  firstSeen: string;
  lastSeen: string;
  source: string;
  status: 'Active' | 'Mitigated' | 'Monitoring';
}

export interface DetectionRule {
  id: string;
  name: string;
  description: string;
  category: 'URL Pattern' | 'Domain Homograph' | 'Email Keyword' | 'Entropy Threshold' | 'TLD Filter';
  pattern: string;
  riskWeight: number;
  enabled: boolean;
  createdBy: string;
  createdAt: string;
}

export interface FileScanResult {
  id: string;
  fileName: string;
  fileSize: number;
  fileType: string;
  sha256: string;
  md5: string;
  sha1: string;
  entropy: number;
  suspiciousIndicators: string[];
  riskScore: number;
  riskLevel: RiskLevel;
  verdict: string;
  recommendation: string;
  scannedAt: string;
}

export interface QuizQuestion {
  id: string;
  title: string;
  scenario: string;
  artifactType: 'email' | 'url' | 'sms' | 'qr';
  artifactContent: string;
  isPhishing: boolean;
  redFlags: string[];
  explanation: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
}

export interface CourseModule {
  id: string;
  title: string;
  category: string;
  readTime: string;
  description: string;
  lessons: {
    title: string;
    content: string;
    tips: string[];
  }[];
  quizQuestions: QuizQuestion[];
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'alert' | 'incident' | 'threat_intel' | 'system';
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: string;
  read: boolean;
  link?: string;
}

export type DomainIntel = DomainIntelData;
export type IncidentStatus = 'New' | 'Investigating' | 'Contained' | 'Resolved' | 'Closed';
export type SeverityLevel = 'Low' | 'Medium' | 'High' | 'Critical';
export type FileAnalysisResult = FileScanResult;

export interface AuditLogItem {
  id: string;
  action: string;
  performedBy: string;
  timestamp: string;
  target: string;
  details: string;
}

