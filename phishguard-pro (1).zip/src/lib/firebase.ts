import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDocs,
  onSnapshot,
  query,
  orderBy,
  limit,
  updateDoc,
  deleteDoc,
  Unsubscribe
} from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { UrlAnalysisResult, Incident, ThreatReport, IOCItem } from '../types';

// Initialize Firebase App
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize Firestore
// Use firestoreDatabaseId if specified in config, otherwise fallback to default
export const db = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

export const auth = getAuth(app);

/**
 * Scan Telemetry Firestore Operations
 */
export async function saveScanToFirestore(scan: UrlAnalysisResult): Promise<void> {
  try {
    const scanRef = doc(db, 'scans', scan.id);
    await setDoc(scanRef, {
      ...scan,
      syncedAt: new Date().toISOString()
    }, { merge: true });
  } catch (err) {
    console.warn('Firebase saveScan error:', err);
  }
}

export async function deleteScanFromFirestore(id: string): Promise<void> {
  try {
    const scanRef = doc(db, 'scans', id);
    await deleteDoc(scanRef);
  } catch (err) {
    console.warn('Firebase deleteScan error:', err);
  }
}

export async function clearAllScansFromFirestore(scans: UrlAnalysisResult[]): Promise<void> {
  try {
    const promises = scans.map(s => deleteDoc(doc(db, 'scans', s.id)));
    await Promise.all(promises);
  } catch (err) {
    console.warn('Firebase clearAllScans error:', err);
  }
}

export function subscribeToScans(callback: (scans: UrlAnalysisResult[]) => void): Unsubscribe {
  const scansRef = collection(db, 'scans');
  const q = query(scansRef, limit(30));

  return onSnapshot(q, (snapshot) => {
    if (!snapshot.empty) {
      const items: UrlAnalysisResult[] = [];
      snapshot.forEach(docSnap => {
        items.push(docSnap.data() as UrlAnalysisResult);
      });
      // Sort newest first
      items.sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || ''));
      callback(items);
    }
  }, (err) => {
    console.warn('Scans subscription error:', err);
  });
}

/**
 * SOC Incidents Firestore Operations
 */
export async function saveIncidentToFirestore(incident: Incident): Promise<void> {
  try {
    const incRef = doc(db, 'incidents', incident.id);
    await setDoc(incRef, {
      ...incident,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (err) {
    console.warn('Firebase saveIncident error:', err);
  }
}

export async function updateIncidentStatusInFirestore(id: string, status: Incident['status']): Promise<void> {
  try {
    const incRef = doc(db, 'incidents', id);
    await updateDoc(incRef, {
      status,
      updatedAt: new Date().toISOString()
    });
  } catch (err) {
    console.warn('Firebase updateIncidentStatus error:', err);
  }
}

export async function addIncidentNoteInFirestore(id: string, timeline: Incident['timeline']): Promise<void> {
  try {
    const incRef = doc(db, 'incidents', id);
    await updateDoc(incRef, {
      timeline,
      updatedAt: new Date().toISOString()
    });
  } catch (err) {
    console.warn('Firebase addIncidentNote error:', err);
  }
}

export function subscribeToIncidents(callback: (incidents: Incident[]) => void): Unsubscribe {
  const incRef = collection(db, 'incidents');
  return onSnapshot(incRef, (snapshot) => {
    if (!snapshot.empty) {
      const items: Incident[] = [];
      snapshot.forEach(docSnap => {
        items.push(docSnap.data() as Incident);
      });
      callback(items);
    }
  }, (err) => {
    console.warn('Incidents subscription error:', err);
  });
}

/**
 * Incident Reports Firestore Operations
 */
export async function saveReportToFirestore(report: ThreatReport): Promise<void> {
  try {
    const repRef = doc(db, 'reports', report.id);
    await setDoc(repRef, report, { merge: true });
  } catch (err) {
    console.warn('Firebase saveReport error:', err);
  }
}

export function subscribeToReports(callback: (reports: ThreatReport[]) => void): Unsubscribe {
  const repRef = collection(db, 'reports');
  return onSnapshot(repRef, (snapshot) => {
    if (!snapshot.empty) {
      const items: ThreatReport[] = [];
      snapshot.forEach(docSnap => {
        items.push(docSnap.data() as ThreatReport);
      });
      callback(items);
    }
  }, (err) => {
    console.warn('Reports subscription error:', err);
  });
}

/**
 * Threat IOCs Firestore Operations
 */
export async function saveIocToFirestore(ioc: IOCItem): Promise<void> {
  try {
    const iocRef = doc(db, 'iocs', ioc.id);
    await setDoc(iocRef, ioc, { merge: true });
  } catch (err) {
    console.warn('Firebase saveIoc error:', err);
  }
}

export function subscribeToIocs(callback: (iocs: IOCItem[]) => void): Unsubscribe {
  const iocsRef = collection(db, 'iocs');
  return onSnapshot(iocsRef, (snapshot) => {
    if (!snapshot.empty) {
      const items: IOCItem[] = [];
      snapshot.forEach(docSnap => {
        items.push(docSnap.data() as IOCItem);
      });
      callback(items);
    }
  }, (err) => {
    console.warn('IOCs subscription error:', err);
  });
}
