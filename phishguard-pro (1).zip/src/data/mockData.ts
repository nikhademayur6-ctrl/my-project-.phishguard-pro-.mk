import {
  UrlAnalysisResult,
  Incident,
  ThreatReport,
  ThreatIntelFeed,
  IOCItem,
  DetectionRule,
  CourseModule,
  NotificationItem,
  DomainIntelData
} from '../types';

export const INITIAL_URL_SCANS: UrlAnalysisResult[] = [
  {
    id: 'scan-101',
    url: 'https://paypal-security-update-center.top/login/index.php',
    normalizedUrl: 'https://paypal-security-update-center.top/login/index.php',
    domain: 'paypal-security-update-center.top',
    riskScore: 94,
    riskLevel: 'CRITICAL',
    confidence: 96,
    timestamp: '2026-08-26T04:12:00Z',
    threatCategory: 'Brand Impersonation',
    targetBrand: 'PayPal',
    aiExplanation: {
      summary: 'Critical danger: High-confidence active phishing campaign targeting PayPal credentials.',
      whySuspicious: [
        'Domain contains trademarked brand name "paypal" but is registered under an unofficial .top TLD.',
        'Uses typical phishing keywords: "security-update-center" and "/login/index.php".',
        'Domain was created 3 days ago according to WHOIS record heuristics.',
        'Matches known pattern on global OpenPhish intelligence feed.'
      ],
      positiveSignals: ['HTTPS transport active (standard for modern phishing kits)'],
      recommendedAction: 'BLOCK IMMEDIATELY. Do not enter credentials. Add domain to firewall blocklist.',
      mitreTechniques: ['T1566.001 - Spearphishing Link', 'T1036.005 - Masquerading', 'T1056.003 - Input Capture'],
      analystNotes: 'Domain actively resolves to 185.220.101.44 (known bulletproof hosting provider).'
    },
    signals: [
      { id: 's1', category: 'Domain', name: 'Brand Impersonation in FQDN', description: 'Explicit misuse of "PayPal" brand in unauthorized domain', severity: 'critical', scoreContribution: 40 },
      { id: 's2', category: 'Domain', name: 'High-Abuse TLD (.top)', description: 'Registrar extension with over 68% malicious disposition score', severity: 'high', scoreContribution: 25 },
      { id: 's3', category: 'Content', name: 'Credential Harvesting Path', description: 'Explicit login portal path observed', severity: 'high', scoreContribution: 20 },
      { id: 's4', category: 'Threat Intel', name: 'Feed Match: OpenPhish', description: 'Active IOC reported in global threat feed', severity: 'critical', scoreContribution: 30 }
    ],
    technicalDetails: {
      https: true,
      domainAgeDays: 3,
      redirectCount: 1,
      redirectChain: ['https://paypal-security-update-center.top/login/index.php', 'https://paypal-security-update-center.top/auth/verify'],
      ipAddress: '185.220.101.44',
      isIpHost: false,
      hasHomoglyphs: false,
      tld: 'top',
      tldRisk: 'High',
      subdomainCount: 0,
      subdomains: [],
      suspiciousKeywords: ['paypal', 'security-update', 'login'],
      entropyScore: 4.31,
      sslIssuer: "Let's Encrypt Authority X3",
      sslValid: true,
      dnsRecordsFound: true,
      threatIntelHits: ['OpenPhish', 'PhishTank Community Feed']
    },
    isDemoData: true
  },
  {
    id: 'scan-102',
    url: 'https://office365-password-reset-portal.xyz/auth?user=employee@company.com',
    normalizedUrl: 'https://office365-password-reset-portal.xyz/auth?user=employee@company.com',
    domain: 'office365-password-reset-portal.xyz',
    riskScore: 89,
    riskLevel: 'HIGH RISK',
    confidence: 92,
    timestamp: '2026-08-26T03:45:00Z',
    threatCategory: 'Credential Harvesting',
    targetBrand: 'Microsoft',
    aiExplanation: {
      summary: 'High risk: Impersonation of Microsoft Office 365 authentication portal with targeted user parameter.',
      whySuspicious: [
        'Impersonates Microsoft Office 365 on an untrusted .xyz domain.',
        'Targeted user email parameter passed in query string to prefill phishing victim box.',
        'High entropy parameter strings.'
      ],
      positiveSignals: ['Valid SSL Certificate present'],
      recommendedAction: 'Isolate user mailbox, reset compromised credentials if clicked, and block across mail gateway.',
      mitreTechniques: ['T1566.002 - Spearphishing Attachment/Link', 'T1598 - Phishing for Info'],
      analystNotes: 'Observed targeting corporate financial staff.'
    },
    signals: [
      { id: 's21', category: 'Domain', name: 'Microsoft 365 Brand Spoof', description: 'Unauthorized use of office365 keyword in hostname', severity: 'critical', scoreContribution: 38 },
      { id: 's22', category: 'URL', name: 'Targeted Victim Email Parameter', description: 'Query string contains victim email address', severity: 'high', scoreContribution: 25 },
      { id: 's23', category: 'Domain', name: 'Disposable .xyz TLD', description: 'High frequency in spearphishing lures', severity: 'medium', scoreContribution: 15 }
    ],
    technicalDetails: {
      https: true,
      domainAgeDays: 6,
      redirectCount: 0,
      redirectChain: ['https://office365-password-reset-portal.xyz/auth'],
      ipAddress: '104.21.72.19',
      isIpHost: false,
      hasHomoglyphs: false,
      tld: 'xyz',
      tldRisk: 'Medium',
      subdomainCount: 0,
      subdomains: [],
      suspiciousKeywords: ['office365', 'password-reset', 'auth'],
      entropyScore: 4.82,
      sslIssuer: 'Cloudflare Inc ECC CA-3',
      sslValid: true,
      dnsRecordsFound: true,
      threatIntelHits: ['AbuseIPDB Threat List']
    },
    isDemoData: true
  },
  {
    id: 'scan-103',
    url: 'https://www.github.com/torvalds/linux',
    normalizedUrl: 'https://github.com/torvalds/linux',
    domain: 'github.com',
    riskScore: 2,
    riskLevel: 'SAFE',
    confidence: 99,
    timestamp: '2026-08-26T02:30:00Z',
    threatCategory: 'Legitimate / Benign',
    targetBrand: undefined,
    aiExplanation: {
      summary: 'Verified benign repository URL on verified GitHub domain with clean multi-year historical reputation.',
      whySuspicious: [],
      positiveSignals: [
        'Domain established in 2007 (mature domain authority).',
        'Valid DigiCert Extended Validation TLS Certificate.',
        'Clean across all authoritative global threat intelligence feeds.',
        'DNSSEC enabled with SPF/DKIM verification.'
      ],
      recommendedAction: 'Safe to access and interact with.',
      mitreTechniques: [],
      analystNotes: 'Known official source code repository.'
    },
    signals: [
      { id: 's31', category: 'Domain', name: 'Authoritative Domain Age', description: 'Registered over 18 years ago with zero malicious flags', severity: 'benign', isSafeSignal: true, scoreContribution: -30 },
      { id: 's32', category: 'SSL/TLS', name: 'High-Grade Commercial TLS', description: 'DigiCert High Assurance EV CA', severity: 'benign', isSafeSignal: true, scoreContribution: -10 }
    ],
    technicalDetails: {
      https: true,
      domainAgeDays: 6680,
      redirectCount: 0,
      redirectChain: ['https://github.com/torvalds/linux'],
      ipAddress: '140.82.121.4',
      isIpHost: false,
      hasHomoglyphs: false,
      tld: 'com',
      tldRisk: 'Low',
      subdomainCount: 1,
      subdomains: ['www'],
      suspiciousKeywords: [],
      entropyScore: 3.12,
      sslIssuer: 'DigiCert TLS RSA SHA256 2020 CA1',
      sslValid: true,
      dnsRecordsFound: true,
      threatIntelHits: []
    },
    isDemoData: true
  },
  {
    id: 'scan-104',
    url: 'http://192.241.220.88/secure/login/chase/auth.html',
    normalizedUrl: 'http://192.241.220.88/secure/login/chase/auth.html',
    domain: '192.241.220.88',
    riskScore: 98,
    riskLevel: 'CRITICAL',
    confidence: 98,
    timestamp: '2026-08-26T01:15:00Z',
    threatCategory: 'Financial / Invoice Scam',
    targetBrand: 'Chase Bank',
    aiExplanation: {
      summary: 'Critical threat: Direct raw IP address hosting cloned Chase Bank authentication portal over unencrypted HTTP.',
      whySuspicious: [
        'Direct IP address in URL instead of legitimate domain name.',
        'Unencrypted HTTP protocol exposing submitted credentials in plaintext.',
        'Directly targets Chase Bank online login mechanism.',
        'High entropy HTML artifact hosted on DigitalOcean droplet.'
      ],
      positiveSignals: [],
      recommendedAction: 'BLOCK ENTIRE SUBNET. Report IP to DigitalOcean Trust & Safety.',
      mitreTechniques: ['T1566.001 - Spearphishing Link', 'T1056.003 - Input Capture', 'T1583.003 - Virtual Private Server'],
      analystNotes: 'Cloned login portal targeting Chase online banking customers.'
    },
    signals: [
      { id: 's41', category: 'URL', name: 'Raw IP Address Hostname', description: 'Direct numeric host bypassing DNS hierarchy', severity: 'critical', scoreContribution: 45 },
      { id: 's42', category: 'SSL/TLS', name: 'Insecure HTTP Transport', description: 'Plaintext data transmission on financial login path', severity: 'high', scoreContribution: 25 },
      { id: 's43', category: 'Content', name: 'Chase Bank Impersonation', description: 'Explicit spoofing of financial institution', severity: 'critical', scoreContribution: 40 }
    ],
    technicalDetails: {
      https: false,
      domainAgeDays: 0,
      redirectCount: 0,
      redirectChain: ['http://192.241.220.88/secure/login/chase/auth.html'],
      ipAddress: '192.241.220.88',
      isIpHost: true,
      hasHomoglyphs: false,
      tld: 'none',
      tldRisk: 'Suspicious',
      subdomainCount: 0,
      subdomains: [],
      suspiciousKeywords: ['secure', 'login', 'chase', 'auth'],
      entropyScore: 4.15,
      sslValid: false,
      dnsRecordsFound: false,
      threatIntelHits: ['Spamhaus DROP', 'AbuseIPDB Flagged']
    },
    isDemoData: true
  }
];

export const INITIAL_INCIDENTS: Incident[] = [
  {
    id: 'INC-2026-8941',
    title: 'Targeted Executive Spearphishing Campaign (CEO Impersonation)',
    type: 'Email Phishing',
    severity: 'Critical',
    status: 'Investigating',
    assignee: 'Mayur Nikhade (Lead Analyst)',
    reporter: 'sarah.finance@enterprise.corp',
    targetUser: 'cfo.office@enterprise.corp',
    createdAt: '2026-08-26T03:10:00Z',
    updatedAt: '2026-08-26T04:05:00Z',
    sourceEmail: 'ceo-office-update@secure-board-exec.top',
    sourceUrl: 'https://secure-wire-transfer-authorization.top/portal',
    iocs: ['secure-board-exec.top', 'secure-wire-transfer-authorization.top', '185.220.101.44'],
    tags: ['BEC', 'Wire Fraud', 'Executive Target', 'MITRE:T1566'],
    notes: [
      {
        id: 'n1',
        author: 'Mayur Nikhade',
        timestamp: '2026-08-26T03:20:00Z',
        content: 'Triage complete. Phishing email attempted to spoof CEO requesting emergency vendor invoice payment of $142,000. Domain registered 14 hours ago.'
      },
      {
        id: 'n2',
        author: 'Mayur Nikhade',
        timestamp: '2026-08-26T03:55:00Z',
        content: 'Mailbox rules audited across 4 executive recipients. Extracted IOCs pushed to perimeter firewall and Microsoft Defender tenant.'
      }
    ],
    timeline: [
      { timestamp: '2026-08-26T03:10:00Z', event: 'Incident submitted via PhishGuard Pro Outlook Add-in', actor: 'sarah.finance' },
      { timestamp: '2026-08-26T03:15:00Z', event: 'Risk score evaluated at 98/100 (CRITICAL). Escalated to SOC.', actor: 'PhishGuard Engine' },
      { timestamp: '2026-08-26T03:20:00Z', event: 'Assigned to Mayur Nikhade; status moved to Investigating', actor: 'Mayur Nikhade' }
    ]
  },
  {
    id: 'INC-2026-8940',
    title: 'Quishing Campaign Targeting Office 365 MFA Credentials in Cafeteria QR Codes',
    type: 'Quishing',
    severity: 'High',
    status: 'Contained',
    assignee: 'Security Operations Tier 2',
    reporter: 'james.hr@enterprise.corp',
    createdAt: '2026-08-25T19:30:00Z',
    updatedAt: '2026-08-26T01:10:00Z',
    sourceUrl: 'https://mfa-employee-benefits-survey.xyz/verify',
    iocs: ['mfa-employee-benefits-survey.xyz', '45.142.214.10'],
    tags: ['Quishing', 'QR Phishing', 'Physical Social Engineering', 'MFA Harvest'],
    notes: [
      {
        id: 'n3',
        author: 'SOC Tier 2',
        timestamp: '2026-08-25T20:15:00Z',
        content: 'Physical QR flyers removed from 3 office buildings. Destination URL blocked on corporate proxy and DNS sinkhole.'
      }
    ],
    timeline: [
      { timestamp: '2026-08-25T19:30:00Z', event: 'Report filed with uploaded QR image', actor: 'james.hr' },
      { timestamp: '2026-08-25T19:35:00Z', event: 'QR Scanner decoded destination and flagged score 92/100', actor: 'PhishGuard Engine' },
      { timestamp: '2026-08-25T21:00:00Z', event: 'Perimeter DNS sinkhole updated. Contained.', actor: 'SecOps Team' }
    ]
  },
  {
    id: 'INC-2026-8939',
    title: 'Phishing Kit Deployment on Compromised WordPress Subdomain',
    type: 'URL Phishing',
    severity: 'Medium',
    status: 'Resolved',
    assignee: 'Automated Response Orchestrator',
    reporter: 'threat-intel-feed@phishguard.internal',
    createdAt: '2026-08-25T14:10:00Z',
    updatedAt: '2026-08-25T18:00:00Z',
    sourceUrl: 'https://bakery-demo.ca/wp-content/plugins/auth/paypal.php',
    iocs: ['bakery-demo.ca', '198.51.100.22'],
    tags: ['Compromised CMS', 'Phishing Kit', 'Automated Block'],
    notes: [
      {
        id: 'n4',
        author: 'Auto Orchestrator',
        timestamp: '2026-08-25T14:12:00Z',
        content: 'Webmaster notified. Host provider took down phishing script path.'
      }
    ],
    timeline: [
      { timestamp: '2026-08-25T14:10:00Z', event: 'Discovered via Threat Intel crawler', actor: 'Automated Feed' },
      { timestamp: '2026-08-25T18:00:00Z', event: 'Host confirmed script deletion. Incident resolved.', actor: 'Auto Orchestrator' }
    ]
  }
];

export const INITIAL_THREAT_REPORTS: ThreatReport[] = [
  {
    id: 'REP-2026-1049',
    submissionType: 'Email',
    target: 'suspicious-billing@fedex-parcel-delivery.xyz',
    details: 'Received an email claiming package delivery failed and demanding $2.40 redelivery fee with credit card.',
    reporterEmail: 'alex.dev@enterprise.corp',
    status: 'Investigation',
    riskScore: 91,
    createdAt: '2026-08-26T02:40:00Z',
    updatedAt: '2026-08-26T03:00:00Z',
    analystComment: 'Confirmed FedEx brand impersonation phishing kit. Domain added to global blocklist.'
  },
  {
    id: 'REP-2026-1048',
    submissionType: 'URL',
    target: 'https://metamask-security-audit-airdrop.io/claim',
    details: 'Telegram bot sent link claiming 500 USDT airdrop requesting 12-word seed phrase.',
    reporterEmail: 'crypto.enthusiast@enterprise.corp',
    status: 'Action Taken',
    riskScore: 97,
    createdAt: '2026-08-25T22:15:00Z',
    updatedAt: '2026-08-25T23:30:00Z',
    analystComment: 'Crypto drainer smart contract scam. Takedown requested to Cloudflare & registrar.'
  },
  {
    id: 'REP-2026-1047',
    submissionType: 'QR Code',
    target: 'https://quick-login-parking-pay.top',
    details: 'QR sticker placed over real parking meter in city center.',
    reporterEmail: 'urban.commuter@mail.org',
    status: 'Closed',
    riskScore: 88,
    createdAt: '2026-08-25T16:00:00Z',
    updatedAt: '2026-08-25T18:30:00Z',
    analystComment: 'Local municipal police & transit authority alerted. Fake payment gateway disabled.'
  }
];

export const INITIAL_THREAT_FEEDS: ThreatIntelFeed[] = [
  {
    id: 'feed-1',
    name: 'OpenPhish Global Community Feed',
    provider: 'OpenPhish Ltd',
    type: 'URL Reputation',
    status: 'Active',
    lastSync: '1 min ago',
    indicatorsCount: 48210,
    reliability: 'Authoritative',
    apiKeyConfigured: true
  },
  {
    id: 'feed-2',
    name: 'PhishTank Real-Time Feed',
    provider: 'OpenDNS / Cisco Talos',
    type: 'URL Reputation',
    status: 'Active',
    lastSync: '3 mins ago',
    indicatorsCount: 124500,
    reliability: 'Authoritative',
    apiKeyConfigured: true
  },
  {
    id: 'feed-3',
    name: 'AbuseIPDB Malicious Host Feed',
    provider: 'AbuseIPDB Project',
    type: 'IP Reputation',
    status: 'Active',
    lastSync: '8 mins ago',
    indicatorsCount: 89340,
    reliability: 'High',
    apiKeyConfigured: true
  },
  {
    id: 'feed-4',
    name: 'CISA Known Exploited Threats (KEV)',
    provider: 'US Cybersecurity & Infrastructure Security Agency',
    type: 'CISA Feed',
    status: 'Active',
    lastSync: '12 mins ago',
    indicatorsCount: 1140,
    reliability: 'Authoritative',
    apiKeyConfigured: true
  },
  {
    id: 'feed-5',
    name: 'VirusTotal Threat Intelligence',
    provider: 'Google Cloud Security',
    type: 'Malware Hashes',
    status: 'Configured',
    lastSync: '15 mins ago',
    indicatorsCount: 520000,
    reliability: 'Authoritative',
    apiKeyConfigured: true
  },
  {
    id: 'feed-6',
    name: 'AlienVault OTX Community Feed',
    provider: 'AT&T Cybersecurity',
    type: 'Domain Intel',
    status: 'Active',
    lastSync: '22 mins ago',
    indicatorsCount: 310500,
    reliability: 'High',
    apiKeyConfigured: true
  }
];

export const INITIAL_IOCS: IOCItem[] = [
  { id: 'ioc-1', type: 'Domain', value: 'paypal-security-update-center.top', threatType: 'PayPal Phish', confidence: 98, firstSeen: '2026-08-24', lastSeen: 'Just now', source: 'OpenPhish', status: 'Active' },
  { id: 'ioc-2', type: 'URL', value: 'https://office365-password-reset-portal.xyz/auth', threatType: 'Credential Harvester', confidence: 95, firstSeen: '2026-08-25', lastSeen: '15m ago', source: 'PhishGuard Sensor', status: 'Active' },
  { id: 'ioc-3', type: 'IP', value: '185.220.101.44', threatType: 'Phishing C2 Host', confidence: 92, firstSeen: '2026-08-20', lastSeen: '30m ago', source: 'AbuseIPDB', status: 'Active' },
  { id: 'ioc-4', type: 'SHA256', value: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', threatType: 'Malicious Invoice Macro Dropper', confidence: 99, firstSeen: '2026-08-21', lastSeen: '2h ago', source: 'VirusTotal', status: 'Mitigated' },
  { id: 'ioc-5', type: 'Domain', value: 'dhl-tracking-parcel-support.click', threatType: 'Delivery Smishing', confidence: 91, firstSeen: '2026-08-23', lastSeen: '1h ago', source: 'AlienVault OTX', status: 'Active' },
  { id: 'ioc-6', type: 'Email', value: 'ceo-office-update@secure-board-exec.top', threatType: 'BEC Impersonator', confidence: 96, firstSeen: '2026-08-26', lastSeen: '45m ago', source: 'PhishGuard Sensor', status: 'Active' }
];

export const INITIAL_DETECTION_RULES: DetectionRule[] = [
  {
    id: 'rule-1',
    name: 'High-Risk TLD & Brand Impersonation Combination',
    description: 'Triggers when a known financial or cloud brand occurs inside a .top, .xyz, .click, or .tk TLD',
    category: 'Domain Homograph',
    pattern: '(paypal|microsoft|apple|chase|netflix|google).*(top|xyz|click|tk|work|icu)$',
    riskWeight: 40,
    enabled: true,
    createdBy: 'Mayur Nikhade',
    createdAt: '2026-08-01'
  },
  {
    id: 'rule-2',
    name: 'Raw IP Host with Authentication Keywords',
    description: 'Flags URLs with direct IPv4 hosts containing /login, /auth, /verify, or /secure',
    category: 'URL Pattern',
    pattern: 'https?:\\/\\/\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\/.*(login|auth|verify|secure)',
    riskWeight: 45,
    enabled: true,
    createdBy: 'Mayur Nikhade',
    createdAt: '2026-08-05'
  },
  {
    id: 'rule-3',
    name: 'High Shannon Entropy URL Detection (> 4.5)',
    description: 'Flags obfuscated query strings commonly generated by automated phishing kit builders',
    category: 'Entropy Threshold',
    pattern: 'entropy > 4.5 AND length > 80',
    riskWeight: 20,
    enabled: true,
    createdBy: 'Mayur Nikhade',
    createdAt: '2026-08-10'
  },
  {
    id: 'rule-4',
    name: 'Urgent Wire Transfer & Gift Card Solicitation',
    description: 'Linguistic rule detecting executive fraud and emergency payment demands',
    category: 'Email Keyword',
    pattern: '(immediate wire|gift card payment|overdue invoice|confidential transaction)',
    riskWeight: 35,
    enabled: true,
    createdBy: 'SOC Lead Analyst',
    createdAt: '2026-08-12'
  }
];

export const EDUCATION_COURSES: CourseModule[] = [
  {
    id: 'mod-1',
    title: 'Phishing Fundamentals: Recognizing Modern Threat Vectors',
    category: 'Foundations',
    readTime: '6 min read',
    description: 'Learn the primary indicators of deceptive URLs, domain spoofing, and emotional manipulation.',
    lessons: [
      {
        title: '1. Anatomy of Deceptive URLs',
        content: 'Attackers manipulate subdomains to make URLs look official. For example, in "https://paypal.com.account-update.xyz", the actual destination is "account-update.xyz", NOT paypal.com. Always read the domain name from right to left before the first single forward slash.',
        tips: [
          'Look at the word immediately preceding the Top-Level Domain (.com, .org, etc.).',
          'Beware of excessive hyphens (e.g. "secure-login-chase-bank.com").',
          'Hover over links before clicking to reveal the true destination address.'
        ]
      },
      {
        title: '2. The Psychological Weapons of Phishers',
        content: 'Phishing exploits human emotion rather than software vulnerabilities. The 4 primary triggers are: 1. Artificial Urgency ("Account suspended in 24 hours"), 2. Fear of Consequence ("Legal warrant issued"), 3. Curiosity / Greed ("Unclaimed $1,000 refund"), and 4. Authority ("Message from CEO - confidential").',
        tips: [
          'Slow down: If a message demands immediate action, treat it as a red flag.',
          'Verify out-of-band: Call the sender using an independently verified phone number.',
          'Never use phone numbers or contact links provided inside the suspicious message.'
        ]
      }
    ],
    quizQuestions: [
      {
        id: 'q1',
        title: 'Spot the Real Destination Domain',
        scenario: 'You receive a notification urging you to review a document. You hover over the link and see: "https://google.com.drive-share-auth.top/folder/doc123". What is the true apex domain you will connect to?',
        artifactType: 'url',
        artifactContent: 'https://google.com.drive-share-auth.top/folder/doc123',
        isPhishing: true,
        redFlags: ['Domain is "drive-share-auth.top", not google.com', 'google.com is merely a deceptive subdomain prefix', 'High-risk .top TLD'],
        explanation: 'In DNS hierarchy, the true domain is the last two labels before the path ("drive-share-auth.top"). "google.com" is just a subdomain crafted by the attacker.',
        difficulty: 'Beginner'
      },
      {
        id: 'q2',
        title: 'Netflix Billing Suspension Lure',
        scenario: 'An email arrives with the subject "Your Netflix membership is on hold". The sender is "support@netflix-billing-recovery.xyz". It contains an "Update Payment" button.',
        artifactType: 'email',
        artifactContent: 'Subject: Your Netflix membership is on hold\nFrom: support@netflix-billing-recovery.xyz\n\nDear Customer,\nWe failed to process your latest subscription payment. Your service will be disconnected within 12 hours unless you update your card information immediately.\n\n[Update Payment Method Now]',
        isPhishing: true,
        redFlags: ['Unofficial domain (@netflix-billing-recovery.xyz)', 'Artificial 12-hour urgency deadline', 'Generic greeting ("Dear Customer") instead of your registered name'],
        explanation: 'Netflix sends billing notices strictly from @netflix.com. The urgency deadline and generic greeting are classic social-engineering hallmarks.',
        difficulty: 'Beginner'
      }
    ]
  },
  {
    id: 'mod-2',
    title: 'Quishing & QR-Code Phishing Defense',
    category: 'Emerging Threats',
    readTime: '8 min read',
    description: 'Understand how adversaries exploit physical & digital QR codes to bypass email security filters.',
    lessons: [
      {
        title: '1. Why Attackers Use QR Codes (Quishing)',
        content: 'Traditional email security gateways inspect text, hyperlinks, and attachments. When an attacker replaces a malicious hyperlink with a QR code image, standard text-based scanners often cannot evaluate the destination URL. This shifts the attack directly to personal mobile devices where corporate endpoint protection may be absent.',
        tips: [
          'Never scan QR codes in emails requesting authentication or password resets.',
          'Always use a defensive scanner like PhishGuard Pro to inspect the decoded URL before opening.',
          'Inspect physical QR stickers on public parking meters or menus for tampering.'
        ]
      }
    ],
    quizQuestions: [
      {
        id: 'q3',
        title: 'Cafeteria MFA Update QR Code',
        scenario: 'You see a flyer in the breakroom titled "Mandatory IT MFA Migration" featuring a QR code. Scanning the QR code points to "https://it-auth-portal.xyz/mfa". Is this safe?',
        artifactType: 'qr',
        artifactContent: 'https://it-auth-portal.xyz/mfa',
        isPhishing: true,
        redFlags: ['Legitimate IT teams rarely deploy physical QR codes for password/MFA migration', 'Unapproved .xyz domain', 'Bypasses internal SSO identity provider'],
        explanation: 'Physical QR social engineering is an increasingly popular tactic to compromise corporate credentials. IT announcements should always be verified on the company intranet.',
        difficulty: 'Intermediate'
      }
    ]
  },
  {
    id: 'mod-3',
    title: 'Business Email Compromise (BEC) & Executive Fraud',
    category: 'Advanced Defense',
    readTime: '10 min read',
    description: 'Deep dive into supplier invoice fraud, executive impersonation, and payroll redirection scams.',
    lessons: [
      {
        title: '1. Recognizing BEC Tactics',
        content: 'BEC scams rarely contain malicious links or malware attachments; they rely entirely on social engineering, display-name spoofing, and forged authority to convince accounting personnel to execute wire transfers or update direct deposit bank details.',
        tips: [
          'Require dual-custody phone confirmation for any wire transfer or bank account change.',
          'Check the "Reply-To" header carefully — it often differs from the displayed "From" address.',
          'Beware of requests marked "Strictly Confidential" or "Do Not Call Me, I am in a Board Meeting".'
        ]
      }
    ],
    quizQuestions: [
      {
        id: 'q4',
        title: 'Urgent Wire Transfer Request from CEO',
        scenario: 'An email arrives appearing to be from your CEO: "I need you to process a confidential acquisition retainer of $45,000 right now. I am in an all-day conference, so handle this via email only." The email address shows "CEO Name <ceo.office.update@gmail.com>".',
        artifactType: 'email',
        artifactContent: 'From: Tim Cook <ceo.office.update@gmail.com>\nSubject: Urgent - Confidential Wire\n\nPlease execute the attached wire instructions for the project escrow immediately. Keep this between us until press release.',
        isPhishing: true,
        redFlags: ['Free public email domain (@gmail.com) used for executive communication', 'Demands secrecy ("Keep this between us")', 'Pretext prevents verbal confirmation ("Handle via email only")'],
        explanation: 'This is a textbook CEO Fraud / BEC attack. Executive communications will never originate from free email services for official corporate financial transfers.',
        difficulty: 'Intermediate'
      }
    ]
  }
];

export const SAMPLE_EMAIL_TEMPLATES = [
  {
    id: 'sample-1',
    name: 'Microsoft 365 Password Expiration Lure',
    subject: 'Urgent: Your Microsoft 365 Password Expires Today',
    sender: 'security-notice@microsoft-cloud-auth.top',
    content: `From: Microsoft Security Team <security-notice@microsoft-cloud-auth.top>
Subject: Action Required: Your Microsoft 365 Password Expires in 2 Hours

Dear User,

Your organization's IT password policy requires you to update your credentials immediately. 
If you do not update your password within 2 hours, your access to Outlook, Teams, and SharePoint will be permanently locked out.

Click the secure link below to verify your current password and set a new one:
https://office365-password-reset-portal.xyz/auth?user=employee@company.com

Thank you,
Microsoft Cloud Security Operations`
  },
  {
    id: 'sample-2',
    name: 'PayPal Unauthorized Transaction Alert',
    subject: 'Security Alert: We detected an unauthorized login to your PayPal account',
    sender: 'service-update@paypal-security-update-center.top',
    content: `From: PayPal Support <service-update@paypal-security-update-center.top>
Subject: Unauthorized Transaction Alert - Case #PP-99412

Dear Customer,

We noticed a suspicious transaction of $499.00 USD authorized from an unrecognized IP address (Moscow, Russia).
If you did not make this purchase, please dispute and secure your account immediately:

https://paypal-security-update-center.top/login/index.php

Failure to confirm your identity within 24 hours will result in automatic billing authorization.

Sincerely,
PayPal Fraud Resolution Department`
  },
  {
    id: 'sample-3',
    name: 'USPS Missed Parcel Delivery SMS/Email',
    subject: 'USPS Delivery Failure - Package #US940284241US',
    sender: 'no-reply@usps-tracking-parcel-support.click',
    content: `From: USPS Tracking Alert <no-reply@usps-tracking-parcel-support.click>
Subject: Notice: Package delivery failed due to incomplete address

Your parcel with tracking code #US940284241US could not be delivered on August 25, 2026 due to an incorrect house number.
Please update your address details and pay the $1.95 redelivery processing fee within 48 hours:

https://usps-parcel-redelivery-notice.xyz/update-address

Items unclaimed after 48 hours will be returned to sender or destroyed.`
  },
  {
    id: 'sample-4',
    name: 'Legitimate IT Maintenance Announcement',
    subject: 'Scheduled Maintenance: Internal Intranet Maintenance Sunday 2AM-4AM',
    sender: 'it-support@company.internal',
    content: `From: Corporate IT Operations <it-support@company.internal>
Subject: Scheduled Maintenance: Sunday August 30, 2:00 AM - 4:00 AM EST

Hello Team,

This is a reminder that our internal Jira and Confluence servers will undergo routine patch maintenance this Sunday from 2:00 AM to 4:00 AM EST.
No action is required from employees. You do not need to change your password or log into any system.

If you have questions, please reach out via our official internal Slack channel #it-helpdesk.

Best regards,
Internal IT Team`
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'Critical Threat Intercepted',
    message: 'High-severity spearphishing domain "paypal-security-update-center.top" was blocked across all endpoints.',
    type: 'alert',
    severity: 'critical',
    timestamp: '10 mins ago',
    read: false,
    link: 'scanner'
  },
  {
    id: 'notif-2',
    title: 'New Incident Assigned',
    message: 'Incident INC-2026-8941 (Executive BEC Scam) assigned to Mayur Nikhade for SOC triage.',
    type: 'incident',
    severity: 'high',
    timestamp: '45 mins ago',
    read: false,
    link: 'soc'
  },
  {
    id: 'notif-3',
    title: 'Threat Intel Feeds Synced',
    message: '48,210 new malicious IOCs synchronized from OpenPhish and PhishTank feeds.',
    type: 'threat_intel',
    severity: 'low',
    timestamp: '2 hours ago',
    read: true,
    link: 'intel'
  }
];

export const SPOT_THE_PHISH_CHALLENGES = [
  {
    id: 'spot-1',
    scenarioTitle: 'Scenario 1: Executive Wire Transfer vs Official Internal Announcement',
    isOptionAPhish: true,
    optionA: {
      sender: 'ceo-office@company-leadership-updates.top',
      subject: 'URGENT & CONFIDENTIAL: Acquisition Wire Escrow Required Today',
      body: 'Hi Sarah,\nI am currently in an all-day confidential board meeting for an M&A transaction. I need you to immediately process an earnest money escrow wire of $148,500 to the attached account before 4 PM EST.\nPlease do not call my mobile as I cannot step away from the negotiation. Treat this with maximum priority.'
    },
    optionB: {
      sender: 'ceo-office@enterprise.corp',
      subject: 'Quarterly Town Hall & All-Hands Briefing Next Thursday',
      body: 'Team,\nPlease join us next Thursday at 11:00 AM EST for our Q3 Town Hall on our official Zoom bridge.\nWe will celebrate team milestones, discuss our product roadmap, and answer your submitted Slido questions.\nLooking forward to seeing everyone there.'
    },
    explanation: 'Option A is a textbook Business Email Compromise (BEC) attack. Red flags: (1) Urgent, high-pressure request involving financial wire transfer. (2) Unverified external domain (company-leadership-updates.top instead of enterprise.corp). (3) Deliberate obstruction of out-of-band verification ("Do not call my mobile").'
  },
  {
    id: 'spot-2',
    scenarioTitle: 'Scenario 2: Cloud Storage File Sharing Notification',
    isOptionAPhish: false,
    optionA: {
      sender: 'no-reply@sharepointonline.com',
      subject: 'Alex Rivera shared the file "Q3_Financial_Audit_Report.xlsx" with you',
      body: 'Alex Rivera (alex.r@enterprise.corp) has invited you to collaborate on OneDrive for Business.\n\nClick the link below to open the document directly inside Office 365 Online:\nhttps://enterprise-my.sharepoint.com/:x:/r/personal/alex_r_enterprise_corp/Doc1.xlsx'
    },
    optionB: {
      sender: 'notification-service@onedrive-secure-docs-access.xyz',
      subject: 'CRITICAL: You have 1 encrypted confidential document pending verification',
      body: 'A secure PDF document from Executive Management has arrived. Due to encryption policies, you must verify your corporate email password within 12 hours or the document will be permanently expunged:\n\nhttps://onedrive-secure-docs-access.xyz/login?ref=enterprise.corp'
    },
    explanation: 'Option B is a malicious credential harvesting lure. Notice the domain (onedrive-secure-docs-access.xyz), artificial 12-hour expiry panic, and request to re-enter email credentials on an untrusted third-party host.'
  }
];

export const MOCK_RECENT_SCANS = INITIAL_URL_SCANS;
export const MOCK_INCIDENTS = INITIAL_INCIDENTS;
export const MOCK_THREAT_REPORTS = INITIAL_THREAT_REPORTS;
export const MOCK_NOTIFICATIONS = INITIAL_NOTIFICATIONS;
export const MOCK_THREAT_FEEDS = INITIAL_THREAT_FEEDS;
export const MOCK_IOCS = INITIAL_IOCS;

export const QUIZ_QUESTIONS = [
  {
    id: 1,
    question: 'In the URL "https://login.microsoft.com.account-verify.top/auth/signin", what is the actual destination domain?',
    options: [
      'microsoft.com',
      'login.microsoft.com',
      'account-verify.top',
      'auth/signin'
    ],
    correctAnswer: 2,
    explanation: 'The true root domain is always the segment immediately preceding the first single slash (/). Attackers place "microsoft.com" as a subdomain to visually deceive users, but the browser will connect directly to "account-verify.top".'
  },
  {
    id: 2,
    question: 'Which of the following is a classic indicator of a Business Email Compromise (BEC) spearphishing attack?',
    options: [
      'An email containing a zip file with an .exe attachment',
      'An urgent request claiming to be from an executive demanding immediate payment while discouraging phone calls',
      'An email offering a 50% discount on consumer footwear',
      'A delivery notification with an official tracking code'
    ],
    correctAnswer: 1,
    explanation: 'BEC attacks rely on psychological authority, urgency, and isolating the victim from verifying the request through out-of-band channels like direct phone calls.'
  },
  {
    id: 3,
    question: 'Why are Quishing (QR Code Phishing) attacks increasingly dangerous in enterprise environments?',
    options: [
      'QR codes cannot be read by smart phones',
      'They bypass standard email text scanners and force users onto personal mobile devices with fewer corporate security controls',
      'QR codes automatically install rootkits on Windows servers',
      'They delete the recipient inbox upon opening'
    ],
    correctAnswer: 1,
    explanation: 'QR codes present as static images, bypassing traditional text-based email filters and moving victims from protected corporate workstations to unmanaged personal mobile devices.'
  },
  {
    id: 4,
    question: 'What is Shannon Entropy used for in URL threat analysis?',
    options: [
      'Measuring the download speed of the web server',
      'Quantifying character randomness and detecting obfuscated, machine-generated tokens or domain generation algorithms (DGA)',
      'Checking if the SSL certificate has expired',
      'Translating non-English text to English'
    ],
    correctAnswer: 1,
    explanation: 'Shannon Entropy measures informational randomness. High entropy values (above 4.5) often indicate randomized hashes, DGA domains, or obfuscated payload parameters.'
  },
  {
    id: 5,
    question: 'What is the most secure response when receiving an unexpected request to change supplier banking details?',
    options: [
      'Reply directly to the email asking if it is genuine',
      'Approve the payment if the invoice has a realistic company logo',
      'Perform out-of-band verification via a known, pre-established official phone number or trusted directory',
      'Forward the email to all colleagues for advice'
    ],
    correctAnswer: 2,
    explanation: 'Always verify bank account changes through a trusted, pre-existing out-of-band channel (e.g. verified phone number from contracts), never by replying to the email itself.'
  }
];

