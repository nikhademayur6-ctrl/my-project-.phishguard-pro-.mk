import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { UrlScanner } from './components/UrlScanner';
import { ScanHistory } from './components/ScanHistory';
import { EmailAnalyzer } from './components/EmailAnalyzer';
import { QrScanner } from './components/QrScanner';
import { DomainIntelComponent } from './components/DomainIntel';
import { TyposquattingDetector } from './components/TyposquattingDetector';
import { FileSafetyScanner } from './components/FileSafetyScanner';
import { ThreatIntelCenter } from './components/ThreatIntelCenter';
import { SocMode } from './components/SocMode';
import { IncidentReporting } from './components/IncidentReporting';
import { EducationCenter } from './components/EducationCenter';
import { BrowserShield } from './components/BrowserShield';
import { AdminPanel } from './components/AdminPanel';
import { LandingPage } from './components/LandingPage';
import { ReportModal } from './components/ReportModal';
import { FalsePositiveModal } from './components/FalsePositiveModal';
import { SettingsModal } from './components/SettingsModal';

import {
  saveScanToFirestore,
  deleteScanFromFirestore,
  clearAllScansFromFirestore,
  subscribeToScans,
  saveIncidentToFirestore,
  updateIncidentStatusInFirestore,
  addIncidentNoteInFirestore,
  subscribeToIncidents,
  saveReportToFirestore,
  subscribeToReports,
  saveIocToFirestore,
  subscribeToIocs
} from './lib/firebase';

import {
  UrlAnalysisResult,
  EmailAnalysisResult,
  Incident,
  ThreatReport,
  DomainIntel,
  UserRole,
  NotificationItem,
  ThreatIntelFeed,
  IOCItem,
  IncidentStatus
} from './types';

import {
  MOCK_RECENT_SCANS,
  MOCK_INCIDENTS,
  MOCK_THREAT_REPORTS,
  MOCK_NOTIFICATIONS,
  MOCK_THREAT_FEEDS,
  MOCK_IOCS
} from './data/mockData';

export function App() {
  const [activeView, setActiveView] = useState<string>('dashboard');
  const [currentRole, setCurrentRole] = useState<UserRole>('Security Analyst');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [firebaseConnected, setFirebaseConnected] = useState(true);

  // Theme Mode State ('dark' | 'light') with local persistence
  const [themeMode, setThemeMode] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem('phishguard_theme');
    if (saved === 'light' || saved === 'dark') return saved;
    return 'dark';
  });

  useEffect(() => {
    localStorage.setItem('phishguard_theme', themeMode);
    const root = document.documentElement;
    const body = document.body;
    if (themeMode === 'light') {
      root.setAttribute('data-theme', 'light');
      body.classList.add('light-mode');
      body.classList.remove('dark');
    } else {
      root.setAttribute('data-theme', 'dark');
      body.classList.remove('light-mode');
      body.classList.add('dark');
    }
  }, [themeMode]);

  const toggleThemeMode = () => {
    setThemeMode(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Core Data States
  const [scans, setScans] = useState<UrlAnalysisResult[]>(MOCK_RECENT_SCANS);
  const [currentUrlResult, setCurrentUrlResult] = useState<UrlAnalysisResult | null>(MOCK_RECENT_SCANS[0]);
  const [currentEmailResult, setCurrentEmailResult] = useState<EmailAnalysisResult | null>(null);
  const [incidents, setIncidents] = useState<Incident[]>(MOCK_INCIDENTS);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [reports, setReports] = useState<ThreatReport[]>(MOCK_THREAT_REPORTS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(MOCK_NOTIFICATIONS);
  const [feeds] = useState<ThreatIntelFeed[]>(MOCK_THREAT_FEEDS);
  const [iocs, setIocs] = useState<IOCItem[]>(MOCK_IOCS);

  // Modals
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportTarget, setReportTarget] = useState('');
  const [reportType, setReportType] = useState<ThreatReport['type']>('URL');

  const [falsePositiveModalOpen, setFalsePositiveModalOpen] = useState(false);
  const [falsePositiveScan, setFalsePositiveScan] = useState<UrlAnalysisResult | null>(null);

  const [settingsModalOpen, setSettingsModalOpen] = useState(false);

  // Real-time Firestore Subscriptions & Initial Telemetry Sync
  useEffect(() => {
    // 1. Subscribe to real-time scans
    const unsubScans = subscribeToScans((cloudScans) => {
      if (cloudScans && cloudScans.length > 0) {
        setScans(prev => {
          const combined = [...cloudScans];
          prev.forEach(p => {
            if (!combined.some(c => c.id === p.id)) {
              combined.push(p);
            }
          });
          return combined;
        });
      }
    });

    // 2. Subscribe to real-time SOC incidents
    const unsubIncidents = subscribeToIncidents((cloudIncidents) => {
      if (cloudIncidents && cloudIncidents.length > 0) {
        setIncidents(prev => {
          const combined = [...cloudIncidents];
          prev.forEach(p => {
            if (!combined.some(c => c.id === p.id)) {
              combined.push(p);
            }
          });
          return combined;
        });
      }
    });

    // 3. Subscribe to real-time threat reports
    const unsubReports = subscribeToReports((cloudReports) => {
      if (cloudReports && cloudReports.length > 0) {
        setReports(prev => {
          const combined = [...cloudReports];
          prev.forEach(p => {
            if (!combined.some(c => c.id === p.id)) {
              combined.push(p);
            }
          });
          return combined;
        });
      }
    });

    // 4. Subscribe to IOCs
    const unsubIocs = subscribeToIocs((cloudIocs) => {
      if (cloudIocs && cloudIocs.length > 0) {
        setIocs(prev => {
          const combined = [...cloudIocs];
          prev.forEach(p => {
            if (!combined.some(c => c.id === p.id)) {
              combined.push(p);
            }
          });
          return combined;
        });
      }
    });

    // Fetch initial server telemetry
    fetch('/api/dashboard')
      .then(res => res.json())
      .then(data => {
        if (data.recentScans && data.recentScans.length > 0) {
          setScans(prev => {
            const merged = [...prev];
            data.recentScans.forEach((s: UrlAnalysisResult) => {
              if (!merged.some(m => m.id === s.id)) {
                merged.push(s);
              }
            });
            return merged;
          });
        }
      })
      .catch(err => {
        console.warn('Using local telemetry state:', err);
      });

    return () => {
      if (unsubScans) unsubScans();
      if (unsubIncidents) unsubIncidents();
      if (unsubReports) unsubReports();
      if (unsubIocs) unsubIocs();
    };
  }, []);

  // Handlers
  const handleAnalyzeUrl = async (url: string): Promise<UrlAnalysisResult | null> => {
    try {
      const res = await fetch('/api/analyze/url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      const data: UrlAnalysisResult = await res.json();
      setCurrentUrlResult(data);
      setScans(prev => [data, ...prev.filter(s => s.id !== data.id)]);

      // Save directly to Firebase Firestore
      saveScanToFirestore(data);

      // If high risk, generate notification
      if (data.riskScore >= 70) {
        const newNotif: NotificationItem = {
          id: Date.now().toString(),
          title: `High Threat Detected: ${data.domain}`,
          message: `Score ${data.riskScore}/100. Category: ${data.threatCategory}`,
          type: 'alert',
          severity: 'critical',
          timestamp: 'Just now',
          read: false,
          link: 'scanner'
        };
        setNotifications(prev => [newNotif, ...prev]);
      }
      return data;
    } catch (err) {
      console.error('URL analysis failed:', err);
      return null;
    }
  };

  const handleAnalyzeEmail = async (content: string, subject?: string, sender?: string): Promise<EmailAnalysisResult | null> => {
    try {
      const res = await fetch('/api/analyze/email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, subject, sender })
      });
      const data = await res.json();
      setCurrentEmailResult(data);
      return data;
    } catch (err) {
      console.error('Email analysis failed:', err);
      return null;
    }
  };

  const handleLookupDomain = async (domain: string): Promise<DomainIntel | null> => {
    try {
      const res = await fetch(`/api/intel/domain/${encodeURIComponent(domain)}`);
      const data = await res.json();
      return data;
    } catch (err) {
      console.error('Domain lookup failed:', err);
      return null;
    }
  };

  const handleCreateReport = async (reportData: Omit<ThreatReport, 'id' | 'createdAt' | 'status'>): Promise<ThreatReport> => {
    let ticket: ThreatReport;
    try {
      const res = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reportData)
      });
      ticket = await res.json();
    } catch (err) {
      ticket = {
        id: `REP-${Date.now().toString().slice(-4)}`,
        ...reportData,
        status: 'Under Review',
        createdAt: new Date().toLocaleString()
      };
    }
    setReports(prev => [ticket, ...prev]);
    // Persist to Firebase Firestore
    saveReportToFirestore(ticket);
    return ticket;
  };

  const handleUpdateIncidentStatus = async (id: string, status: IncidentStatus) => {
    try {
      await fetch(`/api/incidents/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
    } catch (err) {
      console.warn('Local update only:', err);
    }
    // Update Firebase Firestore
    updateIncidentStatusInFirestore(id, status);
    setIncidents(prev => prev.map(inc => inc.id === id ? { ...inc, status } : inc));
    if (selectedIncident && selectedIncident.id === id) {
      setSelectedIncident(prev => prev ? { ...prev, status } : null);
    }
  };

  const handleAddIncidentNote = async (id: string, note: string) => {
    const newTimeline = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleTimeString(),
      note,
      author: `${currentRole} (Mayur Nikhade)`
    };

    try {
      const res = await fetch(`/api/incidents/${id}/note`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ note, author: `${currentRole} (Mayur Nikhade)` })
      });
      const updated = await res.json();
      setIncidents(prev => prev.map(inc => inc.id === id ? updated : inc));
      setSelectedIncident(updated);
      addIncidentNoteInFirestore(id, updated.timeline);
    } catch (err) {
      const targetInc = incidents.find(i => i.id === id);
      const updatedTimeline = targetInc ? [newTimeline, ...targetInc.timeline] : [newTimeline];
      setIncidents(prev => prev.map(inc => inc.id === id ? { ...inc, timeline: updatedTimeline } : inc));
      if (selectedIncident && selectedIncident.id === id) {
        setSelectedIncident(prev => prev ? { ...prev, timeline: updatedTimeline } : null);
      }
      addIncidentNoteInFirestore(id, updatedTimeline);
    }
  };

  const handleCreateIncident = async (newInc: Omit<Incident, 'id' | 'createdAt' | 'updatedAt' | 'timeline'>) => {
    let created: Incident;
    try {
      const res = await fetch('/api/incidents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newInc)
      });
      created = await res.json();
    } catch (err) {
      created = {
        id: `INC-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        ...newInc,
        createdAt: new Date().toLocaleString(),
        updatedAt: new Date().toLocaleString(),
        timeline: [
          {
            id: '1',
            timestamp: new Date().toLocaleTimeString(),
            note: 'Incident registered in SOC queue',
            author: 'System Intake'
          }
        ]
      };
    }
    setIncidents(prev => [created, ...prev]);
    // Persist to Firebase Firestore
    saveIncidentToFirestore(created);
  };

  const handlePushScanToSoc = (scan: UrlAnalysisResult) => {
    handleCreateIncident({
      title: `Active Malicious Campaign: ${scan.domain}`,
      description: scan.aiExplanation.summary,
      severity: scan.riskScore >= 80 ? 'critical' : scan.riskScore >= 60 ? 'high' : 'medium',
      status: 'New',
      source: 'URL Scanner Heuristics',
      category: scan.threatCategory,
      assignedTo: 'Mayur Nikhade',
      iocs: [scan.domain, scan.url],
      riskScore: scan.riskScore,
      tags: ['Automated Triage', scan.threatCategory]
    });
    setActiveView('soc');
  };

  const handleAddIoc = (newIoc: Omit<IOCItem, 'id' | 'lastSeen'>) => {
    const item: IOCItem = {
      id: Date.now().toString(),
      ...newIoc,
      lastSeen: 'Just now'
    };
    setIocs([item, ...iocs]);
    // Persist to Firebase Firestore
    saveIocToFirestore(item);
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const handleQuickSearch = (query: string) => {
    handleAnalyzeUrl(query);
    setActiveView('scanner');
  };

  const openReportModal = (target: string, type: ThreatReport['type']) => {
    setReportTarget(target);
    setReportType(type);
    setReportModalOpen(true);
  };

  const openFalsePositiveModal = (scan: UrlAnalysisResult) => {
    setFalsePositiveScan(scan);
    setFalsePositiveModalOpen(true);
  };

  const handleDeepScanUrlFromEmail = (url: string) => {
    handleAnalyzeUrl(url);
    setActiveView('scanner');
  };

  const handleDeleteScan = async (id: string) => {
    setScans(prev => prev.filter(s => s.id !== id));
    await deleteScanFromFirestore(id);
    try {
      await fetch(`/api/scans/${id}`, { method: 'DELETE' });
    } catch (e) {
      console.warn('API delete scan error:', e);
    }
  };

  const handleClearAllScans = async () => {
    const currentScans = [...scans];
    setScans([]);
    await clearAllScansFromFirestore(currentScans);
    try {
      await fetch('/api/scans', { method: 'DELETE' });
    } catch (e) {
      console.warn('API clear scans error:', e);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0b10] text-[#e2e8f0] flex flex-col font-sans selection:bg-blue-500/30 selection:text-blue-200">
      {/* Top Navbar */}
      <Navbar
        currentRole={currentRole}
        setCurrentRole={setCurrentRole}
        notifications={notifications}
        markNotificationRead={markNotificationRead}
        onNavigate={setActiveView}
        activeView={activeView}
        onOpenSettings={() => setSettingsModalOpen(true)}
        onQuickSearch={handleQuickSearch}
        themeMode={themeMode}
        onToggleTheme={toggleThemeMode}
      />

      {/* Main Container */}
      {activeView === 'landing' ? (
        <LandingPage
          onLaunchApp={() => setActiveView('dashboard')}
          onQuickInspect={(url) => {
            handleAnalyzeUrl(url);
            setActiveView('scanner');
          }}
        />
      ) : (
        <div className="flex-1 flex overflow-hidden">
          {/* Collapsible Cybersecurity Sidebar */}
          <Sidebar
            activeView={activeView}
            onNavigate={setActiveView}
            currentRole={currentRole}
            collapsed={sidebarCollapsed}
            onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
            incidentCount={incidents.filter(i => i.status !== 'Closed').length}
            scanCount={scans.length}
          />

          {/* Dynamic Content View Area */}
          <div className="flex-1 flex flex-col min-w-0 overflow-hidden bg-[#0a0b10]">
            <main id="main-content-area" className="flex-1 overflow-y-auto bg-[#0a0b10] pb-6">
              {activeView === 'dashboard' && (
                <Dashboard
                  onNavigate={setActiveView}
                  recentScans={scans}
                  incidents={incidents}
                  onSelectScan={(scan) => {
                    setCurrentUrlResult(scan);
                    setActiveView('scanner');
                  }}
                  onSelectIncident={(inc) => {
                    setSelectedIncident(inc);
                    setActiveView('soc');
                  }}
                />
              )}

              {activeView === 'scanner' && (
                <UrlScanner
                  onAnalyzeUrl={handleAnalyzeUrl}
                  currentResult={currentUrlResult}
                  onOpenReportModal={openReportModal}
                  onOpenFalsePositiveModal={openFalsePositiveModal}
                  onPushToSoc={handlePushScanToSoc}
                  onNavigateToHistory={() => setActiveView('history')}
                />
              )}

              {activeView === 'history' && (
                <ScanHistory
                  scans={scans}
                  onSelectScan={(scan) => {
                    setCurrentUrlResult(scan);
                    setActiveView('scanner');
                  }}
                  onDeleteScan={handleDeleteScan}
                  onClearAllScans={handleClearAllScans}
                  onPushToSoc={handlePushScanToSoc}
                  onOpenReportModal={openReportModal}
                  onOpenFalsePositiveModal={openFalsePositiveModal}
                  onQuickScan={(url) => {
                    handleAnalyzeUrl(url);
                    setActiveView('scanner');
                  }}
                />
              )}

              {activeView === 'email' && (
                <EmailAnalyzer
                  onAnalyzeEmail={handleAnalyzeEmail}
                  currentResult={currentEmailResult}
                  onDeepScanUrl={handleDeepScanUrlFromEmail}
                  onOpenReportModal={openReportModal}
                />
              )}

              {activeView === 'qr' && (
                <QrScanner
                  onAnalyzeUrl={handleAnalyzeUrl}
                  onOpenReportModal={openReportModal}
                />
              )}

              {activeView === 'domain' && (
                <DomainIntelComponent
                  onLookupDomain={handleLookupDomain}
                />
              )}

              {activeView === 'typosquat' && (
                <TyposquattingDetector
                  onScanPermutation={(domain) => {
                    handleAnalyzeUrl(domain);
                    setActiveView('scanner');
                  }}
                />
              )}

              {activeView === 'file' && (
                <FileSafetyScanner />
              )}

              {activeView === 'intel' && (
                <ThreatIntelCenter
                  feeds={feeds}
                  iocs={iocs}
                  onAddIoc={handleAddIoc}
                />
              )}

              {activeView === 'soc' && (
                <SocMode
                  incidents={incidents}
                  onUpdateStatus={handleUpdateIncidentStatus}
                  onAddNote={handleAddIncidentNote}
                  onCreateIncident={handleCreateIncident}
                  selectedIncident={selectedIncident}
                  onSelectIncident={setSelectedIncident}
                />
              )}

              {activeView === 'reports' && (
                <IncidentReporting
                  reports={reports}
                  onSubmitReport={handleCreateReport}
                />
              )}

              {activeView === 'education' && (
                <EducationCenter />
              )}

              {activeView === 'browser' && (
                <BrowserShield />
              )}

              {activeView === 'admin' && (
                <AdminPanel />
              )}
            </main>

            {/* Elegant Dark Bottom App Footer */}
            <footer className="px-6 py-3 border-t border-[#262b3d] bg-[#141722] text-xs text-slate-400 flex flex-wrap items-center justify-between gap-2 shrink-0">
              <div className="flex items-center gap-3">
                <span className="font-medium text-slate-300">© 2026 PhishGuard Pro</span>
                <span className="text-slate-600">•</span>
                <span className="font-mono text-[11px] text-slate-400">v2.5.0 Enterprise Edition</span>
                <span className="text-slate-600">•</span>
                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  SOC Sentinel Active
                </span>
              </div>
              <div className="text-right text-xs">
                Created by <strong className="text-blue-400 font-medium">Mayur Nikhade</strong>
              </div>
            </footer>
          </div>
        </div>
      )}

      {/* Global Modals */}
      <ReportModal
        isOpen={reportModalOpen}
        onClose={() => setReportModalOpen(false)}
        targetInitial={reportTarget}
        typeInitial={reportType}
        onSubmitReport={handleCreateReport}
      />

      <FalsePositiveModal
        isOpen={falsePositiveModalOpen}
        onClose={() => setFalsePositiveModalOpen(false)}
        scan={falsePositiveScan}
        onSubmit={(id, reason) => {
          console.log(`False positive reported for ${id}: ${reason}`);
        }}
      />

      <SettingsModal
        isOpen={settingsModalOpen}
        onClose={() => setSettingsModalOpen(false)}
        currentRole={currentRole}
        setCurrentRole={setCurrentRole}
        themeMode={themeMode}
        setThemeMode={setThemeMode}
      />
    </div>
  );
}

export default App;

