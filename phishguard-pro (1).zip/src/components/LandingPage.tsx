import React, { useState } from 'react';
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  Link2,
  Mail,
  QrCode,
  Globe2,
  Flame,
  ArrowRight,
  Sparkles,
  Terminal,
  Cpu,
  Layers,
  Award,
  CheckCircle2,
  Lock,
  ExternalLink
} from 'lucide-react';

interface LandingPageProps {
  onLaunchApp: () => void;
  onQuickInspect: (url: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onLaunchApp,
  onQuickInspect
}) => {
  const [heroInput, setHeroInput] = useState('');

  const handleHeroSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (heroInput.trim()) {
      onQuickInspect(heroInput.trim());
    } else {
      onLaunchApp();
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0b10] text-[#e2e8f0] flex flex-col justify-between">
      {/* Hero Section */}
      <div className="relative overflow-hidden pt-12 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        {/* Background glow accents */}
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-40 right-10 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative text-center space-y-6 max-w-4xl mx-auto">
          {/* Creator Badge & Tagline */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#141722] border border-[#262b3d] text-xs font-mono text-slate-300 shadow-xl">
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
            <span>Created by <strong className="text-blue-400 font-semibold">Mayur Nikhade</strong></span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400">Enterprise AI Phishing Defense</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white leading-tight">
            Detect Phishing Before It Becomes a <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-sky-400">Breach.</span>
          </h1>

          <p className="text-base sm:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
            PhishGuard Pro pairs multi-layer heuristic algorithms, explainable AI, brand typosquatting radar, and domain reconnaissance to neutralize modern social engineering attacks.
          </p>

          {/* Instant Hero Scan Input */}
          <form onSubmit={handleHeroSubmit} className="max-w-2xl mx-auto pt-4">
            <div className="relative flex flex-col sm:flex-row items-stretch gap-2 p-2 rounded-2xl bg-[#141722] border border-[#262b3d] shadow-2xl">
              <div className="relative flex-1 flex items-center">
                <Link2 className="absolute left-4 w-5 h-5 text-slate-400" />
                <input
                  id="landing-hero-url-input"
                  type="text"
                  value={heroInput}
                  onChange={(e) => setHeroInput(e.target.value)}
                  placeholder="Paste suspicious URL (e.g. paypal-security-update.top)..."
                  className="w-full bg-transparent border-none pl-12 pr-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none font-mono"
                />
              </div>

              <button
                type="submit"
                className="flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm transition-all shadow-[0_0_25px_rgba(59,130,246,0.3)] shrink-0 cursor-pointer"
              >
                <ShieldCheck className="w-5 h-5" />
                Inspect Threat
              </button>
            </div>
          </form>

          <div className="flex items-center justify-center gap-6 pt-4 text-xs font-mono text-slate-400">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-blue-400" /> Zero-Trust Scoring
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-indigo-400" /> Gemini Explainable AI
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-blue-400" /> STIX 2.1 Threat Intel
            </span>
          </div>
        </div>
      </div>

      {/* Feature Capabilities Grid */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-12">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <div className="text-xs font-mono font-bold text-blue-400 uppercase">
            Comprehensive Defense Matrix
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white">
            Engineered for Modern Cyber Threat Vectors
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-3 shadow-lg hover:border-blue-500/40 transition-all">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Link2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Heuristic URL Inspection</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Extracts Shannon entropy, IDN homoglyphs, brand cloaking, suspicious TLDs, and query parameter obfuscation.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-3 shadow-lg hover:border-indigo-500/40 transition-all">
            <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Mail className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Email & BEC Analyzer</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Detects psychological urgency manipulation, executive impersonation (CEO fraud), and nested anchor links.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-3 shadow-lg hover:border-blue-500/40 transition-all">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <QrCode className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Quishing (QR Phishing) Defense</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Decodes QR payloads in a secure client-side sandbox and evaluates destination safety before execution.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-3 shadow-lg hover:border-indigo-500/40 transition-all">
            <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Globe2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Domain Intelligence & WHOIS</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Calculates domain age, flags newly registered domains (NRDs), verifies SPF/DMARC, and checks blacklist databases.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-3 shadow-lg hover:border-rose-500/40 transition-all">
            <div className="w-12 h-12 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <Flame className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">SOC Incident Operations</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Interactive Kanban triage queue, forensic investigation timelines, IOC extraction, and automated mitigation.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-3 shadow-lg hover:border-blue-500/40 transition-all">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Explainable AI Reasoning</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Powered by Google Gemini to provide clear, actionable explanations, evidence points, and MITRE ATT&CK techniques.
            </p>
          </div>
        </div>

        {/* CTA Launch Banner */}
        <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-[#141722] via-[#141722] to-[#1e293b]/70 border border-[#262b3d] flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left shadow-xl">
          <div className="space-y-1">
            <h3 className="text-xl sm:text-2xl font-bold text-white">
              Ready to fortify your organization against social engineering?
            </h3>
            <p className="text-xs sm:text-sm text-slate-400">
              Access the live enterprise SOC console and threat intelligence telemetry.
            </p>
          </div>

          <button
            onClick={onLaunchApp}
            className="px-8 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm transition-all shadow-[0_0_20px_rgba(59,130,246,0.3)] shrink-0 flex items-center gap-2 cursor-pointer"
          >
            Launch PhishGuard Pro <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-[#262b3d] py-8 px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-400 space-y-2 bg-[#0a0b10]">
        <div className="flex items-center justify-center gap-2 font-mono text-slate-300">
          <span>PhishGuard Pro Enterprise Security</span>
          <span>•</span>
          <span>Created by <strong className="text-blue-400 font-medium">Mayur Nikhade</strong></span>
        </div>
        <p className="text-[11px] text-slate-500">
          "Detect Phishing Before It Becomes a Breach." Designed with zero-trust defensive heuristics and explainable AI.
        </p>
      </footer>
    </div>
  );
};
