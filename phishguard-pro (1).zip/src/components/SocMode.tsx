import React, { useState } from 'react';
import {
  Flame,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Clock,
  User,
  Plus,
  Search,
  Filter,
  ArrowRight,
  CheckCircle2,
  XCircle,
  FileSpreadsheet,
  Terminal,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Layers,
  Tag
} from 'lucide-react';
import { Incident, IncidentStatus, SeverityLevel } from '../types';

interface SocModeProps {
  incidents: Incident[];
  onUpdateStatus: (id: string, status: IncidentStatus) => void;
  onAddNote: (id: string, note: string) => void;
  onCreateIncident: (incident: Omit<Incident, 'id' | 'createdAt' | 'updatedAt' | 'timeline'>) => void;
  selectedIncident: Incident | null;
  onSelectIncident: (incident: Incident | null) => void;
}

export const SocMode: React.FC<SocModeProps> = ({
  incidents,
  onUpdateStatus,
  onAddNote,
  onCreateIncident,
  selectedIncident,
  onSelectIncident
}) => {
  const [viewMode, setViewMode] = useState<'board' | 'table'>('board');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [newNoteText, setNewNoteText] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);

  // New Incident Form State
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newSeverity, setNewSeverity] = useState<SeverityLevel>('high');
  const [newCategory, setNewCategory] = useState('Brand Impersonation Phishing');
  const [newSource, setNewSource] = useState('SOC Manual Intake');
  const [newTarget, setNewTarget] = useState('');

  const filteredIncidents = incidents.filter(inc => {
    const matchSearch = inc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inc.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inc.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchSeverity = filterSeverity === 'all' || inc.severity === filterSeverity;
    return matchSearch && matchSeverity;
  });

  const statuses: IncidentStatus[] = ['New', 'Investigating', 'Contained', 'Resolved', 'Closed'];

  const getSeverityBadge = (sev: string) => {
    const s = (sev || '').toLowerCase();
    switch (s) {
      case 'critical':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      case 'high':
        return 'bg-orange-500/20 text-orange-300 border-orange-500/30';
      case 'medium':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      default:
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
    }
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onCreateIncident({
      title: newTitle,
      description: newDescription,
      severity: newSeverity,
      status: 'New',
      source: newSource,
      category: newCategory,
      assignedTo: 'Mayur Nikhade',
      iocs: newTarget ? [newTarget] : ['192.168.1.1', 'unknown-domain.xyz'],
      riskScore: newSeverity === 'critical' ? 95 : newSeverity === 'high' ? 80 : 50,
      tags: ['Manual Intake', 'SOC Triage']
    });

    setNewTitle('');
    setNewDescription('');
    setNewTarget('');
    setShowCreateModal(false);
  };

  const handleAddNoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedIncident || !newNoteText.trim()) return;
    onAddNote(selectedIncident.id, newNoteText.trim());
    setNewNoteText('');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30">
              SECURITY OPERATIONS CENTER (SOC)
            </span>
            <span className="text-xs text-slate-400 font-mono">Triage • Containment • Forensic Timeline</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
            <Flame className="w-7 h-7 text-rose-400" />
            Incident Response & Threat Queue
          </h1>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <button
            id="soc-create-incident-btn"
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-all shadow-[0_0_15px_rgba(244,63,94,0.25)] cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Create Incident
          </button>
        </div>
      </div>

      {/* Controls Bar: Search & Filter */}
      <div className="p-4 rounded-xl bg-[#141722] border border-[#262b3d] flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            id="soc-incident-search"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search incident ID, keyword, or IOC..."
            className="w-full bg-[#0a0b10] border border-[#262b3d] focus:border-rose-500 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none font-mono"
          />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end text-xs">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">Severity:</span>
            <select
              value={filterSeverity}
              onChange={(e) => setFilterSeverity(e.target.value)}
              className="bg-[#0a0b10] border border-[#262b3d] text-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none"
            >
              <option value="all">All Severities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>

          <div className="flex items-center bg-[#0a0b10] border border-[#262b3d] rounded-lg p-0.5">
            <button
              onClick={() => setViewMode('board')}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                viewMode === 'board' ? 'bg-[#1c2132] text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Kanban Board
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                viewMode === 'table' ? 'bg-[#1c2132] text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              List View
            </button>
          </div>
        </div>
      </div>

      {/* Kanban Board View */}
      {viewMode === 'board' ? (
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {statuses.map(status => {
            const columnIncidents = filteredIncidents.filter(i => i.status === status);
            return (
              <div
                key={status}
                className="bg-[#141722] border border-[#262b3d] rounded-2xl p-3.5 space-y-3 min-h-[480px] flex flex-col shadow-lg"
              >
                {/* Column Header */}
                <div className="flex items-center justify-between pb-2 border-b border-[#262b3d]">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${
                      status === 'New' ? 'bg-rose-400' : status === 'Investigating' ? 'bg-amber-400' : status === 'Contained' ? 'bg-blue-400' : 'bg-emerald-400'
                    }`} />
                    <span className="font-mono text-xs font-bold text-slate-200 uppercase">{status}</span>
                  </div>
                  <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full bg-[#0a0b10] border border-[#262b3d] text-slate-400">
                    {columnIncidents.length}
                  </span>
                </div>

                {/* Cards in Column */}
                <div className="space-y-2.5 flex-1 overflow-y-auto">
                  {columnIncidents.map(inc => (
                    <div
                      key={inc.id}
                      onClick={() => onSelectIncident(inc)}
                      className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] hover:border-rose-500/50 hover:shadow-lg cursor-pointer transition-all space-y-2.5 group"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-slate-400 font-bold">{inc.id}</span>
                        <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-bold uppercase border ${getSeverityBadge(inc.severity)}`}>
                          {inc.severity}
                        </span>
                      </div>

                      <div className="text-xs font-semibold text-white group-hover:text-rose-300 transition-colors line-clamp-2">
                        {inc.title}
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-[#262b3d] font-mono">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3 text-slate-400" />
                          {inc.assignedTo}
                        </span>
                        <span className="text-rose-400 font-bold">{inc.riskScore}/100</span>
                      </div>
                    </div>
                  ))}

                  {columnIncidents.length === 0 && (
                    <div className="h-32 flex items-center justify-center text-[11px] text-slate-600 font-mono italic">
                      Empty queue
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* List View */
        <div className="rounded-2xl bg-[#141722] border border-[#262b3d] overflow-hidden shadow-xl">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#262b3d] text-slate-400 font-mono bg-[#0a0b10]/60">
                <th className="py-3 px-4">Incident ID</th>
                <th className="py-3 px-4">Title & Details</th>
                <th className="py-3 px-4">Severity</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Assignee</th>
                <th className="py-3 px-4 text-right">Risk Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#262b3d]/60">
              {filteredIncidents.map(inc => (
                <tr
                  key={inc.id}
                  onClick={() => onSelectIncident(inc)}
                  className="hover:bg-[#1c2132]/40 cursor-pointer transition-colors"
                >
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-300">{inc.id}</td>
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-white">{inc.title}</div>
                    <div className="text-slate-400 text-[11px] truncate max-w-md">{inc.description}</div>
                  </td>
                  <td className="py-3.5 px-4 font-mono">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${getSeverityBadge(inc.severity)}`}>
                      {inc.severity}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-mono">
                    <span className="px-2 py-0.5 rounded text-[11px] bg-[#0a0b10] border border-[#262b3d] text-slate-300">
                      {inc.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-300">{inc.assignedTo}</td>
                  <td className="py-3.5 px-4 text-right font-mono font-bold text-rose-400">
                    {inc.riskScore}/100
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Incident Detail Drawer / Modal */}
      {selectedIncident && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141722] border border-[#262b3d] rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-6 shadow-2xl">
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-[#262b3d]">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-rose-400 font-bold">{selectedIncident.id}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold uppercase border ${getSeverityBadge(selectedIncident.severity)}`}>
                    {selectedIncident.severity}
                  </span>
                </div>
                <h2 className="text-xl font-bold text-white">{selectedIncident.title}</h2>
              </div>

              <button
                onClick={() => onSelectIncident(null)}
                className="p-1.5 rounded-lg bg-[#0a0b10] border border-[#262b3d] text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Status Changer & Metadata */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
              <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                <div className="text-slate-400">Triage Status</div>
                <select
                  value={selectedIncident.status}
                  onChange={(e) => onUpdateStatus(selectedIncident.id, e.target.value as IncidentStatus)}
                  className="w-full bg-[#141722] border border-[#262b3d] text-white rounded p-1 text-xs focus:outline-none"
                >
                  {statuses.map(st => (
                    <option key={st} value={st}>{st}</option>
                  ))}
                </select>
              </div>

              <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                <div className="text-slate-400">Lead Analyst</div>
                <div className="text-white font-semibold">{selectedIncident.assignedTo}</div>
              </div>

              <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                <div className="text-slate-400">Threat Score</div>
                <div className="text-rose-400 font-bold text-sm">{selectedIncident.riskScore}/100</div>
              </div>
            </div>

            {/* Description & IOCs */}
            <div className="space-y-3">
              <div className="text-xs text-slate-400 font-mono uppercase">Incident Briefing</div>
              <p className="text-xs text-slate-200 leading-relaxed bg-[#0a0b10] p-3.5 rounded-xl border border-[#262b3d]">
                {selectedIncident.description}
              </p>

              <div className="text-xs text-slate-400 font-mono uppercase pt-2">Extracted Indicators of Compromise (IOCs)</div>
              <div className="flex flex-wrap gap-2">
                {selectedIncident.iocs.map((ioc, idx) => (
                  <span key={idx} className="text-xs font-mono px-2.5 py-1 rounded bg-[#0a0b10] text-rose-300 border border-[#262b3d]">
                    {ioc}
                  </span>
                ))}
              </div>
            </div>

            {/* Timeline & Notes */}
            <div className="space-y-3 pt-2 border-t border-[#262b3d]">
              <div className="text-xs font-semibold text-white font-mono uppercase flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                Forensic Investigation Timeline
              </div>

              <div className="space-y-2.5 max-h-48 overflow-y-auto">
                {selectedIncident.timeline.map(tl => (
                  <div key={tl.id} className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] text-xs space-y-0.5">
                    <div className="flex items-center justify-between text-slate-400 font-mono text-[10px]">
                      <span>{tl.author}</span>
                      <span>{tl.timestamp}</span>
                    </div>
                    <p className="text-slate-200">{tl.note}</p>
                  </div>
                ))}
              </div>

              {/* Add Note Form */}
              <form onSubmit={handleAddNoteSubmit} className="flex gap-2 pt-2">
                <input
                  type="text"
                  value={newNoteText}
                  onChange={(e) => setNewNoteText(e.target.value)}
                  placeholder="Append analyst note or action taken..."
                  className="flex-1 bg-[#0a0b10] border border-[#262b3d] rounded-xl px-3.5 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none font-mono focus:border-blue-500"
                />
                <button
                  type="submit"
                  disabled={!newNoteText.trim()}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-[#1c2132] text-white font-bold text-xs cursor-pointer transition-colors"
                >
                  Append Note
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Manual Create Incident Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141722] border border-[#262b3d] rounded-2xl max-w-xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#262b3d]">
              <h2 className="text-lg font-bold text-white">Create New SOC Security Incident</h2>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white cursor-pointer">✕</button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-medium">Incident Summary / Headline</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Executive Spoofing Attack targeting Finance Dept"
                  className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Severity</label>
                  <select
                    value={newSeverity}
                    onChange={(e) => setNewSeverity(e.target.value as SeverityLevel)}
                    className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 focus:outline-none font-mono focus:border-rose-500"
                  >
                    <option value="critical">Critical</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Threat Category</label>
                  <input
                    type="text"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 focus:outline-none font-mono focus:border-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Suspect Domain / Target / IOC</label>
                <input
                  type="text"
                  value={newTarget}
                  onChange={(e) => setNewTarget(e.target.value)}
                  placeholder="e.g. https://paypal-security-update.top"
                  className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 focus:outline-none font-mono focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Detailed Incident Description</label>
                <textarea
                  rows={3}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="Describe initial detection vectors, affected users, and scope..."
                  className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 focus:outline-none font-mono focus:border-rose-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] border border-[#262b3d] text-slate-300 text-xs font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  Create Incident
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
