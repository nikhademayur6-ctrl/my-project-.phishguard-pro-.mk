import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Lock,
  Plus,
  Trash2,
  Download,
  Upload,
  RefreshCw,
  ExternalLink,
  ArrowRight,
  Sparkles,
  Layers,
  AlertTriangle,
  Globe2,
  CheckCircle2
} from 'lucide-react';

interface BlocklistItem {
  id: string;
  domain: string;
  type: 'block' | 'allow';
  reason: string;
  addedAt: string;
}

export const BrowserShield: React.FC = () => {
  const [rules, setRules] = useState<BlocklistItem[]>([
    { id: '1', domain: '*.top', type: 'block', reason: 'High-risk malicious TLD policy', addedAt: '2026-03-01' },
    { id: '2', domain: '*.xyz', type: 'block', reason: 'Newly registered domain abuse', addedAt: '2026-03-01' },
    { id: '3', domain: 'paypal-security-update-center.top', type: 'block', reason: 'Active credential harvesting campaign', addedAt: '2026-03-02' },
    { id: '4', domain: 'microsoft.com', type: 'allow', reason: 'Enterprise SSO identity provider', addedAt: '2026-02-15' },
    { id: '5', domain: 'github.com', type: 'allow', reason: 'Trusted code repository', addedAt: '2026-02-15' }
  ]);

  const [newDomain, setNewDomain] = useState('');
  const [newType, setNewType] = useState<'block' | 'allow'>('block');
  const [newReason, setNewReason] = useState('');

  // Redirect chain simulator state
  const [simUrl, setSimUrl] = useState('https://bit.ly/3xSecUr3');
  const [simulating, setSimulating] = useState(false);
  const [chainResult, setChainResult] = useState<{ step: number; url: string; status: number; note: string }[] | null>(null);

  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDomain.trim()) return;

    const newRule: BlocklistItem = {
      id: Date.now().toString(),
      domain: newDomain.trim().toLowerCase(),
      type: newType,
      reason: newReason.trim() || (newType === 'block' ? 'Custom threat block' : 'Custom allow rule'),
      addedAt: new Date().toISOString().split('T')[0]
    };

    setRules([newRule, ...rules]);
    setNewDomain('');
    setNewReason('');
  };

  const handleDeleteRule = (id: string) => {
    setRules(rules.filter(r => r.id !== id));
  };

  const handleSimulateChain = () => {
    setSimulating(true);
    setTimeout(() => {
      setChainResult([
        { step: 1, url: 'https://bit.ly/3xSecUr3', status: 301, note: 'Shortened link redirect' },
        { step: 2, url: 'https://track.ad-analytics-redirect.click/hop?target=4892', status: 302, note: 'Ad tracker intermediary' },
        { step: 3, url: 'https://paypal-security-update-center.top/login/index.php', status: 200, note: 'Final destination: HIGH-RISK CREDENTIAL HARVESTER' }
      ]);
      setSimulating(false);
    }, 800);
  };

  const handleExport = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(rules, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `phishguard_rules_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
            PERIMETER PROTECTION SHIELD
          </span>
          <span className="text-xs text-slate-400 font-mono">DNS Sinkhole • Redirect Chain Inspector</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
          <ShieldCheck className="w-7 h-7 text-blue-400" />
          Browser Shield & Threat Protection Policies
        </h1>
        <p className="text-sm text-slate-400">
          Manage corporate allowlists, sinkhole malicious domains, and trace stealthy HTTP redirect hops used by evasion kits.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Rules Table & Creation Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Add Rule Card */}
          <div className="p-5 sm:p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4 shadow-xl">
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-blue-400" />
              Add Domain Filtering Rule
            </h2>

            <form onSubmit={handleAddRule} className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="sm:col-span-1">
                <label className="block text-slate-400 mb-1 font-medium">Policy Action</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as any)}
                  className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-xl p-2.5 text-slate-200 focus:outline-none font-mono focus:border-blue-500"
                >
                  <option value="block">BLOCK (Sinkhole)</option>
                  <option value="allow">ALLOW (Bypass)</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-400 mb-1 font-medium">Domain or Wildcard Pattern</label>
                <input
                  type="text"
                  required
                  value={newDomain}
                  onChange={(e) => setNewDomain(e.target.value)}
                  placeholder="e.g. *.top, phish-login.xyz, internal-portal.corp"
                  className="w-full bg-[#0a0b10] border border-[#262b3d] focus:border-blue-500 rounded-xl p-2.5 text-slate-200 focus:outline-none font-mono"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-400 mb-1 font-medium">Reason / Threat Context</label>
                <input
                  type="text"
                  value={newReason}
                  onChange={(e) => setNewReason(e.target.value)}
                  placeholder="e.g. Quishing campaign IOC, trusted vendor"
                  className="w-full bg-[#0a0b10] border border-[#262b3d] focus:border-blue-500 rounded-xl p-2.5 text-slate-200 focus:outline-none font-mono"
                />
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold transition-all shadow-[0_0_15px_rgba(59,130,246,0.25)] cursor-pointer"
                >
                  Apply Rule
                </button>
              </div>
            </form>
          </div>

          {/* Active Rules List */}
          <div className="p-5 sm:p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                  <Lock className="w-4 h-4 text-blue-400" />
                  Active Firewall & DNS Policies ({rules.length})
                </h2>
                <p className="text-xs text-slate-400">Enforced synchronously across enterprise perimeter</p>
              </div>

              <button
                onClick={handleExport}
                className="text-xs px-3 py-1.5 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] text-slate-300 border border-[#262b3d] flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                Export JSON
              </button>
            </div>

            <div className="divide-y divide-[#262b3d]/80">
              {rules.map(rule => (
                <div key={rule.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                  <div className="space-y-0.5 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.2 rounded font-mono font-bold text-[10px] uppercase border ${
                        rule.type === 'block'
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                      }`}>
                        {rule.type}
                      </span>
                      <span className="font-mono font-bold text-white truncate">{rule.domain}</span>
                    </div>
                    <p className="text-[11px] text-slate-400">{rule.reason}</p>
                  </div>

                  <button
                    onClick={() => handleDeleteRule(rule.id)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-[#1c2132] transition-colors shrink-0 cursor-pointer"
                    title="Remove rule"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Redirect Chain Simulator */}
        <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-5 shadow-xl flex flex-col justify-between">
          <div className="space-y-4">
            <div>
              <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                <Globe2 className="w-4 h-4 text-blue-400" />
                Redirect Chain Inspector
              </h2>
              <p className="text-xs text-slate-400">Trace multi-hop redirects and shorteners</p>
            </div>

            <div className="space-y-2">
              <input
                type="text"
                value={simUrl}
                onChange={(e) => setSimUrl(e.target.value)}
                placeholder="https://short-link.co/..."
                className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-xl p-2.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-blue-500"
              />
              <button
                onClick={handleSimulateChain}
                disabled={simulating}
                className="w-full py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-[#1c2132] text-white font-bold text-xs transition-colors cursor-pointer"
              >
                {simulating ? 'Tracing Hops...' : 'Trace Redirect Path'}
              </button>
            </div>

            {chainResult && (
              <div className="space-y-2.5 pt-2 border-t border-[#262b3d]">
                <div className="text-[10px] font-mono uppercase text-slate-400 font-bold">
                  Detected HTTP Hops ({chainResult.length})
                </div>
                {chainResult.map(hop => (
                  <div key={hop.step} className="p-2.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] text-xs space-y-1">
                    <div className="flex items-center justify-between font-mono">
                      <span className="text-slate-400">Hop #{hop.step}</span>
                      <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                        hop.status === 200 ? 'bg-rose-950 text-rose-300' : 'bg-[#1c2132] text-slate-300'
                      }`}>
                        HTTP {hop.status}
                      </span>
                    </div>
                    <div className="font-mono text-slate-200 break-all text-[11px]">{hop.url}</div>
                    <div className="text-[10px] text-slate-400">{hop.note}</div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] text-[11px] text-slate-400">
            <strong>Sinkhole Status:</strong> 1,180,490 threat feeds synced with automatic DNS responses set to 0.0.0.0.
          </div>
        </div>
      </div>
    </div>
  );
};
