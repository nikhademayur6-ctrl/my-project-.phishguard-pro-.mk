import React, { useState } from 'react';
import {
  Terminal,
  Globe2,
  Download,
  Plus,
  Search,
  CheckCircle2,
  RefreshCw,
  Layers,
  Database,
  ExternalLink,
  Flame,
  ShieldCheck,
  Filter,
  Copy,
  Check
} from 'lucide-react';
import { ThreatIntelFeed, IOCItem } from '../types';

interface ThreatIntelCenterProps {
  feeds: ThreatIntelFeed[];
  iocs: IOCItem[];
  onAddIoc: (ioc: Omit<IOCItem, 'id' | 'lastSeen'>) => void;
}

export const ThreatIntelCenter: React.FC<ThreatIntelCenterProps> = ({
  feeds,
  iocs,
  onAddIoc
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [copied, setCopied] = useState(false);

  // New IOC State
  const [newVal, setNewVal] = useState('');
  const [newType, setNewType] = useState<IOCItem['type']>('Domain');
  const [newThreat, setNewThreat] = useState('Credential Harvesting Phish');
  const [newConfidence, setNewConfidence] = useState(90);

  const filteredIocs = iocs.filter(ioc => {
    const matchSearch = ioc.value.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ioc.threatType.toLowerCase().includes(searchQuery.toLowerCase());
    const matchType = typeFilter === 'all' || ioc.type === typeFilter;
    return matchSearch && matchType;
  });

  const handleExportStix = () => {
    const stixBundle = {
      type: "bundle",
      id: `bundle--${Date.now()}`,
      spec_version: "2.1",
      objects: filteredIocs.map(ioc => ({
        type: "indicator",
        id: `indicator--${ioc.id}`,
        created: new Date().toISOString(),
        name: ioc.threatType,
        pattern_type: "stix",
        pattern: `[${ioc.type.toLowerCase()}-addr:value = '${ioc.value}']`,
        confidence: ioc.confidence
      }))
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(stixBundle, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `phishguard_stix_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVal.trim()) return;

    onAddIoc({
      type: newType,
      value: newVal.trim(),
      threatType: newThreat.trim(),
      confidence: newConfidence,
      source: 'SOC Analyst Manual Submission',
      tags: ['Manual', 'Threat Hunting']
    });

    setNewVal('');
    setShowAddModal(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
              GLOBAL THREAT INTELLIGENCE
            </span>
            <span className="text-xs text-slate-400 font-mono">1.18M Indicators Synced</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
            <Terminal className="w-7 h-7 text-blue-400" />
            Threat Intel Feeds & IOC Repository
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-all shadow-[0_0_15px_rgba(59,130,246,0.25)] cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Custom IOC
          </button>
          <button
            onClick={handleExportStix}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#141722] hover:bg-[#1c2132] text-slate-200 border border-[#262b3d] text-xs font-medium transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            Export STIX 2.1 Bundle
          </button>
        </div>
      </div>

      {/* Live Feed Status Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {feeds.map(feed => (
          <div key={feed.id} className="p-4 rounded-xl bg-[#141722] border border-[#262b3d] space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-white truncate">{feed.name}</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </div>
            <div className="text-sm font-bold font-mono text-blue-400">{feed.indicatorsCount.toLocaleString()}</div>
            <div className="text-[10px] text-slate-400 font-mono">Sync: {feed.lastUpdated}</div>
          </div>
        ))}
      </div>

      {/* IOC Table & Search */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="ioc-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search IOC value, hash, or keyword..."
              className="w-full bg-[#0a0b10] border border-[#262b3d] focus:border-blue-500 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none font-mono"
            />
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Filter Type:</span>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="bg-[#0a0b10] border border-[#262b3d] text-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none"
            >
              <option value="all">All Types</option>
              <option value="Domain">Domain</option>
              <option value="URL">URL</option>
              <option value="IP">IP Address</option>
              <option value="SHA256">SHA-256</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#262b3d] text-slate-400 bg-[#0a0b10]/60">
                <th className="py-3 px-4">IOC Type</th>
                <th className="py-3 px-4">Indicator Value</th>
                <th className="py-3 px-4">Threat Classification</th>
                <th className="py-3 px-4">Confidence</th>
                <th className="py-3 px-4">Feed Source</th>
                <th className="py-3 px-4">Last Telemetry</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#262b3d]/60">
              {filteredIocs.map(ioc => (
                <tr key={ioc.id} className="hover:bg-[#1c2132]/40 transition-colors">
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-[#0a0b10] border border-[#262b3d] text-blue-300 font-bold text-[10px]">
                      {ioc.type}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-bold text-white break-all">{ioc.value}</td>
                  <td className="py-3 px-4 text-slate-300">{ioc.threatType}</td>
                  <td className="py-3 px-4">
                    <span className="text-emerald-400 font-bold">{ioc.confidence}%</span>
                  </td>
                  <td className="py-3 px-4 text-slate-400 text-[11px]">{ioc.source}</td>
                  <td className="py-3 px-4 text-slate-500 text-[10px]">{ioc.lastSeen}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Custom IOC Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141722] border border-[#262b3d] rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#262b3d]">
              <h2 className="text-lg font-bold text-white">Add Threat Indicator (IOC)</h2>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white cursor-pointer">✕</button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Indicator Type</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 font-mono focus:border-blue-500 focus:outline-none"
                  >
                    <option value="Domain">Domain</option>
                    <option value="URL">URL</option>
                    <option value="IP">IP Address</option>
                    <option value="SHA256">SHA-256</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Confidence Rating (%)</label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={newConfidence}
                    onChange={(e) => setNewConfidence(Number(e.target.value))}
                    className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 font-mono focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Indicator Value</label>
                <input
                  type="text"
                  required
                  value={newVal}
                  onChange={(e) => setNewVal(e.target.value)}
                  placeholder="e.g. evil-banking-portal.xyz or 185.220.101.5"
                  className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 font-mono focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Threat Classification</label>
                <input
                  type="text"
                  value={newThreat}
                  onChange={(e) => setNewThreat(e.target.value)}
                  className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 font-mono focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] text-slate-300 text-xs font-medium border border-[#262b3d] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  Commit IOC
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
