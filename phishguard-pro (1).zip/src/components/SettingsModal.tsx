import React, { useState } from 'react';
import {
  Lock,
  ShieldCheck,
  Key,
  User,
  CheckCircle2,
  Cpu,
  Eye,
  Sliders,
  Sun,
  Moon,
  Palette
} from 'lucide-react';
import { UserRole, ThemeMode } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  currentRole,
  setCurrentRole,
  themeMode,
  setThemeMode
}) => {
  const [mfaEnabled, setMfaEnabled] = useState(true);
  const [sessionTimeout, setSessionTimeout] = useState('30');
  const [aiExplainability, setAiExplainability] = useState('Deep Forensic');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#141722] border border-[#262b3d] rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-[#262b3d]">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Lock className="w-4 h-4 text-blue-400" />
            Security & System Preferences
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white cursor-pointer">✕</button>
        </div>

        <div className="space-y-4 text-xs">
          {/* Appearance / Theme Mode Selection */}
          <div className="space-y-1.5">
            <label className="block text-slate-300 font-medium flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-blue-400" />
              Interface Theme & Visual Appearance
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                id="theme-select-dark"
                type="button"
                onClick={() => setThemeMode('dark')}
                className={`py-2.5 px-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  themeMode === 'dark'
                    ? 'bg-blue-500/20 text-blue-300 border-blue-500/50 font-bold shadow-sm'
                    : 'bg-[#0a0b10] text-slate-400 border-[#262b3d] hover:border-slate-600'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Moon className="w-4 h-4 text-indigo-400" />
                  <span>Dark Mode (SOC Night)</span>
                </div>
                {themeMode === 'dark' && <CheckCircle2 className="w-4 h-4 text-blue-400" />}
              </button>

              <button
                id="theme-select-light"
                type="button"
                onClick={() => setThemeMode('light')}
                className={`py-2.5 px-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  themeMode === 'light'
                    ? 'bg-blue-500/20 text-blue-300 border-blue-500/50 font-bold shadow-sm'
                    : 'bg-[#0a0b10] text-slate-400 border-[#262b3d] hover:border-slate-600'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span>Light Mode (Clean Day)</span>
                </div>
                {themeMode === 'light' && <CheckCircle2 className="w-4 h-4 text-blue-400" />}
              </button>
            </div>
          </div>

          {/* Role Simulation */}
          <div className="space-y-1.5">
            <label className="block text-slate-300 font-medium">Simulated SOC Access Role (RBAC)</label>
            <div className="grid grid-cols-3 gap-2">
              {(['User', 'Security Analyst', 'Administrator'] as UserRole[]).map(r => (
                <button
                  key={r}
                  onClick={() => setCurrentRole(r)}
                  className={`py-2 px-2.5 rounded-lg border text-center font-medium transition-all cursor-pointer ${
                    currentRole === r
                      ? 'bg-blue-500/20 text-blue-300 border-blue-500/40 font-bold'
                      : 'bg-[#0a0b10] text-slate-400 border-[#262b3d] hover:border-slate-600'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* MFA Security */}
          <div className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="font-semibold text-white">FIDO2 / WebAuthn Hardware MFA</div>
              <p className="text-[11px] text-slate-400">Cryptographically enforce hardware key verification</p>
            </div>
            <button
              onClick={() => setMfaEnabled(!mfaEnabled)}
              className={`px-3 py-1 rounded-md text-[11px] font-mono font-bold uppercase transition-colors cursor-pointer ${
                mfaEnabled ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-[#141722] text-slate-400 border border-[#262b3d]'
              }`}
            >
              {mfaEnabled ? 'Active' : 'Disabled'}
            </button>
          </div>

          {/* AI Explainability Mode */}
          <div className="space-y-1.5">
            <label className="block text-slate-300 font-medium">Explainable AI Reasoning Mode</label>
            <select
              value={aiExplainability}
              onChange={(e) => setAiExplainability(e.target.value)}
              className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2 text-slate-200 focus:outline-none font-mono focus:border-blue-500"
            >
              <option value="Deep Forensic">Deep Forensic + MITRE ATT&CK Matrix</option>
              <option value="Executive Summary">Executive Briefing (Simplified)</option>
              <option value="Standard">Standard Heuristic Breakdown</option>
            </select>
          </div>

          {/* Identity & Attribution */}
          <div className="p-3 rounded-xl bg-[#0a0b10]/60 border border-[#262b3d]/80 text-[11px] text-slate-400 space-y-1">
            <div><strong>Application:</strong> PhishGuard Pro v2.5</div>
            <div><strong>Created by:</strong> <span className="text-blue-400 font-medium">Mayur Nikhade</span></div>
            <div><strong>Environment:</strong> Secure Container Gateway • Port 3000</div>
          </div>
        </div>

        <div className="flex justify-end pt-2 border-t border-[#262b3d]">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer transition-colors shadow-[0_0_15px_rgba(59,130,246,0.25)]"
          >
            Save & Close
          </button>
        </div>
      </div>
    </div>
  );
};
