import React, { useState } from 'react';
import { Flag, CheckCircle2, AlertTriangle } from 'lucide-react';
import { UrlAnalysisResult } from '../types';

interface FalsePositiveModalProps {
  isOpen: boolean;
  onClose: () => void;
  scan: UrlAnalysisResult | null;
  onSubmit: (id: string, reason: string) => void;
}

export const FalsePositiveModal: React.FC<FalsePositiveModalProps> = ({
  isOpen,
  onClose,
  scan,
  onSubmit
}) => {
  const [reason, setReason] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen || !scan) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return;
    onSubmit(scan.id, reason.trim());
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#141722] border border-[#262b3d] rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-[#262b3d]">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Flag className="w-4 h-4 text-amber-400" />
            Submit False Positive Dispute
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white cursor-pointer">✕</button>
        </div>

        {submitted ? (
          <div className="py-6 text-center space-y-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
            <div className="text-sm font-semibold text-white">Dispute Submitted for Review</div>
            <p className="text-xs text-slate-400">Security researchers will re-evaluate heuristic scores.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
            <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] font-mono space-y-1">
              <div className="text-slate-400">Target Evaluated Domain:</div>
              <div className="text-white font-bold break-all">{scan.domain}</div>
              <div className="text-amber-400">Assigned Score: {scan.riskScore}/100 ({scan.riskLevel})</div>
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-medium">
                Why is this evaluation incorrect?
              </label>
              <textarea
                rows={3}
                required
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Explain why this domain is legitimate (e.g. verified internal enterprise portal, approved vendor)..."
                className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 focus:outline-none font-mono focus:border-blue-500"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-[#262b3d]">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] border border-[#262b3d] text-slate-300 text-xs cursor-pointer transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!reason.trim()}
                className="px-5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:bg-[#1c2132] text-slate-950 font-bold text-xs cursor-pointer transition-colors"
              >
                Submit Dispute
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
