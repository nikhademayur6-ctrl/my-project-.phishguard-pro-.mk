import React from 'react';
import {
  LayoutDashboard,
  Link2,
  Mail,
  QrCode,
  Globe2,
  Copy,
  FileCheck2,
  Flame,
  AlertOctagon,
  FileSpreadsheet,
  GraduationCap,
  ShieldCheck,
  Sliders,
  Terminal,
  ChevronRight,
  UserCheck,
  History
} from 'lucide-react';
import { UserRole } from '../types';

interface SidebarProps {
  activeView: string;
  onNavigate: (view: string) => void;
  currentRole: UserRole;
  collapsed: boolean;
  onToggleCollapse: () => void;
  incidentCount: number;
  scanCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onNavigate,
  currentRole,
  collapsed,
  onToggleCollapse,
  incidentCount,
  scanCount = 0
}) => {
  const navItems = [
    { id: 'dashboard', label: 'SOC Dashboard', icon: LayoutDashboard, category: 'Core Defense' },
    { id: 'scanner', label: 'Advanced URL Scanner', icon: Link2, category: 'Core Defense', badge: 'AI' },
    { id: 'history', label: 'Scan History & Vault', icon: History, category: 'Core Defense', badge: scanCount > 0 ? `${scanCount}` : undefined },
    { id: 'email', label: 'Email & Message Analyzer', icon: Mail, category: 'Core Defense', badge: 'Linguistic' },
    { id: 'qr', label: 'QR Phishing (Quishing)', icon: QrCode, category: 'Core Defense' },
    { id: 'domain', label: 'Domain Intelligence', icon: Globe2, category: 'Intelligence' },
    { id: 'typosquat', label: 'Typosquatting & Brands', icon: Copy, category: 'Intelligence' },
    { id: 'file', label: 'File & Attachment Safety', icon: FileCheck2, category: 'Intelligence' },
    { id: 'intel', label: 'Threat Intel Feeds', icon: Terminal, category: 'Intelligence', badge: '6 Feeds' },
    { id: 'soc', label: 'SOC Incident Center', icon: Flame, category: 'Operations', badge: incidentCount > 0 ? `${incidentCount}` : undefined, badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30' },
    { id: 'reports', label: 'Incident Reporting', icon: FileSpreadsheet, category: 'Operations' },
    { id: 'education', label: 'Education & Quizzes', icon: GraduationCap, category: 'Awareness', badge: 'Training' },
    { id: 'browser', label: 'Browser Shield & Rules', icon: ShieldCheck, category: 'Awareness' },
  ];

  if (currentRole === 'Administrator' || currentRole === 'Security Analyst') {
    navItems.push({ id: 'admin', label: 'Admin & Detection Rules', icon: Sliders, category: 'Management', badge: 'Admin' });
  }

  // Group by category
  const categories = Array.from(new Set(navItems.map(i => i.category)));

  return (
    <aside
      id="main-sidebar"
      className={`bg-[#141722] border-r border-[#262b3d] transition-all duration-300 flex flex-col justify-between shrink-0 ${
        collapsed ? 'w-20' : 'w-64 lg:w-72'
      }`}
    >
      <div className="py-4 px-3 space-y-6 overflow-y-auto max-h-[calc(100vh-130px)]">
        {categories.map(category => (
          <div key={category} className="space-y-1">
            {!collapsed && (
              <div className="px-3 py-1 text-[11px] font-mono font-semibold tracking-wider text-slate-400 uppercase">
                {category}
              </div>
            )}
            <div className="space-y-0.5">
              {navItems
                .filter(i => i.category === category)
                .map(item => {
                  const Icon = item.icon;
                  const isActive = activeView === item.id;
                  return (
                    <button
                      key={item.id}
                      id={`sidebar-nav-${item.id}`}
                      onClick={() => onNavigate(item.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all group relative ${
                        isActive
                          ? 'bg-[#3b82f6]/15 text-blue-300 border border-[#3b82f6]/40 shadow-[0_0_12px_rgba(59,130,246,0.15)] font-semibold'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-[#1c2132] border border-transparent'
                      }`}
                      title={collapsed ? item.label : undefined}
                    >
                      <Icon
                        className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                          isActive ? 'text-blue-400' : 'text-slate-400 group-hover:text-slate-300'
                        }`}
                      />
                      {!collapsed && (
                        <div className="flex items-center justify-between flex-1 truncate">
                          <span className="truncate">{item.label}</span>
                          {item.badge && (
                            <span
                              className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold uppercase border ${
                                item.badgeColor || 'bg-blue-500/10 text-blue-400 border-blue-500/25'
                              }`}
                            >
                              {item.badge}
                            </span>
                          )}
                        </div>
                      )}
                      {isActive && (
                        <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-[#3b82f6] rounded-r" />
                      )}
                    </button>
                  );
                })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer Creator Attribution Box */}
      <div className="p-3 border-t border-[#262b3d] bg-[#0a0b10]/70">
        {!collapsed ? (
          <div className="p-3 rounded-xl bg-gradient-to-br from-[#141722] via-[#141722] to-[#1e293b]/50 border border-[#262b3d] text-xs">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-mono text-blue-400 uppercase font-semibold">PhishGuard Pro</span>
              <span className="text-[10px] text-slate-400 font-mono">v2.5</span>
            </div>
            <p className="text-[11px] text-slate-300 font-medium">Created by <strong className="text-blue-400">Mayur Nikhade</strong></p>
            <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
              Detect Phishing Before It Becomes a Breach.
            </p>
          </div>
        ) : (
          <div className="text-center py-2">
            <div className="w-8 h-8 mx-auto rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-[10px] font-mono text-blue-400 font-bold">
              PG
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
