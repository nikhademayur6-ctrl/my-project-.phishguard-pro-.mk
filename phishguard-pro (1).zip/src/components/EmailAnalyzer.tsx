import React, { useState } from 'react';
import {
  Mail,
  Shield,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Sparkles,
  RefreshCw,
  Copy,
  Check,
  ExternalLink,
  FileText,
  Paperclip,
  ArrowRight,
  Info,
  CheckCircle2,
  AlertOctagon,
  FileSpreadsheet
} from 'lucide-react';
import { EmailAnalysisResult, RiskLevel } from '../types';
import { SAMPLE_EMAIL_TEMPLATES } from '../data/mockData';

interface EmailAnalyzerProps {
  onAnalyzeEmail: (content: string, subject?: string, sender?: string) => Promise<EmailAnalysisResult | null>;
  currentResult: EmailAnalysisResult | null;
  onDeepScanUrl: (url: string) => void;
  onOpenReportModal: (target: string, type: 'Email') => void;
}

export const EmailAnalyzer: React.FC<EmailAnalyzerProps> = ({
  onAnalyzeEmail,
  currentResult,
  onDeepScanUrl,
  onOpenReportModal
}) => {
  const [content, setContent] = useState('');
  const [subject, setSubject] = useState('');
  const [sender, setSender] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleTemplateSelect = (template: typeof SAMPLE_EMAIL_TEMPLATES[0]) => {
    setSubject(template.subject);
    setSender(template.sender);
    setContent(template.content);
    onAnalyzeEmail(template.content, template.subject, template.sender);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    setLoading(true);
    try {
      await onAnalyzeEmail(content.trim(), subject.trim(), sender.trim());
    } finally {
      setLoading(false);
    }
  };

  const getRiskColor = (level: RiskLevel) => {
    switch (level) {
      case 'CRITICAL':
        return { text: 'text-rose-400', bg: 'bg-rose-500/20', border: 'border-rose-500/30' };
      case 'HIGH RISK':
        return { text: 'text-orange-400', bg: 'bg-orange-500/20', border: 'border-orange-500/30' };
      case 'SUSPICIOUS':
        return { text: 'text-amber-400', bg: 'bg-amber-500/20', border: 'border-amber-500/30' };
      case 'LOW RISK':
        return { text: 'text-blue-400', bg: 'bg-blue-500/20', border: 'border-blue-500/30' };
      default:
        return { text: 'text-emerald-400', bg: 'bg-emerald-500/20', border: 'border-emerald-500/30' };
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
            LINGUISTIC SOCIAL-ENGINEERING DETECTOR
          </span>
          <span className="text-xs text-slate-400 font-mono">NLP Urgency & Spoofing Heuristics</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
          <Mail className="w-7 h-7 text-blue-400" />
          Email & Message Threat Analyzer
        </h1>
        <p className="text-sm text-slate-400">
          Paste raw emails, SMS texts, chat messages, or notifications to detect urgency manipulation, executive spoofing (BEC), and malicious links.
        </p>
      </div>

      {/* Input Section */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-5 shadow-xl">
        {/* Sample Templates Bar */}
        <div>
          <div className="text-xs font-medium text-slate-400 mb-2">Load Real-World Phishing Simulations:</div>
          <div className="flex flex-wrap gap-2">
            {SAMPLE_EMAIL_TEMPLATES.map(tmpl => (
              <button
                key={tmpl.id}
                type="button"
                onClick={() => handleTemplateSelect(tmpl)}
                className="text-xs px-3 py-1.5 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] text-slate-300 border border-[#262b3d] hover:border-slate-600 transition-colors flex items-center gap-2 cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5 text-blue-400" />
                <span>{tmpl.name}</span>
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">
                Sender Email or Header (Optional)
              </label>
              <input
                id="email-sender-input"
                type="text"
                value={sender}
                onChange={(e) => setSender(e.target.value)}
                placeholder="e.g. security-alert@microsoft-auth.xyz"
                className="w-full bg-[#0a0b10] border border-[#262b3d] focus:border-blue-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">
                Subject Line (Optional)
              </label>
              <input
                id="email-subject-input"
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Action Required: Your Account Has Been Locked"
                className="w-full bg-[#0a0b10] border border-[#262b3d] focus:border-blue-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">
              Email / Message Body Content <span className="text-blue-400">*</span>
            </label>
            <textarea
              id="email-body-input"
              rows={6}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Paste email text, SMS message, Slack lure, or invoice details here..."
              className="w-full bg-[#0a0b10] border border-[#262b3d] focus:border-blue-500 rounded-xl p-3.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none font-mono leading-relaxed"
            />
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>Multi-layer linguistic NLP + Gemini AI reasoning</span>
            </div>

            <button
              id="email-submit-btn"
              type="submit"
              disabled={loading || !content.trim()}
              className="flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-semibold text-sm transition-all shadow-[0_0_20px_rgba(59,130,246,0.25)] cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Decomposing Message...
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  Inspect Message
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Analysis Result */}
      {currentResult && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-6 shadow-xl">
            {/* Header Verdict */}
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-6 border-b border-[#262b3d]">
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className={`text-xs px-3 py-1 rounded-md font-mono font-extrabold uppercase border ${getRiskColor(currentResult.riskLevel).bg} ${getRiskColor(currentResult.riskLevel).text} ${getRiskColor(currentResult.riskLevel).border}`}>
                    {currentResult.riskLevel}
                  </span>
                  <span className="text-xs px-2.5 py-0.5 rounded bg-[#0a0b10] text-slate-300 font-mono border border-[#262b3d]">
                    Category: {currentResult.threatCategory}
                  </span>
                </div>
                <h2 className="text-xl font-bold text-white">
                  {currentResult.subject || 'Analyzed Message Payload'}
                </h2>
                {currentResult.sender && (
                  <p className="text-xs text-slate-400 font-mono">
                    Sender: <span className="text-slate-200">{currentResult.sender}</span>
                  </p>
                )}
              </div>

              <div className="flex items-center gap-4 shrink-0">
                <div className="text-right">
                  <div className="text-3xl font-extrabold font-mono text-white">
                    {currentResult.riskScore}<span className="text-lg text-slate-500 font-normal">/100</span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    Confidence: {currentResult.confidence}%
                  </div>
                </div>

                <div className="w-14 h-14 rounded-xl bg-[#0a0b10] border border-[#262b3d] flex items-center justify-center">
                  {currentResult.riskScore >= 70 ? (
                    <Flame className="w-7 h-7 text-rose-400" />
                  ) : currentResult.riskScore >= 40 ? (
                    <AlertTriangle className="w-7 h-7 text-amber-400" />
                  ) : (
                    <ShieldCheck className="w-7 h-7 text-emerald-400" />
                  )}
                </div>
              </div>
            </div>

            {/* Indicator Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 text-xs font-mono">
              <div className={`p-2.5 rounded-lg border text-center ${
                currentResult.indicators.urgencyLanguage ? 'bg-rose-950/40 text-rose-300 border-rose-800/60' : 'bg-[#0a0b10] text-slate-500 border-[#262b3d]'
              }`}>
                Urgency Pressure
              </div>
              <div className={`p-2.5 rounded-lg border text-center ${
                currentResult.indicators.fearBasedLanguage ? 'bg-rose-950/40 text-rose-300 border-rose-800/60' : 'bg-[#0a0b10] text-slate-500 border-[#262b3d]'
              }`}>
                Fear Coercion
              </div>
              <div className={`p-2.5 rounded-lg border text-center ${
                currentResult.indicators.credentialRequest ? 'bg-rose-950/40 text-rose-300 border-rose-800/60' : 'bg-[#0a0b10] text-slate-500 border-[#262b3d]'
              }`}>
                Credential Demand
              </div>
              <div className={`p-2.5 rounded-lg border text-center ${
                currentResult.indicators.paymentRequest ? 'bg-amber-950/40 text-amber-300 border-amber-800/60' : 'bg-[#0a0b10] text-slate-500 border-[#262b3d]'
              }`}>
                Financial Solicitation
              </div>
              <div className={`p-2.5 rounded-lg border text-center ${
                currentResult.indicators.brandImpersonation ? 'bg-rose-950/40 text-rose-300 border-rose-800/60' : 'bg-[#0a0b10] text-slate-500 border-[#262b3d]'
              }`}>
                Brand Spoof
              </div>
              <div className={`p-2.5 rounded-lg border text-center ${
                currentResult.indicators.senderMismatch ? 'bg-rose-950/40 text-rose-300 border-rose-800/60' : 'bg-[#0a0b10] text-slate-500 border-[#262b3d]'
              }`}>
                Sender Domain Mismatch
              </div>
            </div>

            {/* Extracted URLs with Deep Scan Link */}
            {currentResult.extractedUrls.length > 0 && (
              <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-3">
                <div className="text-xs font-semibold text-white uppercase font-mono flex items-center justify-between">
                  <span>Extracted Hyperlinks ({currentResult.extractedUrls.length})</span>
                  <span className="text-[10px] text-slate-400 font-normal">Click to launch deep URL inspection</span>
                </div>
                <div className="space-y-2">
                  {currentResult.extractedUrls.map((u, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-[#141722] border border-[#262b3d] flex items-center justify-between gap-4">
                      <div className="space-y-0.5 min-w-0 flex-1">
                        <div className="font-mono text-xs text-white truncate">{u.url}</div>
                        {u.mismatch && (
                          <div className="text-[10px] text-amber-400 font-mono">
                            ⚠️ Deceptive anchor or high-risk domain
                          </div>
                        )}
                      </div>
                      <button
                        onClick={() => onDeepScanUrl(u.url)}
                        className="px-3 py-1.5 rounded-lg bg-blue-500/15 hover:bg-blue-500/25 text-blue-300 text-xs font-medium border border-blue-500/30 shrink-0 flex items-center gap-1.5 cursor-pointer"
                      >
                        Deep Inspect <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Suspicious Phrases & AI Explanation */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-3">
                <h3 className="text-xs font-semibold text-rose-400 uppercase font-mono flex items-center gap-2">
                  <AlertOctagon className="w-4 h-4" />
                  Flagged Phrases & Red Flags ({currentResult.suspiciousPhrases.length})
                </h3>
                {currentResult.suspiciousPhrases.length > 0 ? (
                  <div className="space-y-2.5">
                    {currentResult.suspiciousPhrases.map((p, idx) => (
                      <div key={idx} className="p-2.5 rounded-lg bg-[#141722] border border-[#262b3d] text-xs space-y-1">
                        <div className="font-mono font-semibold text-rose-300">"{p.phrase}"</div>
                        <div className="text-slate-400 text-[11px] leading-relaxed">{p.reason}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">No overt linguistic phishing triggers detected.</p>
                )}
              </div>

              {/* Safe Handling & Response Guidelines */}
              <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-3">
                <h3 className="text-xs font-semibold text-emerald-400 uppercase font-mono flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4" />
                  Safe Handling & Remediation Protocol
                </h3>
                <div className="space-y-2">
                  {currentResult.aiExplanation.safeHandlingInstructions.map((inst, idx) => (
                    <div key={idx} className="text-xs text-slate-300 flex items-start gap-2 leading-relaxed">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{inst}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-[#262b3d]">
                  <button
                    onClick={() => onOpenReportModal(currentResult.sender || 'Email Payload', 'Email')}
                    className="w-full py-2 rounded-lg bg-[#141722] hover:bg-[#1c2132] text-blue-300 border border-[#262b3d] text-xs font-medium transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    Submit to Incident Response Team
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
