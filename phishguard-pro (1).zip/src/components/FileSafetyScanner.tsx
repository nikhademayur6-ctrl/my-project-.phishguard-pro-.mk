import React, { useState, useRef } from 'react';
import {
  FileCheck2,
  Upload,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Flame,
  FileText,
  FileCode,
  FileSpreadsheet,
  Layers,
  Sparkles,
  RefreshCw,
  Copy,
  Check,
  CheckCircle2,
  XCircle,
  AlertOctagon
} from 'lucide-react';
import { FileAnalysisResult, RiskLevel } from '../types';

const SAMPLE_FILES = [
  { name: 'Overdue_Invoice_2026.pdf.exe', size: 1420000, type: 'Double Extension Executable', risk: 'CRITICAL' },
  { name: 'Wire_Transfer_Confirmation.docm', size: 850000, type: 'Macro-Enabled Document', risk: 'HIGH RISK' },
  { name: 'USPS_Tracking_Manifest.iso', size: 4500000, type: 'Disk Image Container', risk: 'HIGH RISK' },
  { name: 'Cybersecurity_Report_Whitepaper.pdf', size: 2100000, type: 'Benign Clean PDF', risk: 'SAFE' }
];

export const FileSafetyScanner: React.FC = () => {
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<FileAnalysisResult | null>(null);
  const [copied, setCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const simulateFileAnalysis = (fileName: string, fileSize: number) => {
    setAnalyzing(true);
    setTimeout(() => {
      const lower = fileName.toLowerCase();
      let riskLevel: RiskLevel = 'SAFE';
      let riskScore = 10;
      const flags: string[] = [];

      if (lower.includes('.pdf.exe') || lower.includes('.doc.exe') || lower.includes('.zip.exe')) {
        riskLevel = 'CRITICAL';
        riskScore = 95;
        flags.push('Deceptive double extension detected (.pdf.exe)');
        flags.push('Disguised binary executable attempting to masquerade as document');
        flags.push('High Shannon entropy (>7.2) indicating packed payload');
      } else if (lower.endsWith('.docm') || lower.endsWith('.xlsm')) {
        riskLevel = 'HIGH RISK';
        riskScore = 80;
        flags.push('VBA / Office Macro scripts embedded');
        flags.push('AutoOpen() / AutoExec execution hooks present');
        flags.push('Outbound PowerShell payload download triggers');
      } else if (lower.endsWith('.iso') || lower.endsWith('.vhd') || lower.endsWith('.img')) {
        riskLevel = 'HIGH RISK';
        riskScore = 75;
        flags.push('Mark-of-the-Web (MOTW) evasion container (ISO/VHD)');
        flags.push('Contains nested LNK shortcut targeting cmd.exe');
      } else if (lower.endsWith('.scr') || lower.endsWith('.bat') || lower.endsWith('.ps1')) {
        riskLevel = 'CRITICAL';
        riskScore = 90;
        flags.push('Direct script execution payload');
      } else {
        flags.push('Standard file header structure verified');
        flags.push('No suspicious macro triggers found');
        flags.push('Benign entropy profile (4.1)');
      }

      // Generate pseudo-hash
      const sha256 = Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
      const md5 = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('');

      setResult({
        fileName,
        fileSize: `${(fileSize / (1024 * 1024)).toFixed(2)} MB`,
        sha256,
        md5,
        entropy: riskScore > 50 ? 7.34 : 4.12,
        detectedFlags: flags,
        riskLevel,
        riskScore,
        recommendation: riskScore > 50
          ? 'DO NOT EXECUTE. Immediately isolate the workstation and quarantine this attachment in enterprise EDR.'
          : 'File heuristics indicate typical document structure. Standard precautions apply.'
      });
      setAnalyzing(false);
    }, 1000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      simulateFileAnalysis(file.name, file.size);
    }
  };

  const handleCopyHash = () => {
    if (!result) return;
    navigator.clipboard.writeText(`SHA256: ${result.sha256}\nMD5: ${result.md5}\nFile: ${result.fileName}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
            ATTACHMENT DEFENSE SANDBOX
          </span>
          <span className="text-xs text-slate-400 font-mono">Macro Inspector • Entropy • MOTW Evasion</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
          <FileCheck2 className="w-7 h-7 text-blue-400" />
          File & Attachment Safety Inspector
        </h1>
        <p className="text-sm text-slate-400">
          Inspect suspicious email attachments, double-extension payloads, macro-enabled spreadsheets, and ISO containers without executing code.
        </p>
      </div>

      {/* Upload Box */}
      <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-5 shadow-xl">
        <div
          onClick={() => fileInputRef.current?.click()}
          className="p-8 rounded-xl border-2 border-dashed border-[#262b3d] hover:border-blue-500 bg-[#0a0b10] hover:bg-[#10131d] cursor-pointer transition-all flex flex-col items-center justify-center text-center space-y-3 group"
        >
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            onChange={handleFileUpload}
          />
          <div className="w-14 h-14 rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
            <Upload className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <div className="text-sm font-semibold text-white">Select or Drag Suspicious Attachment</div>
            <p className="text-xs text-slate-400">Inspect .pdf, .docx, .zip, .exe, .iso, .vhd, .eml</p>
          </div>
          <button
            type="button"
            className="px-4 py-1.5 rounded-lg bg-[#141722] text-xs text-slate-200 border border-[#262b3d] group-hover:bg-[#1c2132] cursor-pointer"
          >
            Browse Local File
          </button>
        </div>

        {/* Sample File Presets */}
        <div className="pt-2 border-t border-[#262b3d]">
          <div className="text-xs font-medium text-slate-400 mb-2">Simulate Common Malicious Attachment Lures:</div>
          <div className="flex flex-wrap gap-2">
            {SAMPLE_FILES.map(f => (
              <button
                key={f.name}
                type="button"
                onClick={() => simulateFileAnalysis(f.name, f.size)}
                className="text-xs px-3 py-1.5 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] text-slate-300 border border-[#262b3d] hover:border-slate-600 transition-colors flex items-center gap-2 font-mono cursor-pointer"
              >
                <FileCode className="w-3.5 h-3.5 text-blue-400" />
                <span>{f.name}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded ${
                  f.risk === 'CRITICAL' ? 'bg-rose-950 text-rose-300' : f.risk === 'HIGH RISK' ? 'bg-orange-950 text-orange-300' : 'bg-emerald-950 text-emerald-300'
                }`}>
                  {f.risk}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Loading state */}
      {analyzing && (
        <div className="p-8 rounded-2xl bg-[#141722] border border-[#262b3d] text-center space-y-3 shadow-xl">
          <RefreshCw className="w-8 h-8 text-blue-400 animate-spin mx-auto" />
          <div className="text-sm font-semibold text-white">Extracting Attachment Telemetry & Hashes...</div>
          <p className="text-xs text-slate-400 font-mono">Parsing file headers, byte entropy, and macro triggers...</p>
        </div>
      )}

      {/* Result Card */}
      {result && !analyzing && (
        <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-6 shadow-xl">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-6 border-b border-[#262b3d]">
            <div className="space-y-1.5 flex-1 min-w-0">
              <div className="flex items-center gap-2.5">
                <span className={`text-xs px-3 py-1 rounded font-mono font-extrabold uppercase ${
                  result.riskScore >= 70
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : result.riskScore >= 40
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                }`}>
                  {result.riskLevel}
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded bg-[#0a0b10] text-slate-300 font-mono border border-[#262b3d]">
                  Entropy: {result.entropy}
                </span>
              </div>
              <h2 className="text-xl font-bold text-white font-mono break-all">{result.fileName}</h2>
              <p className="text-xs text-slate-400 font-mono">Size: {result.fileSize}</p>
            </div>

            <div className="flex items-center gap-4 shrink-0">
              <div className="text-right">
                <div className="text-3xl font-extrabold font-mono text-white">
                  {result.riskScore}<span className="text-lg text-slate-500 font-normal">/100</span>
                </div>
                <div className="text-[11px] text-slate-400 font-mono">Static Threat Score</div>
              </div>
              <div className="w-14 h-14 rounded-xl bg-[#0a0b10] border border-[#262b3d] flex items-center justify-center">
                {result.riskScore >= 70 ? (
                  <Flame className="w-7 h-7 text-rose-400" />
                ) : (
                  <ShieldCheck className="w-7 h-7 text-emerald-400" />
                )}
              </div>
            </div>
          </div>

          {/* Hashes Section */}
          <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-2.5 font-mono text-xs">
            <div className="flex items-center justify-between text-slate-400">
              <span>Cryptographic Hashes (IOCs)</span>
              <button
                onClick={handleCopyHash}
                className="flex items-center gap-1 text-blue-400 hover:text-blue-300 transition-colors cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy Hashes'}
              </button>
            </div>
            <div className="space-y-1">
              <div className="text-slate-300 break-all">
                <span className="text-slate-500">SHA-256: </span>{result.sha256}
              </div>
              <div className="text-slate-300 break-all">
                <span className="text-slate-500">MD5: </span>{result.md5}
              </div>
            </div>
          </div>

          {/* Flagged Observations & Recommendation */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-3">
              <h3 className="text-xs font-semibold text-rose-400 uppercase font-mono flex items-center gap-2">
                <ShieldAlert className="w-4 h-4" />
                Observed Static Heuristic Flags
              </h3>
              <ul className="space-y-2 text-xs text-slate-300">
                {result.detectedFlags.map((flag, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-rose-400 font-bold mt-0.5">•</span>
                    <span>{flag}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-3 flex flex-col justify-between">
              <div>
                <h3 className="text-xs font-semibold text-amber-400 uppercase font-mono flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  Sandbox Directive
                </h3>
                <p className="text-xs text-slate-200 mt-2 leading-relaxed">
                  {result.recommendation}
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-[#141722] border border-[#262b3d] text-[11px] text-slate-400">
                <strong>Quarantine Protocol:</strong> High-risk attachments should be purged from email gateways and quarantined across Microsoft Defender / CrowdStrike endpoints.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
