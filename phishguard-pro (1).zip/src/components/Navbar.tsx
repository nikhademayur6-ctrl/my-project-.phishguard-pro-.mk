import React, { useState } from 'react';
import {
  Shield,
  ShieldAlert,
  Bell,
  User,
  ExternalLink,
  ChevronDown,
  Lock,
  Radio,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Search,
  Database,
  Sun,
  Moon
} from 'lucide-react';
import { UserRole, NotificationItem, ThemeMode } from '../types';

interface NavbarProps {
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  notifications: NotificationItem[];
  markNotificationRead: (id: string) => void;
  onNavigate: (view: string) => void;
  activeView: string;
  onOpenSettings: () => void;
  onQuickSearch: (query: string) => void;
  themeMode: ThemeMode;
  onToggleTheme: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  setCurrentRole,
  notifications,
  markNotificationRead,
  onNavigate,
  activeView,
  onOpenSettings,
  onQuickSearch,
  themeMode,
  onToggleTheme
}) => {
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showNotifMenu, setShowNotifMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onQuickSearch(searchQuery.trim());
      setSearchQuery('');
    }
  };

  return (
    <header id="main-header" className="sticky top-0 z-40 bg-[#141722]/95 backdrop-blur-md border-b border-[#262b3d] px-4 lg:px-6 py-2.5">
      <div className="flex items-center justify-between gap-4">
        {/* Brand & Status */}
        <div className="flex items-center gap-3.5">
          <button
            id="brand-home-button"
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-2.5 text-left group focus:outline-none"
          >
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500/20 via-indigo-500/20 to-blue-700/30 border border-blue-500/40 group-hover:border-blue-400 transition-all shadow-[0_0_15px_rgba(59,130,246,0.18)]">
              <Shield className="w-5 h-5 text-blue-400 group-hover:scale-105 transition-transform" />
              <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping opacity-75" />
              <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight text-white group-hover:text-blue-300 transition-colors">
                  PhishGuard <span className="text-blue-400 font-extrabold text-xs px-1.5 py-0.5 rounded bg-blue-950/60 border border-blue-700/50 ml-0.5">PRO</span>
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-mono tracking-wider">
                DEFENSE POSTURE: <span className="text-emerald-400 font-semibold">ACTIVE</span>
              </p>
            </div>
          </button>

          <div className="hidden xl:flex items-center gap-2 pl-4 border-l border-[#262b3d] text-[11px] text-slate-400 font-mono">
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#0a0b10] border border-[#262b3d] text-slate-300">
              <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
              SOC Sensor: Synced
            </span>
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-300">
              <Database className="w-3 h-3 text-blue-400" />
              Firebase: Live
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400 text-xs">Created by <strong className="text-blue-400 font-medium">Mayur Nikhade</strong></span>
          </div>
        </div>

        {/* Global Quick Scan Search */}
        <form onSubmit={handleSearchSubmit} className="hidden md:flex flex-1 max-w-md mx-4">
          <div className="relative w-full">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="global-url-quick-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Quick inspect URL, domain, or IOC (e.g. login-verify.xyz)..."
              className="w-full bg-[#0a0b10] border border-[#262b3d] hover:border-slate-600 focus:border-blue-500 rounded-lg pl-9 pr-20 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none transition-all"
            />
            <button
              type="submit"
              className="absolute right-1.5 top-1/2 -translate-y-1/2 px-2.5 py-0.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-medium transition-colors shadow-sm cursor-pointer"
            >
              Inspect
            </button>
          </div>
        </form>

        {/* Right Controls */}
        <div className="flex items-center gap-2.5">
          {/* Public Landing Link */}
          <button
            id="nav-landing-page-btn"
            onClick={() => onNavigate('landing')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors border ${
              activeView === 'landing'
                ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                : 'bg-[#0a0b10] text-slate-300 hover:text-white border-[#262b3d] hover:border-slate-600'
            }`}
          >
            Public Portal
          </button>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              id="notifications-toggle-btn"
              onClick={() => setShowNotifMenu(!showNotifMenu)}
              className="relative p-2 rounded-lg bg-[#0a0b10] border border-[#262b3d] text-slate-400 hover:text-slate-200 hover:border-slate-600 transition-colors"
              title="Security Alerts"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center shadow-lg animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            {showNotifMenu && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-[#141722] border border-[#262b3d] rounded-xl shadow-2xl z-50 p-2 text-xs">
                <div className="flex items-center justify-between px-3 py-2 border-b border-[#262b3d]">
                  <div className="font-semibold text-slate-200 flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-blue-400" />
                    Security Event Alerts
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">{unreadCount} Unread</span>
                </div>

                <div className="divide-y divide-[#262b3d]/50 max-h-72 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <div className="py-6 text-center text-slate-500">No active alerts</div>
                  ) : (
                    notifications.map(n => (
                      <div
                        key={n.id}
                        onClick={() => {
                          markNotificationRead(n.id);
                          if (n.link) onNavigate(n.link);
                          setShowNotifMenu(false);
                        }}
                        className={`p-3 hover:bg-[#1c2132] cursor-pointer transition-colors ${
                          !n.read ? 'bg-[#1c2132]/60' : ''
                        }`}
                      >
                        <div className="flex items-start gap-2.5">
                          {n.severity === 'critical' ? (
                            <Flame className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                          ) : n.severity === 'high' ? (
                            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                          ) : (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                          )}
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <span className={`font-medium ${!n.read ? 'text-white' : 'text-slate-300'}`}>
                                {n.title}
                              </span>
                              <span className="text-[10px] text-slate-500">{n.timestamp}</span>
                            </div>
                            <p className="text-slate-400 text-[11px] mt-0.5 leading-relaxed">{n.message}</p>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Light / Dark Mode Toggle Button */}
          <button
            id="theme-mode-toggle-btn"
            onClick={onToggleTheme}
            className="p-2 rounded-lg bg-[#0a0b10] border border-[#262b3d] text-slate-300 hover:text-white hover:border-slate-500 transition-all cursor-pointer flex items-center justify-center shadow-sm"
            title={themeMode === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle Theme Mode"
          >
            {themeMode === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400 animate-in spin-in-90 duration-300" />
            ) : (
              <Moon className="w-4 h-4 text-blue-400 animate-in spin-in-90 duration-300" />
            )}
          </button>

          {/* Role Switcher */}
          <div className="relative">
            <button
              id="role-selector-button"
              onClick={() => setShowRoleMenu(!showRoleMenu)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0a0b10] border border-[#262b3d] hover:border-slate-600 text-xs text-slate-200 transition-colors"
            >
              <div className={`w-2 h-2 rounded-full ${
                currentRole === 'Administrator'
                  ? 'bg-rose-400'
                  : currentRole === 'Security Analyst'
                  ? 'bg-blue-400'
                  : 'bg-emerald-400'
              }`} />
              <span className="font-medium hidden sm:inline">{currentRole}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {showRoleMenu && (
              <div className="absolute right-0 mt-2 w-56 bg-[#141722] border border-[#262b3d] rounded-xl shadow-2xl z-50 p-1.5 text-xs">
                <div className="px-2.5 py-1.5 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  RBAC Role Simulator
                </div>
                {(['User', 'Security Analyst', 'Administrator'] as UserRole[]).map(role => (
                  <button
                    key={role}
                    onClick={() => {
                      setCurrentRole(role);
                      setShowRoleMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-colors ${
                      currentRole === role ? 'bg-blue-500/20 text-blue-300 font-medium' : 'text-slate-300 hover:bg-[#1c2132]'
                    }`}
                  >
                    <span>{role}</span>
                    {currentRole === role && <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />}
                  </button>
                ))}
                <div className="border-t border-[#262b3d] my-1 pt-1">
                  <button
                    onClick={() => {
                      setShowRoleMenu(false);
                      onOpenSettings();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-slate-300 hover:bg-[#1c2132] text-left"
                  >
                    <Lock className="w-3.5 h-3.5 text-slate-400" />
                    Security Settings & MFA
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
