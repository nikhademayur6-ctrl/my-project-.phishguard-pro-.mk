import React, { useState } from 'react';
import {
  Globe2,
  Search,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Server,
  Lock,
  Calendar,
  Layers,
  Activity,
  CheckCircle2,
  XCircle,
  ExternalLink,
  RefreshCw,
  Sparkles,
  Info
} from 'lucide-react';
import { DomainIntel } from '../types';

interface DomainIntelProps {
  onLookupDomain: (domain: string) => Promise<DomainIntel | null>;
}

const PRESET_DOMAINS = [
  { domain: 'paypal-security-update-center.top', label: 'Suspicious Spoof Domain', isRisk: true },
  { domain: 'microsoft.com', label: 'Legitimate Global Brand', isRisk: false },
  { domain: 'chase-security-verify.xyz', label: 'Newly Registered Phish', isRisk: true },
  { domain: 'github.com', label: 'Trusted Cloud Hub', isRisk: false }
];

export const DomainIntelComponent: React.FC<DomainIntelProps> = ({
  onLookupDomain
}) => {
  const [domainInput, setDomainInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [intelResult, setIntelResult] = useState<DomainIntel | null>(null);

  const handleSearch = async (d?: string) => {
    const target = d || domainInput;
    if (!target.trim()) return;

    setLoading(true);
    try {
      const res = await onLookupDomain(target.trim());
      setIntelResult(res);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
            DEEP RECONNAISSANCE ENGINE
          </span>
          <span className="text-xs text-slate-400 font-mono">WHOIS • DNS • TLS • Blacklist Feeds</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
          <Globe2 className="w-7 h-7 text-blue-400" />
          Domain Intelligence & Threat Profiler
        </h1>
        <p className="text-sm text-slate-400">
          Uncover newly registered domains (NRDs), hidden WHOIS privacy cloaks, DNS MX/SPF/DMARC configurations, and threat feed correlations.
        </p>
      </div>

      {/* Search Input & Quick Presets */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4 shadow-xl">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSearch();
          }}
          className="flex flex-col sm:flex-row items-stretch gap-3"
        >
          <div className="relative flex-1">
            <Globe2 className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="domain-intel-input"
              type="text"
              value={domainInput}
              onChange={(e) => setDomainInput(e.target.value)}
              placeholder="Enter domain or hostname (e.g. login-verify-bank.top or google.com)..."
              className="w-full bg-[#0a0b10] border border-[#262b3d] hover:border-slate-600 focus:border-blue-500 rounded-xl px-4 py-3 pl-11 text-sm text-slate-100 placeholder-slate-500 focus:outline-none font-mono transition-all"
            />
          </div>

          <button
            id="domain-intel-search-btn"
            type="submit"
            disabled={loading || !domainInput.trim()}
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-semibold text-sm transition-all shadow-[0_0_20px_rgba(59,130,246,0.25)] shrink-0 cursor-pointer"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Querying DNS & WHOIS...
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                Profile Domain
              </>
            )}
          </button>
        </form>

        <div className="pt-2 border-t border-[#262b3d]">
          <div className="text-xs font-medium text-slate-400 mb-2">Preset Intelligence Profiles:</div>
          <div className="flex flex-wrap gap-2">
            {PRESET_DOMAINS.map(p => (
              <button
                key={p.domain}
                type="button"
                onClick={() => {
                  setDomainInput(p.domain);
                  handleSearch(p.domain);
                }}
                className="text-xs px-3 py-1.5 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] text-slate-300 border border-[#262b3d] hover:border-slate-600 transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span className={`w-1.5 h-1.5 rounded-full ${p.isRisk ? 'bg-rose-400' : 'bg-emerald-400'}`} />
                <span className="font-mono">{p.domain}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Intel Result Card */}
      {intelResult && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-6 shadow-xl">
            {/* Header Verdict */}
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-6 border-b border-[#262b3d]">
              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className={`text-xs px-3 py-1 rounded font-mono font-extrabold uppercase ${
                    intelResult.riskScore >= 70
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      : intelResult.riskScore >= 40
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  }`}>
                    {intelResult.reputation} REPUTATION
                  </span>

                  {intelResult.domainAgeDays !== undefined && intelResult.domainAgeDays < 30 && (
                    <span className="text-xs px-2.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 font-mono flex items-center gap-1 font-bold">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      NEWLY REGISTERED DOMAIN (&lt;30d)
                    </span>
                  )}
                </div>

                <h2 className="text-2xl font-bold text-white font-mono">{intelResult.domain}</h2>
                <p className="text-xs text-slate-400 font-mono">
                  Registrar: <strong className="text-slate-200">{intelResult.registrar}</strong> | Country: <strong className="text-slate-200">{intelResult.country}</strong>
                </p>
              </div>

              <div className="flex items-center gap-4 shrink-0">
                <div className="text-right">
                  <div className="text-3xl font-extrabold font-mono text-white">
                    {intelResult.riskScore}<span className="text-lg text-slate-500 font-normal">/100</span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">Risk Index</div>
                </div>
                <div className="w-14 h-14 rounded-xl bg-[#0a0b10] border border-[#262b3d] flex items-center justify-center">
                  {intelResult.riskScore >= 70 ? (
                    <ShieldAlert className="w-7 h-7 text-rose-400" />
                  ) : intelResult.riskScore >= 40 ? (
                    <AlertTriangle className="w-7 h-7 text-amber-400" />
                  ) : (
                    <ShieldCheck className="w-7 h-7 text-emerald-400" />
                  )}
                </div>
              </div>
            </div>

            {/* WHOIS & Registration Timeline */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs">
              <div className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                <div className="text-slate-400 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-blue-400" />
                  Created / Registered Date
                </div>
                <div className="text-white font-bold">{intelResult.creationDate}</div>
                {intelResult.domainAgeDays && (
                  <div className="text-[11px] text-slate-400">({intelResult.domainAgeDays} days ago)</div>
                )}
              </div>

              <div className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                <div className="text-slate-400 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  Expiration Date
                </div>
                <div className="text-white font-bold">{intelResult.expirationDate}</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                <div className="text-slate-400 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  SSL Certificate CA
                </div>
                <div className="text-white font-bold truncate">{intelResult.sslIssuer || 'Self-Signed / Untrusted'}</div>
              </div>
            </div>

            {/* DNS Records Table */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold text-white uppercase font-mono flex items-center gap-2">
                  <Server className="w-4 h-4 text-blue-400" />
                  Resolved DNS Zone Records
                </h3>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead>
                    <tr className="border-b border-[#262b3d] text-slate-400">
                      <th className="py-2 px-3">Type</th>
                      <th className="py-2 px-3">Resolved Value</th>
                      <th className="py-2 px-3">TTL</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#262b3d]/60 text-slate-300">
                    {intelResult.dnsRecords.map((rec, idx) => (
                      <tr key={idx} className="hover:bg-[#1c2132]/40">
                        <td className="py-2.5 px-3 font-bold text-blue-400">{rec.type}</td>
                        <td className="py-2.5 px-3 break-all">{rec.value}</td>
                        <td className="py-2.5 px-3 text-slate-400">{rec.ttl}s</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Email Authentication Security (SPF / DMARC / MX) */}
            <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-3">
              <h3 className="text-xs font-semibold text-white uppercase font-mono flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Email Authenticity & Spoofing Resilience (SPF / DMARC)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-[#141722] border border-[#262b3d] flex items-center justify-between">
                  <span className="text-slate-300 font-mono">SPF Record (Sender Policy Framework)</span>
                  {intelResult.dnsRecords.some(r => r.type === 'TXT' && r.value.includes('v=spf1')) ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-1 font-mono">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Enforced
                    </span>
                  ) : (
                    <span className="text-rose-400 font-bold flex items-center gap-1 font-mono">
                      <XCircle className="w-3.5 h-3.5" /> Missing (Spoofable)
                    </span>
                  )}
                </div>

                <div className="p-3 rounded-lg bg-[#141722] border border-[#262b3d] flex items-center justify-between">
                  <span className="text-slate-300 font-mono">DMARC Policy Compliance</span>
                  {intelResult.dnsRecords.some(r => r.type === 'TXT' && r.value.includes('v=DMARC1')) ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-1 font-mono">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Configured
                    </span>
                  ) : (
                    <span className="text-amber-400 font-bold flex items-center gap-1 font-mono">
                      <AlertTriangle className="w-3.5 h-3.5" /> Not Found
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
