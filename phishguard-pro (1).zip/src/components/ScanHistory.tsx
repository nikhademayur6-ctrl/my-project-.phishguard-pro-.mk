import React, { useState, useMemo } from 'react';
import {
  History,
  Search,
  Filter,
  Download,
  Trash2,
  ExternalLink,
  Shield,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Flame,
  ArrowUpDown,
  FileSpreadsheet,
  CheckCircle2,
  Copy,
  Check,
  RefreshCw,
  Eye,
  Layers,
  Terminal,
  Flag,
  Globe2,
  Lock,
  Unlock,
  Server,
  Sparkles,
  ChevronRight,
  X,
  FileCode,
  Zap,
  Info
} from 'lucide-react';
import { UrlAnalysisResult, RiskLevel, ThreatCategory } from '../types';

interface ScanHistoryProps {
  scans: UrlAnalysisResult[];
  onSelectScan: (scan: UrlAnalysisResult) => void;
  onDeleteScan: (id: string) => void;
  onClearAllScans: () => void;
  onPushToSoc: (scan: UrlAnalysisResult) => void;
  onOpenReportModal: (target: string, type: 'URL') => void;
  onOpenFalsePositiveModal: (scan: UrlAnalysisResult) => void;
  onQuickScan: (url: string) => void;
}

export const ScanHistory: React.FC<ScanHistoryProps> = ({
  scans,
  onSelectScan,
  onDeleteScan,
  onClearAllScans,
  onPushToSoc,
  onOpenReportModal,
  onOpenFalsePositiveModal,
  onQuickScan
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRiskFilter, setSelectedRiskFilter] = useState<string>('ALL');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'highest_risk' | 'lowest_risk'>('newest');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedScanForModal, setSelectedScanForModal] = useState<UrlAnalysisResult | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [quickScanUrl, setQuickScanUrl] = useState('');
  const [activeModalTab, setActiveModalTab] = useState<'overview' | 'signals' | 'technical' | 'mitre'>('overview');

  // Stats calculation
  const stats = useMemo(() => {
    const total = scans.length;
    const criticalAndHigh = scans.filter(s => s.riskScore >= 60).length;
    const safeAndLow = scans.filter(s => s.riskScore < 40).length;
    const suspicious = scans.filter(s => s.riskScore >= 40 && s.riskScore < 60).length;
    const avgScore = total > 0 ? Math.round(scans.reduce((acc, s) => acc + s.riskScore, 0) / total) : 0;

    return { total, criticalAndHigh, safeAndLow, suspicious, avgScore };
  }, [scans]);

  // Categories present in the dataset
  const uniqueCategories = useMemo(() => {
    const cats = new Set<string>();
    scans.forEach(s => {
      if (s.threatCategory) cats.add(s.threatCategory);
    });
    return Array.from(cats);
  }, [scans]);

  // Filtering and sorting logic
  const filteredScans = useMemo(() => {
    return scans
      .filter(scan => {
        // Search filter
        if (searchTerm.trim()) {
          const term = searchTerm.toLowerCase();
          const matchesUrl = scan.url.toLowerCase().includes(term);
          const matchesDomain = scan.domain.toLowerCase().includes(term);
          const matchesCategory = (scan.threatCategory || '').toLowerCase().includes(term);
          const matchesBrand = (scan.targetBrand || '').toLowerCase().includes(term);
          const matchesSummary = (scan.aiExplanation?.summary || '').toLowerCase().includes(term);
          if (!matchesUrl && !matchesDomain && !matchesCategory && !matchesBrand && !matchesSummary) {
            return false;
          }
        }

        // Risk Level filter
        if (selectedRiskFilter !== 'ALL') {
          if (selectedRiskFilter === 'CRITICAL' && scan.riskScore < 80) return false;
          if (selectedRiskFilter === 'HIGH' && (scan.riskScore < 60 || scan.riskScore >= 80)) return false;
          if (selectedRiskFilter === 'SUSPICIOUS' && (scan.riskScore < 40 || scan.riskScore >= 60)) return false;
          if (selectedRiskFilter === 'SAFE' && scan.riskScore >= 40) return false;
        }

        // Category filter
        if (selectedCategoryFilter !== 'ALL' && scan.threatCategory !== selectedCategoryFilter) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') {
          return (b.timestamp || '').localeCompare(a.timestamp || '');
        }
        if (sortBy === 'oldest') {
          return (a.timestamp || '').localeCompare(b.timestamp || '');
        }
        if (sortBy === 'highest_risk') {
          return b.riskScore - a.riskScore;
        }
        if (sortBy === 'lowest_risk') {
          return a.riskScore - b.riskScore;
        }
        return 0;
      });
  }, [scans, searchTerm, selectedRiskFilter, selectedCategoryFilter, sortBy]);

  const handleCopyUrl = (scan: UrlAnalysisResult) => {
    navigator.clipboard.writeText(scan.url);
    setCopiedId(scan.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(filteredScans, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `phishguard-scan-history-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleExportCsv = () => {
    const headers = ["ID", "URL", "Domain", "Risk Score", "Risk Level", "Category", "Target Brand", "Timestamp"];
    const rows = filteredScans.map(s => [
      s.id,
      `"${s.url.replace(/"/g, '""')}"`,
      `"${s.domain}"`,
      s.riskScore,
      s.riskLevel,
      `"${s.threatCategory}"`,
      `"${s.targetBrand || 'N/A'}"`,
      `"${s.timestamp}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `phishguard-scan-history-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const handleQuickScanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickScanUrl.trim()) return;
    onQuickScan(quickScanUrl.trim());
    setQuickScanUrl('');
  };

  const getRiskBadge = (score: number, level: RiskLevel) => {
    if (score >= 80) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-rose-500/15 text-rose-300 border border-rose-500/30">
          <Flame className="w-3.5 h-3.5 text-rose-400" />
          {score}/100 • CRITICAL
        </span>
      );
    }
    if (score >= 60) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-orange-500/15 text-orange-300 border border-orange-500/30">
          <ShieldAlert className="w-3.5 h-3.5 text-orange-400" />
          {score}/100 • HIGH RISK
        </span>
      );
    }
    if (score >= 40) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
          {score}/100 • SUSPICIOUS
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
        {score}/100 • SAFE
      </span>
    );
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
              FORENSIC TELEMETRY VAULT
            </span>
            <span className="text-xs text-slate-400 font-mono">Cloud Synced with Firebase</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
            <History className="w-7 h-7 text-blue-400" />
            Scan History & Threat Vault
          </h1>
          <p className="text-sm text-slate-400">
            Audit, re-inspect, and investigate every historical URL analysis with comprehensive MITRE ATT&CK telemetry.
          </p>
        </div>

        {/* Header Action Buttons */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            id="export-json-btn"
            onClick={handleExportJson}
            disabled={filteredScans.length === 0}
            className="px-3.5 py-2 rounded-xl bg-[#141722] hover:bg-[#1c2132] disabled:opacity-50 border border-[#262b3d] text-slate-300 text-xs font-medium flex items-center gap-2 transition-colors cursor-pointer"
            title="Export filtered records as JSON"
          >
            <Download className="w-4 h-4 text-blue-400" />
            Export JSON
          </button>
          <button
            id="export-csv-btn"
            onClick={handleExportCsv}
            disabled={filteredScans.length === 0}
            className="px-3.5 py-2 rounded-xl bg-[#141722] hover:bg-[#1c2132] disabled:opacity-50 border border-[#262b3d] text-slate-300 text-xs font-medium flex items-center gap-2 transition-colors cursor-pointer"
            title="Export filtered records as CSV"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            Export CSV
          </button>
          {scans.length > 0 && (
            <button
              id="clear-all-scans-btn"
              onClick={() => setShowClearConfirm(true)}
              className="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs font-medium flex items-center gap-2 transition-colors cursor-pointer"
              title="Clear all stored scan history"
            >
              <Trash2 className="w-4 h-4 text-rose-400" />
              Clear History
            </button>
          )}
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[#141722] border border-[#262b3d] shadow-lg space-y-1">
          <div className="text-xs font-mono text-slate-400 uppercase">Total Scans Vaulted</div>
          <div className="text-2xl font-bold text-white font-mono flex items-center justify-between">
            {stats.total}
            <History className="w-5 h-5 text-blue-400" />
          </div>
          <p className="text-[11px] text-slate-400">Persisted locally and in Firestore</p>
        </div>

        <div className="p-4 rounded-2xl bg-[#141722] border border-[#262b3d] shadow-lg space-y-1">
          <div className="text-xs font-mono text-rose-400 uppercase">High & Critical Threats</div>
          <div className="text-2xl font-bold text-rose-400 font-mono flex items-center justify-between">
            {stats.criticalAndHigh}
            <Flame className="w-5 h-5 text-rose-400" />
          </div>
          <p className="text-[11px] text-slate-400">{stats.total > 0 ? Math.round((stats.criticalAndHigh / stats.total) * 100) : 0}% of all analyzed links</p>
        </div>

        <div className="p-4 rounded-2xl bg-[#141722] border border-[#262b3d] shadow-lg space-y-1">
          <div className="text-xs font-mono text-emerald-400 uppercase">Safe / Low Risk Passed</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono flex items-center justify-between">
            {stats.safeAndLow}
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
          </div>
          <p className="text-[11px] text-slate-400">Verified clean destinations</p>
        </div>

        <div className="p-4 rounded-2xl bg-[#141722] border border-[#262b3d] shadow-lg space-y-1">
          <div className="text-xs font-mono text-amber-400 uppercase">Average Risk Score</div>
          <div className="text-2xl font-bold text-amber-400 font-mono flex items-center justify-between">
            {stats.avgScore}/100
            <Sparkles className="w-5 h-5 text-amber-400" />
          </div>
          <p className="text-[11px] text-slate-400">Weighted heuristic calculation</p>
        </div>
      </div>

      {/* Quick Scan Input Box */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#141722] border border-[#262b3d] shadow-xl">
        <form onSubmit={handleQuickScanSubmit} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Globe2 className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="quick-scan-input"
              type="text"
              value={quickScanUrl}
              onChange={(e) => setQuickScanUrl(e.target.value)}
              placeholder="Quickly scan a new destination URL (e.g., https://paypal-security-auth.top/login)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono transition-colors"
            />
          </div>
          <button
            id="quick-scan-submit-btn"
            type="submit"
            disabled={!quickScanUrl.trim()}
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-[#1c2132] disabled:text-slate-600 text-white font-semibold text-xs transition-all shadow-[0_0_15px_rgba(59,130,246,0.25)] flex items-center justify-center gap-2 cursor-pointer shrink-0"
          >
            <Zap className="w-4 h-4" />
            Analyze & Log
          </button>
        </form>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#141722] border border-[#262b3d] shadow-xl space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Search Input */}
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="search-scan-history-input"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by URL, domain, target brand, or keyword..."
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-[#0a0b10] border border-[#262b3d] text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono transition-colors"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Filter */}
          <div className="md:col-span-3">
            <select
              id="category-filter-select"
              value={selectedCategoryFilter}
              onChange={(e) => setSelectedCategoryFilter(e.target.value)}
              className="w-full py-2 px-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-mono transition-colors"
            >
              <option value="ALL">All Threat Categories</option>
              {uniqueCategories.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          {/* Sort Selector */}
          <div className="md:col-span-4">
            <div className="flex items-center gap-2">
              <ArrowUpDown className="w-4 h-4 text-slate-400 shrink-0" />
              <select
                id="sort-scan-history-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full py-2 px-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-mono transition-colors"
              >
                <option value="newest">Sort: Newest Scans First</option>
                <option value="oldest">Sort: Oldest Scans First</option>
                <option value="highest_risk">Sort: Highest Risk Score First</option>
                <option value="lowest_risk">Sort: Lowest Risk Score First</option>
              </select>
            </div>
          </div>
        </div>

        {/* Risk Level Pills Filter */}
        <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-[#262b3d]/70 text-xs">
          <span className="text-slate-400 font-mono text-[11px] uppercase mr-1">Risk Filter:</span>
          {[
            { id: 'ALL', label: 'All Risks' },
            { id: 'CRITICAL', label: 'Critical (≥80)' },
            { id: 'HIGH', label: 'High Risk (60-79)' },
            { id: 'SUSPICIOUS', label: 'Suspicious (40-59)' },
            { id: 'SAFE', label: 'Safe & Low (<40)' }
          ].map(pill => (
            <button
              key={pill.id}
              onClick={() => setSelectedRiskFilter(pill.id)}
              className={`px-3 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
                selectedRiskFilter === pill.id
                  ? 'bg-blue-600 text-white font-bold shadow-[0_0_10px_rgba(59,130,246,0.3)]'
                  : 'bg-[#0a0b10] text-slate-400 hover:text-slate-200 border border-[#262b3d]'
              }`}
            >
              {pill.label}
            </button>
          ))}
          <span className="ml-auto text-slate-400 font-mono text-[11px]">
            Showing <strong className="text-white">{filteredScans.length}</strong> of {scans.length} scans
          </span>
        </div>
      </div>

      {/* Scans List / Cards */}
      {filteredScans.length === 0 ? (
        <div className="p-12 rounded-2xl bg-[#141722] border border-[#262b3d] text-center space-y-4 shadow-xl">
          <div className="w-16 h-16 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mx-auto">
            <History className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">No Scan Records Match Your Filter</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Try adjusting your search query, clearing your filters, or analyzing a URL above to record telemetry.
            </p>
          </div>
          {searchTerm || selectedRiskFilter !== 'ALL' || selectedCategoryFilter !== 'ALL' ? (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedRiskFilter('ALL');
                setSelectedCategoryFilter('ALL');
              }}
              className="px-4 py-2 rounded-xl bg-[#0a0b10] hover:bg-[#1c2132] border border-[#262b3d] text-blue-400 text-xs font-medium cursor-pointer transition-colors"
            >
              Reset Filters
            </button>
          ) : (
            <button
              onClick={() => onQuickScan('https://paypal-security-update-center.top/login/index.php')}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-[0_0_15px_rgba(59,130,246,0.25)] cursor-pointer"
            >
              Run Sample Phishing Scan
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-3.5">
          {filteredScans.map((scan) => (
            <div
              key={scan.id}
              id={`scan-card-${scan.id}`}
              className="p-5 rounded-2xl bg-[#141722] border border-[#262b3d] hover:border-[#3b82f6]/40 transition-all shadow-xl space-y-3 group"
            >
              {/* Header row: Risk Score badge, category, timestamp, targeted brand */}
              <div className="flex flex-wrap items-center justify-between gap-2.5">
                <div className="flex items-center gap-2 flex-wrap">
                  {getRiskBadge(scan.riskScore, scan.riskLevel)}

                  <span className="px-2.5 py-0.5 rounded-md text-[11px] font-mono bg-[#0a0b10] border border-[#262b3d] text-slate-300">
                    {scan.threatCategory}
                  </span>

                  {scan.targetBrand && (
                    <span className="px-2 py-0.5 rounded-md text-[11px] font-mono bg-rose-500/10 border border-rose-500/20 text-rose-300 font-semibold">
                      Target: {scan.targetBrand}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-400 font-mono">
                  <span>{scan.timestamp}</span>
                  <span className="text-slate-600">•</span>
                  <span>Confidence: <strong className="text-slate-200">{scan.confidence}%</strong></span>
                </div>
              </div>

              {/* URL & Domain Breakdown */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d]">
                <div className="space-y-0.5 min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <Globe2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span className="font-mono text-xs font-bold text-white truncate">
                      {scan.domain}
                    </span>
                  </div>
                  <div className="font-mono text-[11px] text-slate-400 truncate max-w-3xl" title={scan.url}>
                    {scan.url}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleCopyUrl(scan)}
                    className="p-2 rounded-lg bg-[#141722] hover:bg-[#1c2132] text-slate-400 hover:text-white border border-[#262b3d] transition-colors cursor-pointer"
                    title="Copy full URL"
                  >
                    {copiedId === scan.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Signals and AI Excerpt */}
              {scan.aiExplanation?.summary && (
                <div className="text-xs text-slate-300 bg-[#141722]/50 p-2.5 rounded-xl border border-[#262b3d]/50 flex items-start gap-2">
                  <Sparkles className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                  <p className="line-clamp-2 leading-relaxed">
                    {scan.aiExplanation.summary}
                  </p>
                </div>
              )}

              {/* Forensic Highlights Tags */}
              <div className="flex items-center gap-1.5 flex-wrap text-[11px] font-mono">
                {scan.technicalDetails.hasHomoglyphs && (
                  <span className="px-2 py-0.5 rounded bg-rose-500/10 text-rose-300 border border-rose-500/20">
                    Homoglyph / Punycode
                  </span>
                )}
                {scan.technicalDetails.isIpHost && (
                  <span className="px-2 py-0.5 rounded bg-rose-500/10 text-rose-300 border border-rose-500/20">
                    Raw IP Address Host
                  </span>
                )}
                {scan.technicalDetails.entropyScore > 4.2 && (
                  <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                    High Entropy: {scan.technicalDetails.entropyScore}
                  </span>
                )}
                {scan.technicalDetails.tldRisk === 'High' && (
                  <span className="px-2 py-0.5 rounded bg-orange-500/10 text-orange-300 border border-orange-500/20">
                    High Risk TLD: .{scan.technicalDetails.tld}
                  </span>
                )}
                {scan.technicalDetails.redirectCount > 1 && (
                  <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-300 border border-blue-500/20">
                    {scan.technicalDetails.redirectCount} HTTP Redirects
                  </span>
                )}
                {scan.signals && (
                  <span className="text-slate-400 ml-auto">
                    {scan.signals.length} Signals Evaluated
                  </span>
                )}
              </div>

              {/* Action Buttons Row */}
              <div className="pt-2 border-t border-[#262b3d] flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    id={`view-forensics-${scan.id}`}
                    onClick={() => {
                      setSelectedScanForModal(scan);
                      setActiveModalTab('overview');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-blue-600/15 hover:bg-blue-600/25 border border-blue-500/30 text-blue-300 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5 text-blue-400" />
                    Inspect Deep Forensics
                  </button>

                  <button
                    id={`rescan-btn-${scan.id}`}
                    onClick={() => onSelectScan(scan)}
                    className="px-3 py-1.5 rounded-xl bg-[#0a0b10] hover:bg-[#1c2132] border border-[#262b3d] text-slate-300 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-blue-400" />
                    Load in Scanner
                  </button>

                  {scan.riskScore >= 60 && (
                    <button
                      id={`soc-push-${scan.id}`}
                      onClick={() => onPushToSoc(scan)}
                      className="px-3 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Flame className="w-3.5 h-3.5 text-rose-400" />
                      Push to SOC Triage
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onOpenFalsePositiveModal(scan)}
                    className="px-2.5 py-1.5 rounded-xl bg-[#0a0b10] hover:bg-[#1c2132] border border-[#262b3d] text-slate-400 hover:text-amber-300 text-xs transition-colors cursor-pointer"
                    title="Dispute as False Positive"
                  >
                    <Flag className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onOpenReportModal(scan.url, 'URL')}
                    className="px-2.5 py-1.5 rounded-xl bg-[#0a0b10] hover:bg-[#1c2132] border border-[#262b3d] text-slate-400 hover:text-white text-xs transition-colors cursor-pointer"
                    title="File Formal Incident Report"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                  </button>

                  <button
                    id={`delete-scan-${scan.id}`}
                    onClick={() => onDeleteScan(scan.id)}
                    className="p-1.5 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20 transition-colors cursor-pointer"
                    title="Delete record from vault"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Deep Forensic Inspection Modal */}
      {selectedScanForModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141722] border border-[#262b3d] rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 border-b border-[#262b3d] flex items-center justify-between bg-[#141722]">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                    FORENSIC TELEMETRY RECORD
                  </span>
                  <span className="text-xs text-slate-400 font-mono">ID: {selectedScanForModal.id}</span>
                </div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2 font-mono">
                  {selectedScanForModal.domain}
                </h2>
              </div>
              <button
                onClick={() => setSelectedScanForModal(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1c2132] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Tabs */}
            <div className="flex items-center gap-2 px-5 pt-3 border-b border-[#262b3d] bg-[#0a0b10]">
              {[
                { id: 'overview', label: 'Forensic Overview', icon: Sparkles },
                { id: 'signals', label: `Signals (${selectedScanForModal.signals?.length || 0})`, icon: AlertTriangle },
                { id: 'technical', label: 'Technical Telemetry', icon: Terminal },
                { id: 'mitre', label: 'MITRE ATT&CK Matrix', icon: Layers }
              ].map(tab => {
                const Icon = tab.icon;
                const active = activeModalTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveModalTab(tab.id as any)}
                    className={`px-3.5 py-2.5 border-b-2 text-xs font-medium flex items-center gap-2 transition-all cursor-pointer ${
                      active
                        ? 'border-blue-500 text-blue-400 font-bold'
                        : 'border-transparent text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Modal Scrollable Content */}
            <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
              {activeModalTab === 'overview' && (
                <div className="space-y-4">
                  {/* Executive Summary */}
                  <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-2">
                    <div className="text-xs font-semibold text-white flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-blue-400" />
                      Executive AI Assessment
                    </div>
                    <p className="text-slate-300 leading-relaxed font-sans">
                      {selectedScanForModal.aiExplanation.summary}
                    </p>
                  </div>

                  {/* Why Suspicious vs Positive Signals */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 rounded-xl bg-[#0a0b10] border border-rose-500/20 space-y-2">
                      <div className="text-xs font-semibold text-rose-300 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-rose-400" />
                        Suspicious Red Flags ({selectedScanForModal.aiExplanation.whySuspicious.length})
                      </div>
                      <ul className="space-y-1.5 list-disc list-inside text-slate-300">
                        {selectedScanForModal.aiExplanation.whySuspicious.map((item, idx) => (
                          <li key={idx} className="leading-relaxed">{item}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-4 rounded-xl bg-[#0a0b10] border border-emerald-500/20 space-y-2">
                      <div className="text-xs font-semibold text-emerald-300 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        Positive Safety Signals ({selectedScanForModal.aiExplanation.positiveSignals?.length || 0})
                      </div>
                      <ul className="space-y-1.5 list-disc list-inside text-slate-300">
                        {(selectedScanForModal.aiExplanation.positiveSignals || ['Standard DNS resolution succeeded']).map((item, idx) => (
                          <li key={idx} className="leading-relaxed">{item}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Recommended Security Action */}
                  <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/30 space-y-1.5">
                    <div className="text-xs font-bold text-blue-300 font-mono uppercase">
                      Recommended Security Action
                    </div>
                    <p className="text-slate-200">
                      {selectedScanForModal.aiExplanation.recommendedAction}
                    </p>
                  </div>
                </div>
              )}

              {activeModalTab === 'signals' && (
                <div className="space-y-3">
                  {selectedScanForModal.signals.map((sig, idx) => (
                    <div key={idx} className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-white">{sig.name}</span>
                          <span className={`px-2 py-0.2 rounded text-[10px] font-mono font-bold uppercase ${
                            sig.severity === 'critical' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                            sig.severity === 'high' ? 'bg-orange-950 text-orange-300 border border-orange-800' :
                            sig.severity === 'medium' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                            'bg-blue-950 text-blue-300 border border-blue-800'
                          }`}>
                            {sig.severity}
                          </span>
                        </div>
                        <p className="text-slate-400">{sig.description}</p>
                        {sig.evidence && (
                          <p className="font-mono text-[11px] text-cyan-300 bg-[#141722] px-2 py-1 rounded border border-[#262b3d] inline-block">
                            Evidence: {sig.evidence}
                          </p>
                        )}
                      </div>
                      <div className="text-right font-mono shrink-0">
                        <span className={`font-bold ${sig.isSafeSignal ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {sig.isSafeSignal ? '-' : '+'}{sig.scoreContribution} Score
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {activeModalTab === 'technical' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] font-mono space-y-1">
                      <div className="text-slate-400 text-[11px]">HTTPS / TLS Status</div>
                      <div className="text-white font-bold flex items-center gap-1.5">
                        {selectedScanForModal.technicalDetails.https ? <Lock className="w-3.5 h-3.5 text-emerald-400" /> : <Unlock className="w-3.5 h-3.5 text-rose-400" />}
                        {selectedScanForModal.technicalDetails.https ? 'Encrypted (HTTPS)' : 'Plaintext (HTTP)'}
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] font-mono space-y-1">
                      <div className="text-slate-400 text-[11px]">Domain Age</div>
                      <div className="text-white font-bold">
                        {selectedScanForModal.technicalDetails.domainAgeDays !== undefined
                          ? `${selectedScanForModal.technicalDetails.domainAgeDays} Days`
                          : 'Newly Registered'}
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] font-mono space-y-1">
                      <div className="text-slate-400 text-[11px]">Entropy Randomness</div>
                      <div className="text-white font-bold">
                        {selectedScanForModal.technicalDetails.entropyScore} / 8.0
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] font-mono space-y-1">
                      <div className="text-slate-400 text-[11px]">TLD & Risk Level</div>
                      <div className="text-white font-bold">
                        .{selectedScanForModal.technicalDetails.tld} ({selectedScanForModal.technicalDetails.tldRisk})
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] font-mono space-y-1">
                      <div className="text-slate-400 text-[11px]">IP Host Detection</div>
                      <div className="text-white font-bold">
                        {selectedScanForModal.technicalDetails.isIpHost ? 'Yes (Direct IP Address)' : 'No (FQDN)'}
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] font-mono space-y-1">
                      <div className="text-slate-400 text-[11px]">Homoglyph / Punycode</div>
                      <div className="text-white font-bold">
                        {selectedScanForModal.technicalDetails.hasHomoglyphs ? 'Yes (Unicode Spoof)' : 'None Detected'}
                      </div>
                    </div>
                  </div>

                  {/* Redirect Chain */}
                  <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-2">
                    <div className="text-xs font-semibold text-white flex items-center gap-2">
                      <Globe2 className="w-4 h-4 text-blue-400" />
                      Observed Redirect Chain ({selectedScanForModal.technicalDetails.redirectChain?.length || 1} Hops)
                    </div>
                    <div className="space-y-1.5 font-mono text-[11px]">
                      {(selectedScanForModal.technicalDetails.redirectChain || [selectedScanForModal.url]).map((step, idx) => (
                        <div key={idx} className="flex items-center gap-2 p-2 rounded bg-[#141722] border border-[#262b3d] text-slate-300">
                          <span className="text-blue-400 font-bold">#{idx + 1}</span>
                          <span className="truncate">{step}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeModalTab === 'mitre' && (
                <div className="space-y-3">
                  <p className="text-slate-400">
                    Mapped ATT&CK techniques identified during the forensic analysis of this artifact:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {selectedScanForModal.aiExplanation.mitreTechniques.map((tech, idx) => (
                      <div key={idx} className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                        <div className="font-mono text-xs font-bold text-rose-300 flex items-center gap-2">
                          <Layers className="w-3.5 h-3.5 text-rose-400" />
                          {tech}
                        </div>
                        <p className="text-slate-400 text-[11px]">
                          Enterprise ATT&CK Matrix Tactic: Initial Access & Credential Harvesting
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#262b3d] bg-[#141722] flex items-center justify-between">
              <button
                onClick={() => {
                  onSelectScan(selectedScanForModal);
                  setSelectedScanForModal(null);
                }}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2 transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Re-Analyze in URL Scanner
              </button>

              <button
                onClick={() => setSelectedScanForModal(null)}
                className="px-4 py-2 rounded-xl bg-[#0a0b10] hover:bg-[#1c2132] border border-[#262b3d] text-slate-300 text-xs font-medium cursor-pointer"
              >
                Close Vault Record
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141722] border border-[#262b3d] rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-white">Clear Scan Telemetry Vault?</h3>
              <p className="text-xs text-slate-400">
                This will delete all stored scan history from your local session and Firestore database. This action cannot be undone.
              </p>
            </div>
            <div className="flex justify-end gap-2 pt-3 border-t border-[#262b3d]">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-4 py-2 rounded-xl bg-[#0a0b10] hover:bg-[#1c2132] border border-[#262b3d] text-slate-300 text-xs font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onClearAllScans();
                  setShowClearConfirm(false);
                }}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-colors cursor-pointer shadow-[0_0_15px_rgba(239,68,68,0.3)]"
              >
                Yes, Clear All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
