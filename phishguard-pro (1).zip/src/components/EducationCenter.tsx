import React, { useState } from 'react';
import {
  GraduationCap,
  Award,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Sparkles,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  ShieldAlert,
  RotateCcw,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { QUIZ_QUESTIONS, SPOT_THE_PHISH_CHALLENGES } from '../data/mockData';

export const EducationCenter: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'guides' | 'spotter' | 'quiz'>('guides');

  // Quiz State
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showResults, setShowResults] = useState(false);

  // Spotter State
  const [spotterIdx, setSpotterIdx] = useState(0);
  const [spotterSelection, setSpotterSelection] = useState<'A' | 'B' | null>(null);
  const [showSpotterFeedback, setShowSpotterFeedback] = useState(false);

  const handleSelectQuizOption = (qIdx: number, optIdx: number) => {
    if (showResults) return;
    setSelectedAnswers(prev => ({ ...prev, [qIdx]: optIdx }));
  };

  const calculateScore = () => {
    let score = 0;
    QUIZ_QUESTIONS.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctAnswer) {
        score += 1;
      }
    });
    return score;
  };

  const resetQuiz = () => {
    setSelectedAnswers({});
    setCurrentQuestionIdx(0);
    setShowResults(false);
  };

  const currentChallenge = SPOT_THE_PHISH_CHALLENGES[spotterIdx];

  const handleSpotterAnswer = (choice: 'A' | 'B') => {
    setSpotterSelection(choice);
    setShowSpotterFeedback(true);
  };

  const nextSpotter = () => {
    setShowSpotterFeedback(false);
    setSpotterSelection(null);
    setSpotterIdx((prev) => (prev + 1) % SPOT_THE_PHISH_CHALLENGES.length);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
            SECURITY AWARENESS ACADEMY
          </span>
          <span className="text-xs text-slate-400 font-mono">Interactive Training & Certification</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
          <GraduationCap className="w-7 h-7 text-blue-400" />
          Phishing Defense Education & Simulation Center
        </h1>
        <p className="text-sm text-slate-400">
          Sharpen your threat detection reflexes with interactive real-world attack breakdowns, side-by-side analysis, and knowledge validation quizzes.
        </p>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-[#262b3d] text-xs font-medium">
        {[
          { id: 'guides', label: 'Threat Defense Guides', icon: BookOpen },
          { id: 'spotter', label: 'Spot the Phish Simulator', icon: Sparkles },
          { id: 'quiz', label: 'Security Certification Quiz', icon: Award }
        ].map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-5 py-3 border-b-2 transition-colors cursor-pointer ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-400 font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab 1: Threat Guides */}
      {activeTab === 'guides' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-3 shadow-xl">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-blue-400 uppercase">
              Module 01 • URL Forensics
            </div>
            <h2 className="text-base font-bold text-white">How to Dissect a Deceptive URL</h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Cybercriminals construct misleading subdomains to fool visual inspection. Learn the anatomy of a URL: The true root domain is always the segment immediately preceding the first single slash (<code className="text-blue-400 font-mono">/</code>).
            </p>
            <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] text-xs font-mono space-y-1">
              <div className="text-rose-400 font-bold">Fake: https://paypal.com.account-verify.top/login</div>
              <div className="text-slate-400 text-[11px]">→ Real root is <strong className="text-rose-300">account-verify.top</strong>, not PayPal!</div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-3 shadow-xl">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-cyan-400 uppercase">
              Module 02 • Business Email Compromise
            </div>
            <h2 className="text-base font-bold text-white">Executive Impersonation (CEO Fraud)</h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              BEC attacks rarely contain malware links. Instead, they exploit psychological urgency and authority by claiming an executive is in a confidential meeting and needs urgent gift cards or wire transfers.
            </p>
            <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] text-xs space-y-1">
              <strong className="text-cyan-300">Golden Rule:</strong> Always verify banking changes via a secondary, out-of-band communication channel (phone call or in-person).
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-3 shadow-xl">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-400 uppercase">
              Module 03 • Quishing Vector
            </div>
            <h2 className="text-base font-bold text-white">The Rise of QR Code Phishing</h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Because email filters cannot inspect images as easily as plain text, attackers embed QR codes in PDFs pretending to be 2FA authenticator updates or parking meter payments.
            </p>
            <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] text-xs space-y-1">
              <strong className="text-amber-300">Defensive Protocol:</strong> Use PhishGuard Pro's Quishing Scanner to inspect QR destinations before scanning with your mobile device.
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-3 shadow-xl">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-rose-400 uppercase">
              Module 04 • Modern Authentication
            </div>
            <h2 className="text-base font-bold text-white">MFA Fatigue & Adversary-in-the-Middle (AiTM)</h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Reverse-proxy phishing kits (like Evilginx) can capture session cookies and bypass SMS or authenticator app 6-digit codes.
            </p>
            <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] text-xs space-y-1">
              <strong className="text-rose-300">Hardening Directive:</strong> Adopt FIDO2 / Passkeys / hardware security keys which are cryptographically bound to the legitimate domain.
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Spot the Phish Simulator */}
      {activeTab === 'spotter' && currentChallenge && (
        <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-6 shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-blue-400 font-bold uppercase">
                Challenge {spotterIdx + 1} of {SPOT_THE_PHISH_CHALLENGES.length}
              </span>
              <h2 className="text-lg font-bold text-white">{currentChallenge.scenarioTitle}</h2>
            </div>

            <button
              onClick={nextSpotter}
              className="text-xs px-3 py-1.5 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] text-slate-200 border border-[#262b3d] flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              Next Scenario <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <p className="text-xs text-slate-300">
            Examine both samples below carefully. Identify which one is the <strong>malicious phishing attempt</strong>.
          </p>

          {/* Side by side comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Option A */}
            <div
              onClick={() => !showSpotterFeedback && handleSpotterAnswer('A')}
              className={`p-5 rounded-xl border transition-all cursor-pointer space-y-3 ${
                showSpotterFeedback
                  ? currentChallenge.isOptionAPhish
                    ? 'border-rose-500 bg-rose-950/20'
                    : 'border-emerald-500 bg-emerald-950/20'
                  : 'border-[#262b3d] bg-[#0a0b10] hover:border-slate-600'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-[#141722] border border-[#262b3d] text-slate-300">
                  Sample Option A
                </span>
                {showSpotterFeedback && currentChallenge.isOptionAPhish && (
                  <span className="text-xs font-bold text-rose-400 font-mono flex items-center gap-1">
                    <ShieldAlert className="w-4 h-4" /> PHISHING SAMPLE
                  </span>
                )}
                {showSpotterFeedback && !currentChallenge.isOptionAPhish && (
                  <span className="text-xs font-bold text-emerald-400 font-mono flex items-center gap-1">
                    <ShieldCheck className="w-4 h-4" /> LEGITIMATE SAMPLE
                  </span>
                )}
              </div>

              <div className="space-y-1.5 text-xs font-mono">
                <div className="text-slate-400">Sender: <span className="text-slate-200">{currentChallenge.optionA.sender}</span></div>
                <div className="text-slate-400">Subject: <span className="text-slate-200">{currentChallenge.optionA.subject}</span></div>
              </div>

              <div className="p-3.5 rounded-lg bg-[#141722] border border-[#262b3d] text-xs text-slate-300 whitespace-pre-line leading-relaxed">
                {currentChallenge.optionA.body}
              </div>

              {!showSpotterFeedback && (
                <button
                  type="button"
                  className="w-full py-2 rounded-lg bg-[#141722] hover:bg-rose-500/20 text-slate-200 hover:text-rose-300 text-xs font-medium border border-[#262b3d] transition-colors cursor-pointer"
                >
                  Flag Option A as Phishing
                </button>
              )}
            </div>

            {/* Option B */}
            <div
              onClick={() => !showSpotterFeedback && handleSpotterAnswer('B')}
              className={`p-5 rounded-xl border transition-all cursor-pointer space-y-3 ${
                showSpotterFeedback
                  ? !currentChallenge.isOptionAPhish
                    ? 'border-rose-500 bg-rose-950/20'
                    : 'border-emerald-500 bg-emerald-950/20'
                  : 'border-[#262b3d] bg-[#0a0b10] hover:border-slate-600'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-[#141722] border border-[#262b3d] text-slate-300">
                  Sample Option B
                </span>
                {showSpotterFeedback && !currentChallenge.isOptionAPhish && (
                  <span className="text-xs font-bold text-rose-400 font-mono flex items-center gap-1">
                    <ShieldAlert className="w-4 h-4" /> PHISHING SAMPLE
                  </span>
                )}
                {showSpotterFeedback && currentChallenge.isOptionAPhish && (
                  <span className="text-xs font-bold text-emerald-400 font-mono flex items-center gap-1">
                    <ShieldCheck className="w-4 h-4" /> LEGITIMATE SAMPLE
                  </span>
                )}
              </div>

              <div className="space-y-1.5 text-xs font-mono">
                <div className="text-slate-400">Sender: <span className="text-slate-200">{currentChallenge.optionB.sender}</span></div>
                <div className="text-slate-400">Subject: <span className="text-slate-200">{currentChallenge.optionB.subject}</span></div>
              </div>

              <div className="p-3.5 rounded-lg bg-[#141722] border border-[#262b3d] text-xs text-slate-300 whitespace-pre-line leading-relaxed">
                {currentChallenge.optionB.body}
              </div>

              {!showSpotterFeedback && (
                <button
                  type="button"
                  className="w-full py-2 rounded-lg bg-[#141722] hover:bg-rose-500/20 text-slate-200 hover:text-rose-300 text-xs font-medium border border-[#262b3d] transition-colors cursor-pointer"
                >
                  Flag Option B as Phishing
                </button>
              )}
            </div>
          </div>

          {/* Feedback Explanation */}
          {showSpotterFeedback && (
            <div className="p-5 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-2 animate-in fade-in">
              <div className="flex items-center gap-2 font-bold text-xs text-blue-400 uppercase font-mono">
                <Sparkles className="w-4 h-4" /> Forensic Breakdown & Red Flags
              </div>
              <p className="text-xs text-slate-200 leading-relaxed">
                {currentChallenge.explanation}
              </p>
              <div className="pt-2">
                <button
                  onClick={nextSpotter}
                  className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  Next Challenge
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Security Quiz */}
      {activeTab === 'quiz' && (
        <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-6 shadow-xl">
          {!showResults ? (
            <div className="space-y-5">
              <div className="flex items-center justify-between pb-4 border-b border-[#262b3d]">
                <div>
                  <span className="text-xs font-mono text-blue-400 font-bold uppercase">
                    Question {currentQuestionIdx + 1} of {QUIZ_QUESTIONS.length}
                  </span>
                  <h2 className="text-base font-bold text-white mt-1">
                    {QUIZ_QUESTIONS[currentQuestionIdx].question}
                  </h2>
                </div>

                <span className="text-xs font-mono px-2.5 py-1 rounded bg-[#0a0b10] border border-[#262b3d] text-slate-300">
                  {Object.keys(selectedAnswers).length} / {QUIZ_QUESTIONS.length} Answered
                </span>
              </div>

              {/* Options */}
              <div className="space-y-3">
                {QUIZ_QUESTIONS[currentQuestionIdx].options.map((opt, optIdx) => {
                  const isSelected = selectedAnswers[currentQuestionIdx] === optIdx;
                  return (
                    <button
                      key={optIdx}
                      onClick={() => handleSelectQuizOption(currentQuestionIdx, optIdx)}
                      className={`w-full text-left p-4 rounded-xl border text-xs font-medium transition-all flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'border-blue-500 bg-blue-500/15 text-white'
                          : 'border-[#262b3d] bg-[#0a0b10] text-slate-300 hover:border-slate-600 hover:bg-[#141722]'
                      }`}
                    >
                      <span>{opt}</span>
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-blue-400" />}
                    </button>
                  );
                })}
              </div>

              {/* Navigation Controls */}
              <div className="flex items-center justify-between pt-4 border-t border-[#262b3d]">
                <button
                  onClick={() => setCurrentQuestionIdx(prev => Math.max(0, prev - 1))}
                  disabled={currentQuestionIdx === 0}
                  className="px-4 py-2 rounded-lg bg-[#0a0b10] border border-[#262b3d] disabled:opacity-40 text-slate-300 text-xs font-medium cursor-pointer"
                >
                  Previous
                </button>

                {currentQuestionIdx < QUIZ_QUESTIONS.length - 1 ? (
                  <button
                    onClick={() => setCurrentQuestionIdx(prev => prev + 1)}
                    className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors cursor-pointer"
                  >
                    Next Question
                  </button>
                ) : (
                  <button
                    onClick={() => setShowResults(true)}
                    disabled={Object.keys(selectedAnswers).length < QUIZ_QUESTIONS.length}
                    className="px-6 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:bg-[#1c2132] text-white text-xs font-bold shadow-[0_0_15px_rgba(59,130,246,0.25)] transition-colors cursor-pointer"
                  >
                    Submit & Grade Quiz
                  </button>
                )}
              </div>
            </div>
          ) : (
            /* Results Screen */
            <div className="text-center space-y-6 py-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
                <Award className="w-9 h-9" />
              </div>

              <div className="space-y-1">
                <h2 className="text-2xl font-bold text-white font-mono">
                  Score: {calculateScore()} / {QUIZ_QUESTIONS.length} ({Math.round((calculateScore() / QUIZ_QUESTIONS.length) * 100)}%)
                </h2>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  {calculateScore() >= 4
                    ? 'Outstanding! You demonstrated advanced threat awareness and URL dissection knowledge.'
                    : 'Good attempt. Review the forensic breakdown below to refine your social-engineering detection skills.'}
                </p>
              </div>

              {/* Detailed Question Review */}
              <div className="space-y-4 text-left max-w-2xl mx-auto pt-4 border-t border-[#262b3d]">
                {QUIZ_QUESTIONS.map((q, idx) => {
                  const isCorrect = selectedAnswers[idx] === q.correctAnswer;
                  return (
                    <div key={idx} className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-2 text-xs">
                      <div className="flex items-start justify-between gap-2">
                        <div className="font-semibold text-white">{idx + 1}. {q.question}</div>
                        {isCorrect ? (
                          <span className="text-emerald-400 flex items-center gap-1 font-bold shrink-0 font-mono">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Correct
                          </span>
                        ) : (
                          <span className="text-rose-400 flex items-center gap-1 font-bold shrink-0 font-mono">
                            <XCircle className="w-3.5 h-3.5" /> Incorrect
                          </span>
                        )}
                      </div>
                      <p className="text-slate-400 text-[11px] leading-relaxed">{q.explanation}</p>
                    </div>
                  );
                })}
              </div>

              <button
                onClick={resetQuiz}
                className="px-5 py-2 rounded-xl bg-[#0a0b10] hover:bg-[#1c2132] text-slate-200 text-xs font-medium border border-[#262b3d] flex items-center gap-2 mx-auto cursor-pointer transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Retake Assessment
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
