import React, { useState, useRef, useEffect } from 'react';
import {
  QrCode,
  Shield,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Upload,
  Camera,
  RefreshCw,
  ExternalLink,
  ArrowRight,
  Sparkles,
  Lock,
  Unlock,
  CheckCircle2,
  FileSpreadsheet,
  AlertOctagon
} from 'lucide-react';
import jsQR from 'jsqr';
import { UrlAnalysisResult, RiskLevel } from '../types';

interface QrScannerProps {
  onAnalyzeUrl: (url: string) => Promise<UrlAnalysisResult | null>;
  onOpenReportModal: (target: string, type: 'QR Code') => void;
}

const SAMPLE_QR_PRESETS = [
  { name: 'Office 365 Quishing Flyer', url: 'https://office365-password-reset-portal.xyz/auth?user=employee@company.com', risk: 'HIGH RISK' },
  { name: 'Parking Meter Fake Payment', url: 'https://quick-login-parking-pay.top/meter/pay', risk: 'CRITICAL' },
  { name: 'Official Company Portal', url: 'https://www.github.com/torvalds/linux', risk: 'SAFE' }
];

export const QrScanner: React.FC<QrScannerProps> = ({
  onAnalyzeUrl,
  onOpenReportModal
}) => {
  const [decodedUrl, setDecodedUrl] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<UrlAnalysisResult | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const animationFrameId = useRef<number | null>(null);

  // Decode QR from Image file
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMsg(null);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        ctx.drawImage(img, 0, 0, img.width, img.height);
        const imageData = ctx.getImageData(0, 0, img.width, img.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);

        if (code && code.data) {
          processDecodedUrl(code.data);
        } else {
          setErrorMsg('No valid QR code could be decoded from this image. Ensure the image is clear and high-contrast.');
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const processDecodedUrl = async (url: string) => {
    setDecodedUrl(url);
    setAnalyzing(true);
    setErrorMsg(null);
    try {
      const res = await onAnalyzeUrl(url);
      setAnalysisResult(res);
    } finally {
      setAnalyzing(false);
    }
  };

  // Start Camera Stream
  const startCamera = async () => {
    setErrorMsg(null);
    setCameraActive(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        scanVideoFrame();
      }
    } catch (err: any) {
      setErrorMsg('Camera access unavailable. You can upload or drop a QR code image instead.');
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(t => t.stop());
      videoRef.current.srcObject = null;
    }
    if (animationFrameId.current) {
      cancelAnimationFrame(animationFrameId.current);
    }
    setCameraActive(false);
  };

  const scanVideoFrame = () => {
    if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
      const video = videoRef.current;
      const canvas = canvasRef.current || document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);
        if (code && code.data) {
          stopCamera();
          processDecodedUrl(code.data);
          return;
        }
      }
    }
    animationFrameId.current = requestAnimationFrame(scanVideoFrame);
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
            QUISHING DEFENSE MODULE
          </span>
          <span className="text-xs text-slate-400 font-mono">Isolated Payload Decoder & Gatekeeper</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
          <QrCode className="w-7 h-7 text-blue-400" />
          QR Phishing (Quishing) Defense Scanner
        </h1>
        <p className="text-sm text-slate-400">
          Decode QR codes in a secure sandbox, extract target URLs, and inspect for credential-harvesting destinations before opening.
        </p>
      </div>

      {/* Upload / Camera Scanner Card */}
      <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-6 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* File Upload Area */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="p-8 rounded-xl border-2 border-dashed border-[#262b3d] hover:border-blue-500/80 bg-[#0a0b10] hover:bg-[#10131d] cursor-pointer transition-all flex flex-col items-center justify-center text-center space-y-3 group"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
            <div className="w-14 h-14 rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
              <Upload className="w-7 h-7" />
            </div>
            <div className="space-y-1">
              <div className="text-sm font-semibold text-white">Upload or Drop QR Code Image</div>
              <p className="text-xs text-slate-400">Supports PNG, JPG, WebP, SVG screenshots</p>
            </div>
            <button
              type="button"
              className="px-4 py-1.5 rounded-lg bg-[#141722] text-xs text-slate-200 border border-[#262b3d] group-hover:bg-[#1c2132] cursor-pointer"
            >
              Browse Image
            </button>
          </div>

          {/* Camera Scanner or Camera View */}
          <div className="p-6 rounded-xl border border-[#262b3d] bg-[#0a0b10] flex flex-col items-center justify-center text-center space-y-4">
            {cameraActive ? (
              <div className="w-full space-y-3">
                <div className="relative rounded-lg overflow-hidden border border-blue-500/50 bg-black h-48 flex items-center justify-center">
                  <video ref={videoRef} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 border-2 border-blue-400/50 m-6 rounded-lg pointer-events-none animate-pulse" />
                </div>
                <button
                  type="button"
                  onClick={stopCamera}
                  className="px-4 py-1.5 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-medium cursor-pointer"
                >
                  Stop Camera
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                  <Camera className="w-7 h-7" />
                </div>
                <div className="space-y-1">
                  <div className="text-sm font-semibold text-white">Live Camera QR Scanner</div>
                  <p className="text-xs text-slate-400">Point your camera at a physical poster or screen</p>
                </div>
                <button
                  type="button"
                  onClick={startCamera}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-[0_0_15px_rgba(59,130,246,0.25)] cursor-pointer"
                >
                  Start Camera Scanner
                </button>
              </div>
            )}
          </div>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Preset Test Scenarios */}
        <div className="pt-2 border-t border-[#262b3d]">
          <div className="text-xs font-medium text-slate-400 mb-2">Simulate Known QR Phishing Scenarios:</div>
          <div className="flex flex-wrap gap-2">
            {SAMPLE_QR_PRESETS.map(preset => (
              <button
                key={preset.name}
                type="button"
                onClick={() => processDecodedUrl(preset.url)}
                className="text-xs px-3 py-1.5 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] text-slate-300 border border-[#262b3d] hover:border-slate-600 transition-colors flex items-center gap-2 cursor-pointer"
              >
                <QrCode className="w-3.5 h-3.5 text-blue-400" />
                <span>{preset.name}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                  preset.risk === 'CRITICAL' ? 'bg-rose-950 text-rose-300' : preset.risk === 'HIGH RISK' ? 'bg-orange-950 text-orange-300' : 'bg-emerald-950 text-emerald-300'
                }`}>
                  {preset.risk}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Decoded QR & Defensive Analysis */}
      {analyzing && (
        <div className="p-8 rounded-2xl bg-[#141722] border border-[#262b3d] text-center space-y-3 shadow-xl">
          <RefreshCw className="w-8 h-8 text-blue-400 animate-spin mx-auto" />
          <div className="text-sm font-semibold text-white">Inspecting Decoded QR Destination...</div>
          <p className="text-xs text-slate-400 font-mono">Evaluating DNS, SSL certificates, homoglyphs, and threat feeds...</p>
        </div>
      )}

      {analysisResult && !analyzing && (
        <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-6 shadow-xl">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-6 border-b border-[#262b3d]">
            <div className="space-y-2 flex-1 min-w-0">
              <div className="flex items-center gap-2.5">
                <span className={`text-xs px-3 py-1 rounded-md font-mono font-extrabold uppercase border ${
                  analysisResult.riskScore >= 70
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                    : analysisResult.riskScore >= 40
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                    : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                }`}>
                  {analysisResult.riskLevel}
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded bg-[#0a0b10] text-slate-300 font-mono border border-[#262b3d]">
                  Quishing Score: {analysisResult.riskScore}/100
                </span>
              </div>
              <h2 className="text-lg font-bold text-white font-mono break-all">
                Destination: {analysisResult.domain}
              </h2>
              <p className="text-xs text-slate-400 font-mono break-all">
                {analysisResult.url}
              </p>
            </div>

            {/* Warning Dialog Gatekeeper */}
            <div className="shrink-0">
              {analysisResult.riskScore >= 40 ? (
                <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-800/80 text-center space-y-2">
                  <div className="text-xs font-bold text-rose-400 flex items-center justify-center gap-1.5 font-mono uppercase">
                    <AlertOctagon className="w-4 h-4" />
                    Access Blocked by Defense Policy
                  </div>
                  <p className="text-[11px] text-slate-300 max-w-xs">
                    This QR destination contains deceptive credential-harvesting indicators. Do not navigate to this site.
                  </p>
                  <button
                    onClick={() => onOpenReportModal(analysisResult.url, 'QR Code')}
                    className="w-full py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-colors cursor-pointer"
                  >
                    Report Quishing Campaign
                  </button>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/80 text-center space-y-2">
                  <div className="text-xs font-bold text-emerald-400 flex items-center justify-center gap-1.5 font-mono uppercase">
                    <ShieldCheck className="w-4 h-4" />
                    Destination Evaluated as Benign
                  </div>
                  <p className="text-[11px] text-slate-300 max-w-xs">
                    Domain matches trusted repository or enterprise authority.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* AI Reasoning Points */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-300 uppercase font-mono flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-400" />
              Why This Score Was Assigned
            </h3>
            <ul className="space-y-2 text-xs text-slate-300">
              {analysisResult.aiExplanation.whySuspicious.map((pt, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="text-rose-400 font-bold mt-0.5">•</span>
                  <span>{pt}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
