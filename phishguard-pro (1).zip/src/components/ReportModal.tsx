import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Send,
  CheckCircle2,
  AlertTriangle,
  Flame
} from 'lucide-react';
import { ThreatReport } from '../types';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetInitial: string;
  typeInitial: ThreatReport['type'];
  onSubmitReport: (report: Omit<ThreatReport, 'id' | 'createdAt' | 'status'>) => Promise<ThreatReport>;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  targetInitial,
  typeInitial,
  onSubmitReport
}) => {
  const [target, setTarget] = useState(targetInitial || '');
  const [type, setType] = useState<ThreatReport['type']>(typeInitial || 'URL');
  const [description, setDescription] = useState('');
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState<ThreatReport | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!target.trim()) return;

    setIsSubmitting(true);
    try {
      const ticket = await onSubmitReport({
        type,
        target: target.trim(),
        description: description.trim(),
        reporterEmail: email.trim() || 'analyst@phishguard.corp'
      });
      setSubmitted(ticket);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#141722] border border-[#262b3d] rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-[#262b3d]">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-blue-400" />
            File Threat Report to Incident Response
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white cursor-pointer">✕</button>
        </div>

        {submitted ? (
          <div className="py-6 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <div className="text-xs font-mono text-blue-400 font-bold">REPORT DISPATCHED</div>
              <div className="text-lg font-mono font-bold text-white">{submitted.id}</div>
              <p className="text-xs text-slate-400 max-w-xs mx-auto">
                Incident Response has received this payload and will evaluate perimeter sinkhole containment.
              </p>
            </div>
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-[#0a0b10] hover:bg-[#1c2132] border border-[#262b3d] text-slate-200 text-xs font-medium cursor-pointer transition-colors"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-slate-400 mb-1 font-medium">Threat Vector</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 focus:outline-none font-mono focus:border-blue-500"
              >
                <option value="URL">Malicious URL / Destination</option>
                <option value="Email">Email Impersonation</option>
                <option value="QR Code">Malicious QR / Quishing</option>
                <option value="SMS">Smishing</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-medium">Suspect Destination / Target</label>
              <input
                type="text"
                required
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 focus:outline-none font-mono focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-medium">Observations / Context</label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What suspicious indicators did you observe?"
                className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2.5 text-slate-200 focus:outline-none font-mono focus:border-blue-500"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-[#262b3d]">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] border border-[#262b3d] text-slate-300 text-xs cursor-pointer transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:bg-[#1c2132] text-white font-bold text-xs cursor-pointer transition-colors shadow-[0_0_15px_rgba(59,130,246,0.25)]"
              >
                {isSubmitting ? 'Transmitting...' : 'Dispatch Report'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
