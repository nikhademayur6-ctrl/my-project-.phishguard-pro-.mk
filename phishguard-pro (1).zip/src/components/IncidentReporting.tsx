import React, { useState } from 'react';
import {
  FileSpreadsheet,
  ShieldAlert,
  ShieldCheck,
  Send,
  Upload,
  CheckCircle2,
  Clock,
  ExternalLink,
  Flame,
  AlertTriangle,
  Lock,
  Sparkles,
  Info
} from 'lucide-react';
import { ThreatReport } from '../types';

interface IncidentReportingProps {
  reports: ThreatReport[];
  onSubmitReport: (report: Omit<ThreatReport, 'id' | 'createdAt' | 'status'>) => Promise<ThreatReport>;
}

export const IncidentReporting: React.FC<IncidentReportingProps> = ({
  reports,
  onSubmitReport
}) => {
  const [threatType, setThreatType] = useState<'URL' | 'Email' | 'SMS' | 'QR Code' | 'Other'>('URL');
  const [target, setTarget] = useState('');
  const [sender, setSender] = useState('');
  const [description, setDescription] = useState('');
  const [reporterEmail, setReporterEmail] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submittedTicket, setSubmittedTicket] = useState<ThreatReport | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!target.trim()) return;

    setSubmitting(true);
    try {
      const ticket = await onSubmitReport({
        type: threatType,
        target: target.trim(),
        sender: sender.trim() || undefined,
        description: description.trim(),
        reporterEmail: isAnonymous ? undefined : reporterEmail.trim() || 'user@organization.corp',
        isAnonymous
      });
      setSubmittedTicket(ticket);
      setTarget('');
      setSender('');
      setDescription('');
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusBadge = (status: ThreatReport['status']) => {
    switch (status) {
      case 'Verified Threat':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      case 'Under Review':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'Resolved':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
      case 'False Positive':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
            EMPLOYEE THREAT INTAKE PORTAL
          </span>
          <span className="text-xs text-slate-400 font-mono">Direct Uplink to SOC Security Queue</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
          <FileSpreadsheet className="w-7 h-7 text-blue-400" />
          Report Phishing or Suspicious Threat
        </h1>
        <p className="text-sm text-slate-400">
          Spotted an impersonation email, credential harvester, or malicious QR code? Submit evidence directly to security analysts for instant perimeter blocking.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form Column */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-5 shadow-xl">
          {submittedTicket ? (
            <div className="p-6 rounded-xl bg-emerald-950/40 border border-emerald-800/80 text-center space-y-4">
              <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <div className="text-xs font-mono text-emerald-400 font-bold uppercase">
                  Incident Ticket Logged Successfully
                </div>
                <h2 className="text-2xl font-bold font-mono text-white">{submittedTicket.id}</h2>
                <p className="text-xs text-slate-300 max-w-md mx-auto">
                  Our SOC security automation engine is inspecting the submission. If verified, the domain will be sinkholed enterprise-wide within 3 minutes.
                </p>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => setSubmittedTicket(null)}
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors cursor-pointer"
                >
                  Submit Another Report
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 mb-1.5 font-medium">Threat Vector</label>
                  <select
                    value={threatType}
                    onChange={(e) => setThreatType(e.target.value as any)}
                    className="w-full bg-[#0a0b10] border border-[#262b3d] focus:border-blue-500 rounded-xl p-2.5 text-slate-200 focus:outline-none font-mono"
                  >
                    <option value="URL">Malicious URL / Website</option>
                    <option value="Email">Phishing Email / BEC</option>
                    <option value="SMS">Smishing (SMS Text Scam)</option>
                    <option value="QR Code">Quishing (Malicious QR Code)</option>
                    <option value="Other">Other Social Engineering Vector</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1.5 font-medium">
                    Suspicious Target URL or Address <span className="text-blue-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={target}
                    onChange={(e) => setTarget(e.target.value)}
                    placeholder="e.g. https://paypal-security-update.top/login"
                    className="w-full bg-[#0a0b10] border border-[#262b3d] focus:border-blue-500 rounded-xl p-2.5 text-slate-200 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 mb-1.5 font-medium">Suspect Sender (If Email/SMS)</label>
                  <input
                    type="text"
                    value={sender}
                    onChange={(e) => setSender(e.target.value)}
                    placeholder="e.g. support@microsoft-verify.xyz"
                    className="w-full bg-[#0a0b10] border border-[#262b3d] focus:border-blue-500 rounded-xl p-2.5 text-slate-200 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1.5 font-medium">Your Email (For Updates)</label>
                  <input
                    type="email"
                    disabled={isAnonymous}
                    value={reporterEmail}
                    onChange={(e) => setReporterEmail(e.target.value)}
                    placeholder={isAnonymous ? 'Reporting anonymously' : 'e.g. yourname@company.com'}
                    className="w-full bg-[#0a0b10] disabled:bg-[#141722] border border-[#262b3d] focus:border-blue-500 rounded-xl p-2.5 text-slate-200 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1.5 font-medium">Incident Context / Red Flags Noticed</label>
                <textarea
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe why this message seemed suspicious (e.g. artificial urgency, unusual payment request, unexpected invoice attachment)..."
                  className="w-full bg-[#0a0b10] border border-[#262b3d] focus:border-blue-500 rounded-xl p-2.5 text-slate-200 focus:outline-none font-mono leading-relaxed"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={isAnonymous}
                    onChange={(e) => setIsAnonymous(e.target.checked)}
                    className="w-4 h-4 rounded border-[#262b3d] bg-[#0a0b10] text-blue-500 focus:ring-0"
                  />
                  <span>Submit report anonymously</span>
                </label>

                <button
                  type="submit"
                  disabled={submitting || !target.trim()}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-[#1c2132] text-white font-bold transition-all shadow-[0_0_15px_rgba(59,130,246,0.25)] cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  Transmit Report
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Reports History / Tracking */}
        <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4 shadow-xl flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-400" />
                Submitted Reports Tracking
              </h2>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#0a0b10] border border-[#262b3d] text-slate-400">
                {reports.length} Total
              </span>
            </div>

            <div className="space-y-2.5 divide-y divide-[#262b3d]/60 max-h-96 overflow-y-auto">
              {reports.map(r => (
                <div key={r.id} className="pt-2.5 first:pt-0 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-white">{r.id}</span>
                    <span className={`text-[10px] px-2 py-0.2 rounded font-mono font-bold uppercase border ${getStatusBadge(r.status)}`}>
                      {r.status}
                    </span>
                  </div>
                  <div className="font-mono text-slate-400 truncate text-[11px]">{r.target}</div>
                  <div className="text-[10px] text-slate-500 font-mono">Logged: {r.createdAt}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] text-[11px] text-slate-400 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Every confirmed submission enriches our collective machine learning threat database.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
