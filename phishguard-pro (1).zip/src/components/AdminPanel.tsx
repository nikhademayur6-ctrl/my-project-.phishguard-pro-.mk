import React, { useState } from 'react';
import {
  Sliders,
  ShieldAlert,
  ShieldCheck,
  Plus,
  Trash2,
  Lock,
  Cpu,
  Server,
  Activity,
  CheckCircle2,
  Sparkles,
  Save,
  Layers,
  FileCode
} from 'lucide-react';
import { AuditLogItem } from '../types';

interface DetectionRule {
  id: string;
  name: string;
  pattern: string;
  weight: number;
  enabled: boolean;
}

export const AdminPanel: React.FC = () => {
  const [entropyThreshold, setEntropyThreshold] = useState(4.5);
  const [nrdDaysThreshold, setNrdDaysThreshold] = useState(30);
  const [geminiModel, setGeminiModel] = useState('gemini-2.5-flash');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const [rules, setRules] = useState<DetectionRule[]>([
    { id: '1', name: 'Raw IP Host In URL', pattern: '^https?://[0-9]{1,3}\\.[0-9]{1,3}', weight: 35, enabled: true },
    { id: '2', name: 'Excessive Subdomain Stacking', pattern: '([^.]+\\.){4,}', weight: 25, enabled: true },
    { id: '3', name: 'Punycode IDN Spoof Indicator', pattern: 'xn--', weight: 30, enabled: true },
    { id: '4', name: 'Credential Keyword Anchor Spoof', pattern: '(login|verify|update|secure|account).*(chase|paypal|microsoft)', weight: 40, enabled: true }
  ]);

  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([
    { id: '1', action: 'Rule Update', performedBy: 'Mayur Nikhade (Administrator)', timestamp: '2026-03-02 04:15:22', target: 'Punycode IDN Spoof Indicator', details: 'Increased weight from 20 to 30' },
    { id: '2', action: 'DNS Sinkhole Policy', performedBy: 'SOC Automation Service', timestamp: '2026-03-02 03:40:10', target: '*.top TLD Policy', details: 'Automated sinkhole block rule updated' },
    { id: '3', action: 'Incident Escalation', performedBy: 'Security Analyst Alpha', timestamp: '2026-03-02 02:11:05', target: 'INC-2026-0891', details: 'Status transitioned from Investigating to Contained' }
  ]);

  const [newRuleName, setNewRuleName] = useState('');
  const [newRulePattern, setNewRulePattern] = useState('');
  const [newRuleWeight, setNewRuleWeight] = useState(25);

  const handleSaveSettings = () => {
    setSavedSuccess(true);
    setAuditLogs([
      {
        id: Date.now().toString(),
        action: 'Engine Threshold Configuration',
        performedBy: 'Mayur Nikhade (Administrator)',
        timestamp: new Date().toLocaleString(),
        target: 'Heuristic Thresholds',
        details: `Entropy: ${entropyThreshold}, NRD Threshold: ${nrdDaysThreshold}d`
      },
      ...auditLogs
    ]);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRuleName.trim() || !newRulePattern.trim()) return;

    const newRule: DetectionRule = {
      id: Date.now().toString(),
      name: newRuleName.trim(),
      pattern: newRulePattern.trim(),
      weight: newRuleWeight,
      enabled: true
    };

    setRules([...rules, newRule]);
    setNewRuleName('');
    setNewRulePattern('');
  };

  const handleToggleRule = (id: string) => {
    setRules(rules.map(r => r.id === id ? { ...r, enabled: !r.enabled } : r));
  };

  const handleDeleteRule = (id: string) => {
    setRules(rules.filter(r => r.id !== id));
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30">
            ADMINISTRATIVE CONSOLE
          </span>
          <span className="text-xs text-slate-400 font-mono">Detection Engine & Rule Governance</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
          <Sliders className="w-7 h-7 text-rose-400" />
          Heuristic Engine & Policy Administration
        </h1>
        <p className="text-sm text-slate-400">
          Configure Shannon entropy sensitivity, newly registered domain thresholds, regex signatures, and audit logs.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Core Heuristic Parameters */}
        <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-5 shadow-xl">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <Cpu className="w-4 h-4 text-blue-400" />
            Detection Engine Thresholds
          </h2>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex items-center justify-between mb-1.5 font-mono">
                <span className="text-slate-300">Entropy Trigger Threshold</span>
                <span className="text-blue-400 font-bold">{entropyThreshold}</span>
              </div>
              <input
                type="range"
                min="3.0"
                max="6.0"
                step="0.1"
                value={entropyThreshold}
                onChange={(e) => setEntropyThreshold(Number(e.target.value))}
                className="w-full accent-blue-500"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Flags URLs with high randomness or obfuscation above this index.
              </p>
            </div>

            <div className="pt-2 border-t border-[#262b3d]">
              <div className="flex items-center justify-between mb-1.5 font-mono">
                <span className="text-slate-300">Newly Registered Domain (NRD) Days</span>
                <span className="text-blue-400 font-bold">{nrdDaysThreshold} Days</span>
              </div>
              <input
                type="range"
                min="7"
                max="90"
                step="1"
                value={nrdDaysThreshold}
                onChange={(e) => setNrdDaysThreshold(Number(e.target.value))}
                className="w-full accent-blue-500"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Domains created within this window trigger automatic suspicion.
              </p>
            </div>

            <div className="pt-2 border-t border-[#262b3d]">
              <label className="block text-slate-300 mb-1 font-medium">Explainable AI Model</label>
              <select
                value={geminiModel}
                onChange={(e) => setGeminiModel(e.target.value)}
                className="w-full bg-[#0a0b10] border border-[#262b3d] rounded-xl p-2.5 text-slate-200 font-mono focus:outline-none focus:border-blue-500"
              >
                <option value="gemini-2.5-flash">Google Gemini 2.5 Flash (Ultra Fast)</option>
                <option value="gemini-3.7-flash">Google Gemini 3.7 Flash</option>
              </select>
            </div>

            <button
              onClick={handleSaveSettings}
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(59,130,246,0.25)] cursor-pointer"
            >
              {savedSuccess ? <CheckCircle2 className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              {savedSuccess ? 'Policies Saved & Propagated' : 'Commit Configuration'}
            </button>
          </div>
        </div>

        {/* Custom Regex Rules */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4 shadow-xl">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <FileCode className="w-4 h-4 text-rose-400" />
            Active Regex Heuristic Signatures ({rules.length})
          </h2>

          <div className="space-y-2.5 max-h-72 overflow-y-auto">
            {rules.map(rule => (
              <div
                key={rule.id}
                className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] flex items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1 min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white">{rule.name}</span>
                    <span className="font-mono text-rose-400 font-bold">+{rule.weight} Score</span>
                  </div>
                  <div className="font-mono text-slate-400 text-[11px] truncate bg-[#141722] px-2 py-0.5 rounded border border-[#262b3d]">
                    {rule.pattern}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleToggleRule(rule.id)}
                    className={`px-2.5 py-1 rounded text-[10px] font-mono font-bold uppercase transition-colors cursor-pointer ${
                      rule.enabled ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-[#141722] text-slate-500'
                    }`}
                  >
                    {rule.enabled ? 'Active' : 'Disabled'}
                  </button>
                  <button
                    onClick={() => handleDeleteRule(rule.id)}
                    className="p-1 text-slate-500 hover:text-rose-400 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Add New Rule Form */}
          <form onSubmit={handleAddRule} className="pt-3 border-t border-[#262b3d] grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
            <input
              type="text"
              required
              value={newRuleName}
              onChange={(e) => setNewRuleName(e.target.value)}
              placeholder="Rule label (e.g. PayPal Phish Trap)"
              className="bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2 text-slate-200 focus:outline-none focus:border-blue-500"
            />
            <input
              type="text"
              required
              value={newRulePattern}
              onChange={(e) => setNewRulePattern(e.target.value)}
              placeholder="Regex pattern (e.g. login-verify.*\\.top)"
              className="bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2 text-slate-200 focus:outline-none font-mono focus:border-blue-500"
            />
            <div className="flex gap-2">
              <input
                type="number"
                min="5"
                max="50"
                value={newRuleWeight}
                onChange={(e) => setNewRuleWeight(Number(e.target.value))}
                className="w-20 bg-[#0a0b10] border border-[#262b3d] rounded-lg p-2 text-slate-200 text-center font-mono focus:outline-none focus:border-blue-500"
              />
              <button
                type="submit"
                className="flex-1 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-medium cursor-pointer transition-colors"
              >
                Add Rule
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* System Audit Logs */}
      <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4 shadow-xl">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2">
          <Activity className="w-4 h-4 text-blue-400" />
          Administrative Security Audit Logs
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#262b3d] text-slate-400 bg-[#0a0b10]/60">
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Action</th>
                <th className="py-2.5 px-3">Administrator</th>
                <th className="py-2.5 px-3">Target Object</th>
                <th className="py-2.5 px-3">Audit Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#262b3d]/60 text-slate-300">
              {auditLogs.map(log => (
                <tr key={log.id} className="hover:bg-[#1c2132]/40">
                  <td className="py-2.5 px-3 text-slate-500">{log.timestamp}</td>
                  <td className="py-2.5 px-3 font-bold text-white">{log.action}</td>
                  <td className="py-2.5 px-3 text-blue-400">{log.performedBy}</td>
                  <td className="py-2.5 px-3 font-mono text-cyan-300">{log.target}</td>
                  <td className="py-2.5 px-3 text-slate-400">{log.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
