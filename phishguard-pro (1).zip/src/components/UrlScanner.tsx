import React, { useState } from 'react';
import {
  Link2,
  Shield,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Flame,
  CheckCircle2,
  ExternalLink,
  Copy,
  Check,
  RefreshCw,
  Sparkles,
  Lock,
  Unlock,
  Server,
  Globe2,
  Layers,
  Terminal,
  FileSpreadsheet,
  Flag,
  ArrowRight,
  Info,
  History
} from 'lucide-react';
import { UrlAnalysisResult, RiskLevel } from '../types';

interface UrlScannerProps {
  onAnalyzeUrl: (url: string) => Promise<UrlAnalysisResult | null>;
  currentResult: UrlAnalysisResult | null;
  onOpenReportModal: (target: string, type: 'URL') => void;
  onOpenFalsePositiveModal: (scan: UrlAnalysisResult) => void;
  onPushToSoc: (scan: UrlAnalysisResult) => void;
  onNavigateToHistory?: () => void;
}

const PRESET_URLS = [
  { label: 'PayPal Spoof (.top TLD)', url: 'https://paypal-security-update-center.top/login/index.php', risk: 'CRITICAL' },
  { label: 'Office 365 Harvester', url: 'https://office365-password-reset-portal.xyz/auth?user=employee@corp.com', risk: 'HIGH RISK' },
  { label: 'Raw IP Bank Clone', url: 'http://192.241.220.88/secure/login/chase/auth.html', risk: 'CRITICAL' },
  { label: 'Punycode Spoof (xn--)', url: 'https://xn--appl-43d.com/appleid-verify', risk: 'CRITICAL' },
  { label: 'Benign Domain (GitHub)', url: 'https://www.github.com/torvalds/linux', risk: 'SAFE' },
];

export const UrlScanner: React.FC<UrlScannerProps> = ({
  onAnalyzeUrl,
  currentResult,
  onOpenReportModal,
  onOpenFalsePositiveModal,
  onPushToSoc,
  onNavigateToHistory
}) => {
  const [inputUrl, setInputUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'signals' | 'technical' | 'mitre'>('overview');
  const [copied, setCopied] = useState(false);

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputUrl.trim()) return;

    setLoading(true);
    try {
      await onAnalyzeUrl(inputUrl.trim());
    } finally {
      setLoading(false);
    }
  };

  const handleCopyIoc = () => {
    if (!currentResult) return;
    const iocData = {
      url: currentResult.url,
      domain: currentResult.domain,
      riskScore: currentResult.riskScore,
      riskLevel: currentResult.riskLevel,
      threatCategory: currentResult.threatCategory,
      signals: currentResult.signals.map(s => s.name),
      timestamp: currentResult.timestamp
    };
    navigator.clipboard.writeText(JSON.stringify(iocData, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getRiskColor = (level: RiskLevel) => {
    switch (level) {
      case 'CRITICAL':
        return { text: 'text-rose-400', bg: 'bg-rose-500/20', border: 'border-rose-500/30', stroke: '#ef4444' };
      case 'HIGH RISK':
        return { text: 'text-orange-400', bg: 'bg-orange-500/20', border: 'border-orange-500/30', stroke: '#f97316' };
      case 'SUSPICIOUS':
        return { text: 'text-amber-400', bg: 'bg-amber-500/20', border: 'border-amber-500/30', stroke: '#f59e0b' };
      case 'LOW RISK':
        return { text: 'text-blue-400', bg: 'bg-blue-500/20', border: 'border-blue-500/30', stroke: '#3b82f6' };
      default:
        return { text: 'text-emerald-400', bg: 'bg-emerald-500/20', border: 'border-emerald-500/30', stroke: '#10b981' };
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
              DEFENSIVE ENGINE v2.5
            </span>
            <span className="text-xs text-slate-400 font-mono">10 Multi-Signal Heuristic Checkpoints</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
            <Link2 className="w-7 h-7 text-blue-400" />
            Advanced URL & Threat Scanner
          </h1>
          <p className="text-sm text-slate-400">
            Inspect destinations for deceptive subdomains, IDN homoglyphs, brand spoofing, newly registered domain abuse, and credential harvesters.
          </p>
        </div>

        {onNavigateToHistory && (
          <button
            id="scanner-go-to-history-btn"
            onClick={onNavigateToHistory}
            className="px-4 py-2 rounded-xl bg-[#141722] hover:bg-[#1c2132] border border-[#262b3d] text-slate-300 text-xs font-medium flex items-center gap-2 transition-colors cursor-pointer self-start sm:self-auto shrink-0 shadow-lg"
          >
            <History className="w-4 h-4 text-blue-400" />
            View Scan History Vault
          </button>
        )}
      </div>

      {/* Input Form & Presets */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4 shadow-xl">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="relative">
            <input
              id="url-scanner-main-input"
              type="text"
              value={inputUrl}
              onChange={(e) => setInputUrl(e.target.value)}
              placeholder="Enter suspicious URL or domain (e.g. https://paypal-security-update.top/login)..."
              className="w-full bg-[#0a0b10] border border-[#262b3d] hover:border-slate-600 focus:border-blue-500 rounded-xl px-4 py-3.5 pl-11 text-sm text-slate-100 placeholder-slate-500 focus:outline-none transition-all font-mono"
            />
            <Link2 className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-1">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>AI explainable threat scoring enabled with Google Gemini 3.7</span>
            </div>

            <button
              id="url-scan-submit-btn"
              type="submit"
              disabled={loading || !inputUrl.trim()}
              className="flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-semibold text-sm transition-all shadow-[0_0_20px_rgba(59,130,246,0.25)] cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Analyzing Signals...
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  Analyze URL
                </>
              )}
            </button>
          </div>
        </form>

        {/* Quick Test Presets */}
        <div className="pt-3 border-t border-[#262b3d]/80">
          <div className="text-xs font-medium text-slate-400 mb-2">Quick Test Presets (Simulated Scenarios):</div>
          <div className="flex flex-wrap gap-2">
            {PRESET_URLS.map(p => (
              <button
                key={p.label}
                type="button"
                onClick={() => {
                  setInputUrl(p.url);
                  onAnalyzeUrl(p.url);
                }}
                className="text-xs px-2.5 py-1.5 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] text-slate-300 border border-[#262b3d] hover:border-slate-600 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <span className={`w-1.5 h-1.5 rounded-full ${
                  p.risk === 'CRITICAL' ? 'bg-rose-400' : p.risk === 'HIGH RISK' ? 'bg-orange-400' : 'bg-emerald-400'
                }`} />
                <span>{p.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Analysis Result Card */}
      {currentResult && (
        <div className="space-y-6">
          {/* Main Verdict Header */}
          <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-6 shadow-xl">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 pb-6 border-b border-[#262b3d]">
              <div className="space-y-2 flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className={`text-xs px-3 py-1 rounded-md font-mono font-extrabold uppercase border ${getRiskColor(currentResult.riskLevel).bg} ${getRiskColor(currentResult.riskLevel).text} ${getRiskColor(currentResult.riskLevel).border}`}>
                    {currentResult.riskLevel}
                  </span>
                  <span className="text-xs px-2.5 py-0.5 rounded bg-[#0a0b10] text-slate-300 font-mono border border-[#262b3d]">
                    Category: {currentResult.threatCategory}
                  </span>
                  {currentResult.targetBrand && (
                    <span className="text-xs px-2.5 py-0.5 rounded bg-rose-950/70 text-rose-300 font-mono border border-rose-800/60">
                      Impersonating: {currentResult.targetBrand}
                    </span>
                  )}
                  {currentResult.isDemoData && (
                    <span className="text-[10px] px-2 py-0.5 rounded bg-[#0a0b10] text-slate-400 font-mono border border-[#262b3d]">
                      DEMO DATA
                    </span>
                  )}
                </div>

                <h2 className="text-xl sm:text-2xl font-mono font-bold text-white break-all">
                  {currentResult.domain}
                </h2>
                <p className="text-xs text-slate-400 font-mono break-all max-w-3xl">
                  {currentResult.url}
                </p>
              </div>

              {/* Risk Score Circle Gauge */}
              <div className="flex items-center gap-4 shrink-0">
                <div className="text-right">
                  <div className="text-3xl font-extrabold font-mono text-white">
                    {currentResult.riskScore}<span className="text-lg text-slate-500 font-normal">/100</span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    Confidence: {currentResult.confidence}%
                  </div>
                </div>

                <div className="relative w-16 h-16 rounded-full flex items-center justify-center border-4" style={{ borderColor: getRiskColor(currentResult.riskLevel).stroke }}>
                  {currentResult.riskScore >= 70 ? (
                    <Flame className="w-7 h-7 text-rose-400" />
                  ) : currentResult.riskScore >= 40 ? (
                    <AlertTriangle className="w-7 h-7 text-amber-400" />
                  ) : (
                    <ShieldCheck className="w-7 h-7 text-emerald-400" />
                  )}
                </div>
              </div>
            </div>

            {/* Quick Action Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 text-slate-400 font-mono">
                <span>Inspected: {new Date(currentResult.timestamp).toLocaleString()}</span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  id="url-copy-ioc-btn"
                  onClick={handleCopyIoc}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] text-slate-200 border border-[#262b3d] transition-colors cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-blue-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                  {copied ? 'Copied IOC' : 'Copy IOC JSON'}
                </button>

                <button
                  id="url-push-soc-btn"
                  onClick={() => onPushToSoc(currentResult)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 transition-colors font-medium cursor-pointer"
                >
                  <Flame className="w-3.5 h-3.5" />
                  Create SOC Incident
                </button>

                <button
                  id="url-false-positive-btn"
                  onClick={() => onOpenFalsePositiveModal(currentResult)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] text-slate-300 border border-[#262b3d] transition-colors cursor-pointer"
                >
                  <Flag className="w-3.5 h-3.5 text-amber-400" />
                  Report False Positive
                </button>

                <button
                  id="url-report-threat-btn"
                  onClick={() => onOpenReportModal(currentResult.url, 'URL')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] text-slate-300 border border-[#262b3d] transition-colors cursor-pointer"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-blue-400" />
                  File Report
                </button>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="flex border-b border-[#262b3d] text-xs font-medium overflow-x-auto">
              {[
                { id: 'overview', label: 'AI Explainability & Reasoning' },
                { id: 'signals', label: `Detected Signals (${currentResult.signals.length})` },
                { id: 'technical', label: 'Technical & DNS Details' },
                { id: 'mitre', label: 'MITRE ATT&CK Matrix' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-4 py-2.5 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === tab.id
                      ? 'border-blue-400 text-blue-400 font-semibold'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab 1: AI Explainability */}
            {activeTab === 'overview' && (
              <div className="space-y-5 pt-2">
                {/* Summary Box */}
                <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-2">
                  <div className="flex items-center gap-2 text-xs font-semibold text-blue-400 uppercase font-mono">
                    <Sparkles className="w-4 h-4" />
                    Explainable AI Security Assessment
                  </div>
                  <p className="text-sm text-slate-200 leading-relaxed">
                    {currentResult.aiExplanation.summary}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Suspicious Red Flags */}
                  <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-3">
                    <h3 className="text-xs font-semibold text-rose-400 uppercase font-mono flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4" />
                      Why This Looks Suspicious ({currentResult.aiExplanation.whySuspicious.length})
                    </h3>
                    <ul className="space-y-2">
                      {currentResult.aiExplanation.whySuspicious.map((item, idx) => (
                        <li key={idx} className="text-xs text-slate-300 flex items-start gap-2 leading-relaxed">
                          <span className="text-rose-400 font-bold mt-0.5">•</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Positive Safety Signals */}
                  <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-3">
                    <h3 className="text-xs font-semibold text-emerald-400 uppercase font-mono flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4" />
                      Observed Safety Signals ({currentResult.aiExplanation.positiveSignals.length})
                    </h3>
                    {currentResult.aiExplanation.positiveSignals.length > 0 ? (
                      <ul className="space-y-2">
                        {currentResult.aiExplanation.positiveSignals.map((item, idx) => (
                          <li key={idx} className="text-xs text-slate-300 flex items-start gap-2 leading-relaxed">
                            <span className="text-emerald-400 font-bold mt-0.5">✓</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-xs text-slate-400 italic">No positive benign signatures observed.</p>
                    )}
                  </div>
                </div>

                {/* Recommended Action Box */}
                <div className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-2">
                  <div className="text-xs font-semibold text-amber-400 uppercase font-mono flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" />
                    Recommended Defensive Action
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed font-mono">
                    {currentResult.aiExplanation.recommendedAction}
                  </p>
                </div>

                {/* Zero-Trust Notice */}
                <div className="p-3 rounded-lg bg-[#0a0b10] border border-[#262b3d] flex items-center gap-2 text-[11px] text-slate-400">
                  <Info className="w-4 h-4 text-blue-400 shrink-0" />
                  <span>
                    <strong>Zero-Trust Disclaimer:</strong> A low risk score indicates that no known malicious heuristics were triggered. PhishGuard Pro never guarantees a URL is definitely safe. Always verify senders independently.
                  </span>
                </div>
              </div>
            )}

            {/* Tab 2: Signals Table */}
            {activeTab === 'signals' && (
              <div className="space-y-4 pt-2">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-[#262b3d] text-slate-400 font-mono">
                        <th className="py-2.5 px-3">Category</th>
                        <th className="py-2.5 px-3">Signal Name</th>
                        <th className="py-2.5 px-3">Severity</th>
                        <th className="py-2.5 px-3">Evidence / Note</th>
                        <th className="py-2.5 px-3 text-right">Risk Score Impact</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#262b3d]/60">
                      {currentResult.signals.map(sig => (
                        <tr key={sig.id} className="hover:bg-[#1c2132]/50">
                          <td className="py-3 px-3 font-mono text-slate-400">{sig.category}</td>
                          <td className="py-3 px-3">
                            <div className="font-semibold text-white">{sig.name}</div>
                            <div className="text-slate-400 text-[11px]">{sig.description}</div>
                          </td>
                          <td className="py-3 px-3 font-mono">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              sig.severity === 'critical'
                                ? 'bg-rose-500/20 text-rose-300'
                                : sig.severity === 'high'
                                ? 'bg-orange-500/20 text-orange-300'
                                : sig.severity === 'medium'
                                ? 'bg-amber-500/20 text-amber-300'
                                : 'bg-emerald-500/20 text-emerald-300'
                            }`}>
                              {sig.severity}
                            </span>
                          </td>
                          <td className="py-3 px-3 font-mono text-slate-300 text-[11px]">
                            {sig.evidence || 'Pattern heuristic'}
                          </td>
                          <td className="py-3 px-3 text-right font-mono font-bold">
                            {sig.scoreContribution > 0 ? (
                              <span className="text-rose-400">+{sig.scoreContribution}</span>
                            ) : (
                              <span className="text-emerald-400">{sig.scoreContribution}</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Tab 3: Technical & DNS Details */}
            {activeTab === 'technical' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2 text-xs font-mono">
                <div className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                  <div className="text-slate-400">Transport Security (TLS)</div>
                  <div className="text-white font-bold flex items-center gap-1.5">
                    {currentResult.technicalDetails.https ? (
                      <>
                        <Lock className="w-3.5 h-3.5 text-emerald-400" />
                        HTTPS Active ({currentResult.technicalDetails.sslIssuer || 'Valid CA'})
                      </>
                    ) : (
                      <>
                        <Unlock className="w-3.5 h-3.5 text-rose-400" />
                        Unencrypted HTTP
                      </>
                    )}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                  <div className="text-slate-400">Domain Age Heuristic</div>
                  <div className="text-white font-bold">
                    {currentResult.technicalDetails.domainAgeDays ? `${currentResult.technicalDetails.domainAgeDays} days old` : 'Unknown / Hidden'}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                  <div className="text-slate-400">Top-Level Domain (TLD)</div>
                  <div className="text-white font-bold flex items-center gap-1.5">
                    .{currentResult.technicalDetails.tld}
                    <span className={`text-[10px] px-1.5 py-0.2 rounded ${
                      currentResult.technicalDetails.tldRisk === 'High' || currentResult.technicalDetails.tldRisk === 'Suspicious'
                        ? 'bg-rose-950/80 text-rose-400'
                        : 'bg-emerald-950/80 text-emerald-400'
                    }`}>
                      {currentResult.technicalDetails.tldRisk} Risk
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                  <div className="text-slate-400">IP Host & Homoglyphs</div>
                  <div className="text-white font-bold">
                    {currentResult.technicalDetails.isIpHost ? 'Direct IP Host (High Risk)' : 'Standard DNS Host'}
                    {currentResult.technicalDetails.hasHomoglyphs && ' | Homoglyphs Present'}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                  <div className="text-slate-400">Shannon Entropy Index</div>
                  <div className="text-white font-bold">
                    {currentResult.technicalDetails.entropyScore} (Threshold: 4.5)
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
                  <div className="text-slate-400">Threat Intel Feed Matches</div>
                  <div className="text-white font-bold">
                    {currentResult.technicalDetails.threatIntelHits.length > 0
                      ? currentResult.technicalDetails.threatIntelHits.join(', ')
                      : 'No active blacklist hits'}
                  </div>
                </div>
              </div>
            )}

            {/* Tab 4: MITRE ATT&CK Matrix */}
            {activeTab === 'mitre' && (
              <div className="space-y-3 pt-2">
                <div className="text-xs text-slate-400 font-mono">Mapped adversary tactics and techniques:</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {currentResult.aiExplanation.mitreTechniques.map((tech, idx) => (
                    <div key={idx} className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Terminal className="w-4 h-4 text-blue-400" />
                        <span className="font-mono text-xs font-semibold text-white">{tech}</span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-[#141722] text-slate-400 font-mono border border-[#262b3d]">
                        MITRE ATT&CK
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
