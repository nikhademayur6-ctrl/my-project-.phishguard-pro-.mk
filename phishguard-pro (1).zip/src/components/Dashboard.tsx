import React from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Activity,
  AlertTriangle,
  Flame,
  CheckCircle2,
  Lock,
  ArrowUpRight,
  TrendingUp,
  Link2,
  Mail,
  QrCode,
  Globe,
  Radio,
  Clock,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Info
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar
} from 'recharts';
import { UrlAnalysisResult, Incident, RiskLevel } from '../types';

interface DashboardProps {
  onNavigate: (view: string) => void;
  recentScans: UrlAnalysisResult[];
  incidents: Incident[];
  onSelectScan: (scan: UrlAnalysisResult) => void;
  onSelectIncident: (incident: Incident) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  onNavigate,
  recentScans,
  incidents,
  onSelectScan,
  onSelectIncident
}) => {
  const timelineData = [
    { time: '00:00', threats: 12, safe: 45 },
    { time: '04:00', threats: 8, safe: 32 },
    { time: '08:00', threats: 34, safe: 140 },
    { time: '12:00', threats: 52, safe: 210 },
    { time: '16:00', threats: 41, safe: 175 },
    { time: '20:00', threats: 24, safe: 95 },
    { time: '04:00 (Now)', threats: 31, safe: 130 }
  ];

  const riskDistribution = [
    { name: 'SAFE', value: 980, color: '#10b981' },
    { name: 'LOW RISK', value: 180, color: '#3b82f6' },
    { name: 'SUSPICIOUS', value: 76, color: '#f59e0b' },
    { name: 'HIGH RISK', value: 142, color: '#f97316' },
    { name: 'CRITICAL', value: 86, color: '#ef4444' }
  ];

  const categoryBreakdown = [
    { category: 'Brand Spoof', count: 48, percentage: 38 },
    { category: 'Credential Harvest', count: 37, percentage: 29 },
    { category: 'Executive BEC', count: 18, percentage: 14 },
    { category: 'Quishing QR', count: 14, percentage: 11 },
    { category: 'Invoice Scam', count: 10, percentage: 8 }
  ];

  const getRiskBadge = (level: RiskLevel) => {
    switch (level) {
      case 'CRITICAL':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      case 'HIGH RISK':
        return 'bg-orange-500/20 text-orange-300 border-orange-500/30';
      case 'SUSPICIOUS':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'LOW RISK':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      default:
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner: Security Posture */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#141722] via-[#141722] to-[#1e293b]/70 border border-[#262b3d] p-5 sm:p-6 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                <Radio className="w-3 h-3 animate-pulse" />
                ENTERPRISE SOC DEFENSE: ACTIVE
              </span>
              <span className="text-xs text-slate-400 font-mono">Live Node: #PG-PRO-NODE-01</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Intelligent Phishing Defense Operations
            </h1>
            <p className="text-sm text-slate-400 max-w-2xl">
              Multi-signal heuristic intelligence, AI-powered explainability, domain reputation mapping, and zero-trust threat response.
            </p>
          </div>

          {/* Quick Action Launchpad */}
          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            <button
              id="dash-quick-scan-url"
              onClick={() => onNavigate('scanner')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-all shadow-[0_0_20px_rgba(59,130,246,0.25)] cursor-pointer"
            >
              <Link2 className="w-4 h-4" />
              Analyze URL
            </button>
            <button
              id="dash-quick-scan-email"
              onClick={() => onNavigate('email')}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#0a0b10] hover:bg-[#1c2132] text-slate-200 font-medium text-xs border border-[#262b3d] transition-colors cursor-pointer"
            >
              <Mail className="w-4 h-4 text-blue-400" />
              Analyze Message
            </button>
            <button
              id="dash-quick-report"
              onClick={() => onNavigate('reports')}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#0a0b10] hover:bg-[#1c2132] text-slate-200 font-medium text-xs border border-[#262b3d] transition-colors cursor-pointer"
            >
              <Flame className="w-4 h-4 text-rose-400" />
              Report Threat
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <div className="p-4 rounded-xl bg-[#141722] border border-[#262b3d] hover:border-blue-500/40 transition-all space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs uppercase tracking-wider font-semibold">
            <span>Analyzed</span>
            <Activity className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">14,282</div>
          <div className="text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
            <TrendingUp className="w-2.5 h-2.5" /> +18% today
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#141722] border border-[#262b3d] hover:border-rose-500/40 transition-all space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs uppercase tracking-wider font-semibold">
            <span>Threats Blocked</span>
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-2xl font-bold text-rose-400 font-mono">1,429</div>
          <div className="text-[10px] text-rose-400 font-mono">100% neutralized</div>
        </div>

        <div className="p-4 rounded-xl bg-[#141722] border border-[#262b3d] hover:border-emerald-500/40 transition-all space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs uppercase tracking-wider font-semibold">
            <span>Safe URLs</span>
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-mono">12,777</div>
          <div className="text-[10px] text-slate-400 font-mono">89.4% benign</div>
        </div>

        <div className="p-4 rounded-xl bg-[#141722] border border-[#262b3d] hover:border-amber-500/40 transition-all space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs uppercase tracking-wider font-semibold">
            <span>Suspicious</span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-amber-400 font-mono">76</div>
          <div className="text-[10px] text-amber-400 font-mono">Under monitoring</div>
        </div>

        <div className="p-4 rounded-xl bg-[#141722] border border-[#262b3d] hover:border-blue-500/40 transition-all space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs uppercase tracking-wider font-semibold">
            <span>SOC Incidents</span>
            <Flame className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">{incidents.filter(i => i.status !== 'Closed').length}</div>
          <div className="text-[10px] text-blue-400 font-mono">Triage ongoing</div>
        </div>

        <div className="p-4 rounded-xl bg-[#141722] border border-[#262b3d] hover:border-blue-500/40 transition-all space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs uppercase tracking-wider font-semibold">
            <span>Intel Feeds</span>
            <Globe className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-blue-400 font-mono">6 / 6</div>
          <div className="text-[10px] text-slate-400 font-mono">1.1M active IOCs</div>
        </div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Threat Activity Timeline */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-400" />
                Real-Time Threat Detection Velocity
              </h2>
              <p className="text-xs text-slate-400">Hourly throughput of scanned vs blocked malicious payloads</p>
            </div>
            <span className="text-[11px] font-mono px-2.5 py-1 rounded bg-[#0a0b10] text-slate-300 border border-[#262b3d]">
              Last 24 Hours
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={timelineData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorThreats" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorSafe" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#141722', borderColor: '#262b3d', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="safe" name="Benign Traffic" stroke="#3b82f6" fillOpacity={1} fill="url(#colorSafe)" />
                <Area type="monotone" dataKey="threats" name="Malicious Blocked" stroke="#ef4444" fillOpacity={1} fill="url(#colorThreats)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Risk Distribution Breakdown */}
        <div className="p-5 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4 flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              Risk Severity Spectrum
            </h2>
            <p className="text-xs text-slate-400">Proportional classification of evaluated entities</p>
          </div>

          <div className="h-44 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={riskDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {riskDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#141722', borderColor: '#262b3d', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            {riskDistribution.map(item => (
              <div key={item.name} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-slate-400 truncate">{item.name}:</span>
                <span className="font-bold text-white ml-auto">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Second Row: Recent Analyses & Active Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Scans Table */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-400" />
                Recent Intelligence Inspections
              </h2>
              <p className="text-xs text-slate-400">Live telemetry from URL and message scanners</p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => onNavigate('history')}
                className="text-xs text-slate-400 hover:text-white font-medium flex items-center gap-1 cursor-pointer transition-colors"
              >
                Full Vault History ({recentScans.length}) <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
              </button>
              <button
                onClick={() => onNavigate('scanner')}
                className="text-xs text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1 cursor-pointer"
              >
                Open Scanner <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="divide-y divide-[#262b3d]/80">
            {recentScans.slice(0, 4).map(scan => (
              <div
                key={scan.id}
                onClick={() => onSelectScan(scan)}
                className="py-3 px-2 rounded-xl hover:bg-[#1c2132] cursor-pointer transition-colors flex items-center justify-between gap-4"
              >
                <div className="space-y-1 min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold uppercase border ${getRiskBadge(scan.riskLevel)}`}>
                      {scan.riskLevel}
                    </span>
                    <span className="text-xs font-semibold text-white truncate font-mono">{scan.domain}</span>
                    {scan.isDemoData && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#0a0b10] text-slate-400 font-mono border border-[#262b3d]">
                        DEMO DATA
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 truncate max-w-xl">{scan.url}</p>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-sm font-bold font-mono text-white">{scan.riskScore}/100</div>
                  <span className="text-[10px] text-slate-400">Score</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Security Recommendations & Health */}
        <div className="p-5 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4">
          <div>
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-400" />
              Defense Recommendations
            </h2>
            <p className="text-xs text-slate-400">Automated posture hardening directives</p>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
              <div className="flex items-center gap-1.5 font-semibold text-amber-300">
                <AlertTriangle className="w-3.5 h-3.5" />
                Quishing Alert in Corporate Mail
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                QR code scams have surged 42% this week. Enable QR image decoding filters across Microsoft 365 / Google Workspace gateways.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
              <div className="flex items-center gap-1.5 font-semibold text-emerald-300">
                <ShieldCheck className="w-3.5 h-3.5" />
                FIDO2 / Hardware Security Keys
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                Enforce WebAuthn / Passkeys to eliminate credential-harvesting vulnerabilities across executive accounts.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-[#0a0b10] border border-[#262b3d] space-y-1">
              <div className="flex items-center gap-1.5 font-semibold text-blue-300">
                <Globe className="w-3.5 h-3.5" />
                Newly Registered Domain Policy
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                Automatically sandbox web traffic to domains registered in the last 14 days.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
