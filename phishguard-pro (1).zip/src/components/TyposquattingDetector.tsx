import React, { useState } from 'react';
import {
  Copy,
  Search,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Flame,
  ArrowRight,
  ExternalLink,
  Sparkles,
  Layers,
  CheckCircle2,
  Lock
} from 'lucide-react';
import { generateTyposquatVariants } from '../utils/securityEngine';

interface TyposquattingProps {
  onScanPermutation: (domain: string) => void;
  onAddToBlocklist?: (domain: string) => void;
}

export const TyposquattingDetector: React.FC<TyposquattingProps> = ({
  onScanPermutation,
  onAddToBlocklist
}) => {
  const [targetDomain, setTargetDomain] = useState('paypal.com');
  const [activeDomain, setActiveDomain] = useState('paypal.com');
  const [variants, setVariants] = useState(() => generateTyposquatVariants('paypal.com'));

  const handleGenerate = (domainToUse?: string) => {
    const domain = domainToUse || targetDomain;
    if (!domain.trim()) return;
    setActiveDomain(domain.trim());
    setVariants(generateTyposquatVariants(domain.trim()));
  };

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case 'CRITICAL':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      case 'HIGH':
        return 'bg-orange-500/20 text-orange-300 border-orange-500/30';
      case 'MEDIUM':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      default:
        return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30">
            BRAND SPOOF SIMULATOR
          </span>
          <span className="text-xs text-slate-400 font-mono">Homoglyphs • Bit-Squatting • Subdomain Cloaks</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
          <Copy className="w-7 h-7 text-rose-400" />
          Typosquatting & Brand Impersonation Matrix
        </h1>
        <p className="text-sm text-slate-400">
          Proactively map deceptive lookalike domains that threat actors weaponize to impersonate your company or legitimate vendors.
        </p>
      </div>

      {/* Target Domain Input */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4 shadow-xl">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleGenerate();
          }}
          className="flex flex-col sm:flex-row items-stretch gap-3"
        >
          <div className="relative flex-1">
            <Copy className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="typosquat-input-domain"
              type="text"
              value={targetDomain}
              onChange={(e) => setTargetDomain(e.target.value)}
              placeholder="Enter legitimate domain (e.g. paypal.com, microsoft.com, chase.com)..."
              className="w-full bg-[#0a0b10] border border-[#262b3d] hover:border-slate-600 focus:border-rose-500 rounded-xl px-4 py-3 pl-11 text-sm text-slate-100 placeholder-slate-500 focus:outline-none font-mono transition-all"
            />
          </div>

          <button
            id="typosquat-generate-btn"
            type="submit"
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-sm transition-all shadow-[0_0_20px_rgba(244,63,94,0.25)] shrink-0 cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            Generate Lookalike Matrix
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#262b3d] text-xs">
          <span className="text-slate-400">Popular Brands to Test:</span>
          {['paypal.com', 'microsoft.com', 'apple.com', 'chase.com', 'netflix.com'].map(b => (
            <button
              key={b}
              type="button"
              onClick={() => {
                setTargetDomain(b);
                handleGenerate(b);
              }}
              className="px-2.5 py-1 rounded-lg bg-[#0a0b10] hover:bg-[#1c2132] text-slate-300 border border-[#262b3d] font-mono transition-colors cursor-pointer"
            >
              {b}
            </button>
          ))}
        </div>
      </div>

      {/* Permutation Matrix Grid */}
      <div className="p-6 rounded-2xl bg-[#141722] border border-[#262b3d] space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              Generated Deception Variants for <span className="font-mono text-blue-400">{activeDomain}</span>
            </h2>
            <p className="text-xs text-slate-400">
              High-risk variations sorted by visual deceptiveness and social engineering efficacy
            </p>
          </div>
          <span className="text-xs font-mono px-2.5 py-1 rounded bg-[#0a0b10] text-slate-300 border border-[#262b3d]">
            {variants.length} Attack Vectors
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-2">
          {variants.map((item, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl bg-[#0a0b10] border border-[#262b3d] hover:border-slate-600 transition-all flex flex-col justify-between gap-3"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold uppercase border ${getRiskBadge(item.risk)}`}>
                      {item.risk} RISK
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">{item.type}</span>
                  </div>
                  <div className="text-base font-bold font-mono text-white break-all">
                    {item.variant}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-xs font-mono font-bold text-slate-300">Similarity</div>
                  <div className="text-sm font-mono text-blue-400 font-bold">{item.similarity}%</div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-[#262b3d] text-xs">
                <span className="text-[11px] text-slate-400">Tactics: Visual Spoofing</span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onScanPermutation(`https://${item.variant}`)}
                    className="px-3 py-1 rounded-lg bg-blue-500/15 hover:bg-blue-500/25 text-blue-300 text-xs font-medium border border-blue-500/30 transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    Deep Scan <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
